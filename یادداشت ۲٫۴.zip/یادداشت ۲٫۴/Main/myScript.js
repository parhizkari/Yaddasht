//============  THE MAIN VARIABLES AND INITIAL POPULATION OF THE WEBPAGE ON LOAD  =============//


//== global variables ==
var container=document.getElementById('container');

var pageToBeEdited,			// it will be used by the functions:  saveEditedPage() and changeView(text)
	myJSONData,				// the main variable (JSON DATABASE) which contains the whole data
	totalPageNumber=1, currentPage=1, selectedPageNumShown=1,
	RTLVar=1, ViewDemoVar=0, StartToEndVar=0,
	hslider='calc(100% - 20px)', vslider='calc(95vh - 50px)';

document.getElementById("hSizeSlider").value = '100';
document.getElementById("vSizeSlider").value = '95';


var refHeader=0, ftnNum=0, refFTN=0, figNum=0, videoNum=0, audioNum=0, iFrameNum=0, tblNum=0, nestedListLevel=0;
var finalTagsList=[], pagesShown=[];

	
document.getElementById("goToPage").value="۱\/۱";



//=============  USE localStorage OF HTML5 TO RELOAD DATA FROM CACHE AT START  ==============//



if (window.localStorage["savedInCahe"] != 'undefined' && window.localStorage["savedInCahe"] != null) {
//if (window.localStorage["savedInCahe"] != 'undefined') {
	myJSONData = JSON.parse(window.localStorage["savedInCahe"]);	//retrieves the data from the browser's cache even after the browser/tab is reopened
}

window.onload=function(){
	if(myJSONData){
		document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>دفترچه‌ی: </span>"+myJSONData.BookName;
		
		selectedPageNumShown = myJSONData.daysInPageNum;
		StartToEndVar = myJSONData.start2End;
		hslider = myJSONData.hslider;
		vslider = myJSONData.vslider;
		currentPage = myJSONData.currentPage;
		
		document.getElementById("hSizeSlider").value = hslider.replace(/[^\d]*(\d+)\%.*/,"$1");
		document.getElementById("vSizeSlider").value = vslider.replace(/[^\d]*(\d+)vh.*/,"$1");
		
		fillTheBook();
		selectHowMany();
	}
}


//=============  FIND THE PRESENT DATE IN THE PERSIAN CALENDAR  ==============//



function gregorian_to_jalali(gy,gm,gd){
	g_d_m=[0,31,59,90,120,151,181,212,243,273,304,334];
	jy=(gy<=1600)?0:979;
	gy-=(gy<=1600)?621:1600;
	gy2=(gm>2)?(gy+1):gy;
	days=(365*gy) +(parseInt((gy2+3)/4)) -(parseInt((gy2+99)/100)) +(parseInt((gy2+399)/400)) -80 +gd +g_d_m[gm-1];
	jy+=33*(parseInt(days/12053)); 
	days%=12053;
	jy+=4*(parseInt(days/1461));
	days%=1461;
	jy+=parseInt((days-1)/365);
 	if(days > 365)days=(days-1)%365;
	jm=(days < 186)?1+parseInt(days/31):7+parseInt((days-186)/30);
	jd=1+((days < 186)?(days%31):((days-186)%30));
	return [jy,jm,jd];
};
var persianMonth=["","فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
var dayOfWeek=["یکشنبه","دوشنبه","سه‌شنبه", "چهارشنبه","پنجشنبه","جمعه","شنبه"];
var currenDayOfWeek;
var shortDate;
function persianDateTime(){
	d=new Date();
	g_y=d.getFullYear();
	g_m=d.getMonth()+1;
	g_d=d.getDate();
	currenDayOfWeek=d.getDay();
	shamsi=gregorian_to_jalali(g_y,g_m,g_d);
	
	H = d.getHours();
	i = d.getMinutes();
	i = (i<10) ? "0"+i : i;
	
	var morningAfternoon= 
		(H==12)  ? "ظهر" : (
			(H!=0) ? (
				(H<12) ? "صبح" : (
					(H>=20) ? "شب" :  "بعد از ظهر"
				)
			)
			: "نیمه‌شب"
		);
	shortDate=shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]+" - "+H+":"+i
	
	H = (H<=12)  ?  H  :  H-12;
	H = (H<10) ? "0"+H : H;
	
	//return shamsi[0]+"-"+persianMonth[shamsi[1]]+"-"+shamsi[2]+"("+H+" "+i+")";
	return dayOfWeek[currenDayOfWeek]+" "+ shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]+"، ساعت "+H+":"+i+" "+morningAfternoon;	// "نسخه‌ی "+shamsi[2]+" "+persianMonth[shamsi[1]]+" "+shamsi[0]+" ساعت "+H+" و "+i+" دقیقه‌ی "+morningAfternoon;
};
// now you can use the present date by calling the function  persianDateTime()




//=================  TRANSFORM NUMBERS TO PERSIAN/ENGLISH  ==================



function toFa(texWithEnglishNumbers){
	return texWithEnglishNumbers.toString()
		.replace(/0/g,'۰').replace(/1/g,'۱').replace(/2/g,'۲').replace(/3/g,'۳').replace(/4/g,'۴').replace(/5/g,'۵')
		.replace(/6/g,'۶').replace(/7/g,'۷').replace(/8/g,'۸').replace(/9/g,'۹').replace(/\./g,'٫').replace(/\//g,'٫');
}
function toEn(texWithPersianNumbers){
	return texWithPersianNumbers.toString()
		.replace(/۰/g,'0').replace(/۱/g,'1').replace(/۲/g,'2').replace(/۳/g,'3').replace(/۴/g,'4').replace(/۵/g,'5')
		.replace(/۶/g,'6').replace(/۷/g,'7').replace(/۸/g,'8').replace(/۹/g,'9').replace(/\//g,'.').replace(/\٫/g,'.');
}
var abjad="الف ب ج د هـ و ز ح ط ی ک ل م ن س ع ف ص ق ر ش ت ث خ ذ ض ظ غ".split(" "),
		Roman="I II III IV V VI VII VIII IX X XI XII XIII XIV XV".split(" "),
		roman="i ii iii iv v vi vii viii ix x xi xii xiii xiv xv".split(" ");
//var dice=["⚀","⚁","⚂","⚃","⚄","⚅","⚅⚀","⚅⚁","⚅⚂","⚅⚃","⚅⚄","⚅⚅"];		//["◌","○","◷","◶","◵","◴","□","◳","◲","◱","◰","◓","◑","◒","◐","●","◨","◪","◧","◩","■"];




//=============  to define some keyboard shortcuts and etc ...  ==============



document.addEventListener("keydown", function(e){
	// add the shortcut "ctrl + F1" for ADD A NEW PAGE
	if (e.ctrlKey && e.keyCode === 112) { e.preventDefault(); addNewDay(); }
	// add the shortcut "ctrl + F2" to Focus to the Filter TextInput
	if (e.ctrlKey && e.keyCode === 113) { e.preventDefault(); document.getElementById("droppableTagsList").focus(); }
	// add the shortcut "ctrl + F3" to Focus to select Page umber Input
	if (e.ctrlKey && e.keyCode === 114) { e.preventDefault(); document.getElementById("goToPage").focus(); document.getElementById("goToPage").value="";}
	
	
	// add the shortcut "Ctrl + right" for toggling between the Editor and the Demo, while adding new day
	if (e.ctrlKey && e.keyCode === 39 && window.location.href.indexOf('popupNewDay')!=-1) {
		e.preventDefault();
		changeView('New');
	}
	// add the shortcut "Ctrl + right" for toggling between the Editor and the Demo, while editing an existing day
	if (e.ctrlKey && e.keyCode === 39 && window.location.href.indexOf('popupEditDay')!=-1) {
		e.preventDefault();
		changeView('Edit');
	}
	
	
	// add the shortcut "ctrl+down" for page change to NEXT
	if (e.ctrlKey && e.keyCode === 40) { e.preventDefault(); nextPage(); }
	// add the shortcut "ctrl+up" for page change to PREVIOUS
	if (e.ctrlKey && e.keyCode === 38) { e.preventDefault(); prevPage(); }
	
	// to close the Popups by pressing the key "Esc"
	if (e.keyCode == 27) {
		if(e.target.id == 'popupSmilies' || e.target.id == 'popupGuide' || e.target.id == 'popupAbout'){
			window.location.href='#';
		}
	}
	
	
});


document.getElementById("bookTitle").onkeypress=function(e){	// to save the book by pressing the key "Enter"
	if (e.keyCode === 13) {
		e.preventDefault();
		e.returnValue = false;
		saveNewBooklet();
	}
};



document.onclick = function(e){
	//check if the dark backgrounds of the popups are clicked ...
	if(e.target.id == 'popupSmilies' || e.target.id == 'popupGuide' || e.target.id == 'popupAbout'){
		window.location.href='#';
	}
}


document.getElementById("goToPage").onclick = function(){
	document.getElementById("goToPage").value="";
}
document.getElementById("goToPage").addEventListener("focusout",function(){
	document.getElementById("goToPage").value=toFa(currentPage)+'\/'+toFa(totalPageNumber);
});




//=============  Pagination  ==============


function selectBoxChange(n){
	if(myJSONData){
		myJSONData.currentPage = currentPage = 1;
		myJSONData.daysInPageNum = selectedPageNumShown = n;
		saveToCache();
		
		selectHowMany();
	}else{
		return false;
	}
}
function selectHowMany(){
	// to determine which days are to be shown on the screen, whether filtered by tags names or not
	var inputKeys=document.getElementById("droppableTagsList").value;	//this being "" will show all the days stored in  myJSONData["days"]
	pagesShown=[];
	for(var day=1, days=myJSONData["days"].length; day<=days; day++) {
		if(myJSONData["days"][day-1]["tags"].join(" ، ").indexOf(inputKeys)!=-1) {
			pagesShown.push(day);
		}
	}
	
	document.getElementById("selectBox").value=selectedPageNumShown;
	if(selectedPageNumShown=="ALL"){
		totalPageNumber=1;
		//currentPage=1;
	} else {
		totalPageNumber=(pagesShown.length)?  Math.ceil(pagesShown.length / selectedPageNumShown)  : 1;
		//currentPage=(StartToEndVar==0)?  1 : totalPageNumber;
		if(currentPage > totalPageNumber){
			myJSONData.currentPage = currentPage = totalPageNumber;
			saveToCache();
		}
	}
	document.getElementById("goToPage").value=toFa(currentPage)+'\/'+toFa(totalPageNumber);
	
	changePage();
}
function nextPage(){
	myJSONData.currentPage = currentPage = (currentPage < totalPageNumber) ? currentPage+1 : totalPageNumber ;
	saveToCache();
	
	document.getElementById("goToPage").value=toFa(currentPage)+'\/'+toFa(totalPageNumber);
	
	// to show only those pages which lie in the range selected
	changePage();
}
function prevPage(){
	myJSONData.currentPage = currentPage = (currentPage > 1) ? currentPage-1 : 1 ;
	saveToCache();
	
	document.getElementById("goToPage").value=toFa(currentPage)+'\/'+toFa(totalPageNumber);
	
	// to show only those pages which lie in the range selected
	changePage();
}
document.getElementById("goToPage").onkeypress = function(ev){
	if (ev.which === 13){
		myJSONData.currentPage = currentPage = toEn(document.getElementById("goToPage").value);
		if(currentPage < 1){ myJSONData.currentPage = currentPage = 1; }
		if(currentPage > totalPageNumber){ myJSONData.currentPage = currentPage = totalPageNumber; }
		saveToCache();
		
		document.getElementById("goToPage").value=toFa(currentPage)+'\/'+toFa(totalPageNumber);
		
		// to show only those pages which lie in the range selected
		changePage();
	}
}
function changePage(){
	for(var day=1, days=myJSONData["days"].length; day<=days; day++) {
		if(!document.getElementById("Page"+day).classList.contains("hidden")){
			document.getElementById("Page"+day).classList.add("hidden");
		}
	}
	// to determine the range of days that should be shown in the current page
	if(StartToEndVar==0){		//to display the pages in reverse order, the last page at top-right of the webpage
		if(selectedPageNumShown == "ALL"){
			initialDayNum=0;
			finalDayNum=pagesShown.length - 1;
		}else{
			initialDayNum=pagesShown.length - currentPage*selectedPageNumShown;
			if(initialDayNum<0) initialDayNum=0;
			finalDayNum=pagesShown.length - (currentPage-1)*selectedPageNumShown - 1;
		}
	}else{						//to display the pages in straight order of page numbers, the last page at bottom-left of the webpage
		if(selectedPageNumShown == "ALL"){
			initialDayNum=0;
			finalDayNum=pagesShown.length - 1;
		}else{
			initialDayNum=(currentPage-1)*selectedPageNumShown;
			finalDayNum=currentPage*selectedPageNumShown - 1;
			if(finalDayNum>pagesShown.length) finalDayNum=pagesShown.length;
		}
	}
	
	
	/*
	// to show only those pages which lie in the correct range,
	// with correct order of appearance from start to end or the reverse (from https://stackoverflow.com/a/16925353)
	if(StartToEndVar==0){	//to display the pages in reverse order, the last page at top-right of the webpage
		container.style.transform = "scale(-1,-1)";
	}else{					//to display the pages in straight order of page numbers
		container.style.transform = "scale(1,1)";
	}
	for (var i in pagesShown) {
		if(i>=initialDayNum && i<=finalDayNum){
			document.getElementById("Page"+pagesShown[i]).classList.remove("hidden");
		}
		
		if(StartToEndVar==0){	//to display the pages in reverse order, the last page at top-right of the webpage
			document.getElementById("Page"+pagesShown[i]).style.transform = "scale(-1,-1)";
		}else{					//to display the pages in straight order of page numbers
			document.getElementById("Page"+pagesShown[i]).style.transform = "scale(1,1)";
		}
	}
	*/
	for (var i in pagesShown) {
		if(i>=initialDayNum && i<=finalDayNum){
			document.getElementById("Page"+pagesShown[i]).classList.remove("hidden");
		}
	}
			
}




//=================  Populate the currenDate div in main header  ==================//



persianDateTime();
document.getElementById("currenDate").innerHTML=toFa(dayOfWeek[currenDayOfWeek]+" "+shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]);



//=================  BUILD A WHOLE NEW BOOKLET  ==================//



function newBooklet() {
	if(myJSONData){
		if(!confirm('با ایجاد یک دفترچه‌ی جدید، اطلاعات پرونده‌ی قبلی پاک می‌شوند، آیا ادامه می‌دهید؟')){
			return false;
		}
	}
	window.location.href='#popupNewBook';
	
	setTimeout(function(){
		document.getElementById("bookTitle").focus();
	}, 500);
}
function saveNewBooklet() {
	if(!(document.getElementById("bookTitle").value)){
		alert("لطفاً عنوان دفترچه‌ی جدید را وارد نمایید!");
		return false;
	}
	// fill the variable and make a new data in the JSON variables
	myJSONData = {
		"BookName":document.getElementById("bookTitle").value,
		"days":[],
		
		"daysInPageNum": 1,					// selectedPageNumShown
		"start2End": 0, 					// StartToEndVar
		"hslider": "calc(100% - 20px)",		// hslider
		"vslider": "calc(95vh - 50px)",		// vslider
		"currentPage": 1					// currentPage
	};
	
	//container.innerHTML="";
	fillTheBook();
	selectHowMany();
	
	document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>دفترچه‌ی: </span>"+myJSONData.BookName;
	
	window.location.href='#';						// to colse the popup
	document.getElementById('newBookForm').reset();	//reset the form for later recalling the popup
}




//=================  BUILD A WHOLE NEW PAGE (DAY) INSIDE THE BOOKLET  ==================//




function addNewDay() {
	if(!myJSONData){
		alert("لطفاً ابتدا یا یک دفترچه‌ی قدیمی را بارگذاری، و یا دفترچه‌ای جدید ایجاد نمایید ...!");
	}else{
		window.location.href='#popupNewDay';
		// to pre-populate the date fields
		document.getElementById("newWeekDAY").value=dayOfWeek[currenDayOfWeek];
		document.getElementById("newDAY").value=toFa(shamsi[2]);
		document.getElementById("newMONTH").value=toFa(shamsi[1]);
		document.getElementById("newYEAR").value=toFa(shamsi[0]);
	
		setTimeout(function(){
			document.getElementById("newDescription").focus();
		}, 500);
		
		RTLVar=1;
		document.getElementById("newDescription").dir="rtl";
		document.getElementById("RTLorLTR_New").src="Main/images/ltr.png";
		document.getElementById("RTLorLTR_New").title="چپ به راست ...";
		document.getElementById("RTLorLTR_New").style.display="initial";
		ViewDemoVar=0;
		document.getElementById("newDescription").style.display="initial";
		document.getElementById("NewDemo").style.display="none";
		document.getElementById("Demo_Editor_New").src="Main/images/eye.png";
		document.getElementById("Demo_Editor_New").title="نمایش خروجی (Ctrl+Right) ... (فقط همین صفحه اجرا می‌شود، در\nنتیجه ارجاعات به صفحات دیگر درست نمایش داده نخواهند شد!\n علاوه بر این، سایر لینک‌ها نیز به صورت غیرفعال نمایش داده می‌شوند\n تا در اثر کلیک بر روی آن‌ها صفحه بسته نشود!)";
	}
}
function saveNewDay() {
	// fill the variable and make a new data in the JSON variable
	var validatedDay=Number(toEn(document.getElementById("newDAY").value)),
		validatedMonth=Number(toEn(document.getElementById("newMONTH").value)),
		validatedYEAR=Number(toEn(document.getElementById("newYEAR").value));
		
	if(Number.isInteger(validatedDay) && validatedDay>=1 && validatedDay<=31
		&& Number.isInteger(validatedMonth) && validatedMonth>=1 && validatedMonth<=12
		&& Number.isInteger(validatedYEAR) && validatedYEAR>=0) {
		// for sorting by dates we need to define new variables
		var validatedDayEx = (validatedDay<10) ? "0"+validatedDay : validatedDay;		//e.g. 5 -> 05
		var validatedMonthEx = (validatedMonth<10) ? "0"+validatedMonth : validatedMonth;	//e.g. 5 -> 05
		
		myJSONData.days.push(
			{
				"weekDay": document.getElementById("newWeekDAY").value ,
				"day": validatedDay ,
				"month": validatedMonth ,
				"year": validatedYEAR ,
				"dateForSortAction": Number(validatedYEAR+""+validatedMonthEx+""+validatedDayEx) ,
				"lastEditDate": "" ,
				"tags": document.getElementById("newTags").value
															.split("،")
															.map(function(item) {return item.trim();})
															.sort(function(a, b){return a.localeCompare(b);}) ,
				"description": document.getElementById("newDescription").value
			}
		);
		
		
		fillTheBook();
		selectHowMany();
		
		
		
		// new day isn't necassarily the last one, so let finally jump to it wherever it is (myJSONData is sorted inside fillTheBook())
		var currentDay;
		for(var day=1, days=myJSONData["days"].length; day<=days; day++) {	//var day in myJSONData["days"]
			if(myJSONData["days"][day-1]["dateForSortAction"] == validatedYEAR+validatedMonthEx+validatedDayEx){
				currentDay=day;
				break;
			}
		}
		jumpToPageContainingPage(currentDay);
		//document.getElementById("Page"+currentDay).scrollIntoView({behavior: "smooth", block: "center", inline: "nearest"});	// or use inline: "center"
		window.location.href='#Page'+currentDay;	// to colse the popup,   and moves the scrollbar to its right position
		
		
		
		//window.location.href='#';						// to colse the popup
		document.getElementById('newTags').value
									=document.getElementById('newDescription').value
									=document.getElementById('NewDemo').innerHTML
									="";
	}else{
		alert("لطفاً تاریخ‌ها را درست وارد نمایید. این اطلاعات برای مرتب کردن صفحات دفترچه به کار گرفته می‌شوند.");
	}
}



//=================  EDIT AN ALREADY AVAILABLE DAY IN THE BOOK  ==================//



function editPage(pageNum) {
	pageToBeEdited=pageNum;
	
	//first populate the form with data from the page which is now to be edited
	document.getElementById("PageToEdit").innerHTML=toFa(pageNum);
	
	document.getElementById("editWeekDAY").value=myJSONData["days"][pageNum-1]["weekDay"];
	document.getElementById("editDAY").value=toFa(myJSONData["days"][pageNum-1]["day"]);
	document.getElementById("editMONTH").value=toFa(myJSONData["days"][pageNum-1]["month"]);
	document.getElementById("editYEAR").value=toFa(myJSONData["days"][pageNum-1]["year"]);
	
	document.getElementById("editTags").value=myJSONData["days"][pageNum-1]["tags"].join(" ، ");
	
	document.getElementById("editDescription").value=myJSONData["days"][pageNum-1]["description"];
	
	// next call for the editing form to open
	window.location.href='#popupEditDay';
	
	setTimeout(function(){
		document.getElementById("editDescription").focus();
	}, 500);
		
	RTLVar=1;
	document.getElementById("editDescription").dir="rtl";
	document.getElementById("RTLorLTR_Edit").src="Main/images/ltr.png";
	document.getElementById("RTLorLTR_Edit").title="چپ به راست ...";
	document.getElementById("RTLorLTR_Edit").style.display="initial";
	ViewDemoVar=0;
	document.getElementById("editDescription").style.display="block";
	document.getElementById("EditDemo").style.display="none";
	document.getElementById("Demo_Editor_Edit").src="Main/images/eye.png";
	document.getElementById("Demo_Editor_Edit").title="نمایش خروجی (Ctrl+Right) ... (فقط همین صفحه اجرا می‌شود، در\nنتیجه ارجاعات به صفحات دیگر درست نمایش داده نخواهند شد!\n علاوه بر این، سایر لینک‌ها نیز به صورت غیرفعال نمایش داده می‌شوند\n تا در اثر کلیک بر روی آن‌ها صفحه بسته نشود!)";
}
function refuseToChange(){
	// I don't know why is this required for footnotes citation to work again properly ... this is now more like a hack :(
	setCrossReferences("container");
	
	for(var day=1, days=myJSONData["days"].length; day<=days; day++) {	//var day in myJSONData["days"]
		document.getElementById('Page'+day).innerHTML=document.getElementById('Page'+day).innerHTML
			.replace(/از برگه‌ی (\d+)/g, function(x,y){
				if(y==day){
					return "از همین برگه";
				}else{
					return "از برگه‌ی "+toFa(y);
				}
			});
	}
}
function saveEditedPage() {
	// fill the variable and make a new data in the JSON variable
	var validatedDay=Number(toEn(document.getElementById("editDAY").value)),
		validatedMonth=Number(toEn(document.getElementById("editMONTH").value)),
		validatedYEAR=Number(toEn(document.getElementById("editYEAR").value));
	
	if(Number.isInteger(validatedDay) && validatedDay>=1 && validatedDay<=31
		&& Number.isInteger(validatedMonth) && validatedMonth>=1 && validatedMonth<=12
		&& Number.isInteger(validatedYEAR) && validatedYEAR>=0) {
		// for sorting by dates we need to define new variables
		var validatedDayEx = (validatedDay<10) ? "0"+validatedDay : validatedDay;			//e.g. 5 -> 05
		var validatedMonthEx = (validatedMonth<10) ? "0"+validatedMonth : validatedMonth;	//e.g. 5 -> 05
		
		myJSONData.days.splice((pageToBeEdited-1), 1,	// deletes the original one and insert the edited one at the same place in the array
			{
				"weekDay": document.getElementById("editWeekDAY").value ,
				"day": validatedDay ,
				"month": validatedMonth ,
				"year": validatedYEAR ,
				"dateForSortAction": Number(validatedYEAR+""+validatedMonthEx+""+validatedDayEx) ,
				"lastEditDate": '<input type="image" src="Main/images/info.png" title="آخرین ویرایش در '+toFa(persianDateTime())+'" width="15" height="15" style="cursor:help; position:relative; bottom:3px; right:2px;">' ,
				"tags": document.getElementById("editTags").value.split("،").map(function(item) {
																							return item.trim();
																						}) ,
				"description": document.getElementById("editDescription").value
			}
		);
		
		fillTheBook();
		selectHowMany();
		jumpToPageContainingPage(pageToBeEdited);
		
		//reset the form for later recalling the popup
		document.getElementById('editTags').value
									=document.getElementById('editDescription').value
									=document.getElementById('EditDemo').innerHTML
									="";
		window.location.href='#';	// to close the popup
	}else{
		alert("لطفاً تاریخ‌ها را درست وارد نمایید. این اطلاعات برای مرتب کردن صفحات دفترچه به کار گرفته می‌شوند.");
	}
}


//=================  MANAGE THE BUTTONS IN THE NEWPAGE & EDITPAGE POPUPS  ==================//



function changeTextDirection(txt){
	if(RTLVar){
		if(txt=="New"){
			document.getElementById("newDescription").dir="ltr";
			document.getElementById("RTLorLTR_New").src="Main/images/rtl.png";
			document.getElementById("RTLorLTR_New").title="راست به چپ ...";
		}else{
			document.getElementById("editDescription").dir="ltr";
			document.getElementById("RTLorLTR_Edit").src="Main/images/rtl.png";
			document.getElementById("RTLorLTR_Edit").title="راست به چپ ...";
		}
	}else{
		if(txt=="New"){
			document.getElementById("newDescription").dir="rtl";
			document.getElementById("RTLorLTR_New").src="Main/images/ltr.png";
			document.getElementById("RTLorLTR_New").title="چپ به راست ...";
		}else{
			document.getElementById("editDescription").dir="rtl";
			document.getElementById("RTLorLTR_Edit").src="Main/images/ltr.png";
			document.getElementById("RTLorLTR_Edit").title="چپ به راست ...";
		}
	}
	RTLVar=(RTLVar)? 0 : 1 ;
}


function changeView(txt){
	if(ViewDemoVar){
		if(txt=="New"){
			document.getElementById("newDescription").style.display="inline-block";
			document.getElementById("RTLorLTR_New").style.display="initial";
			document.getElementById("NewDemo").style.display="none";
			document.getElementById("Demo_Editor_New").src="Main/images/eye.png";
			document.getElementById("Demo_Editor_New").title="نمایش خروجی (Ctrl+Right) ... (فقط همین صفحه اجرا می‌شود، در\nنتیجه ارجاعات به صفحات دیگر درست نمایش داده نخواهند شد!\n علاوه بر این، سایر لینک‌ها نیز به صورت غیرفعال نمایش داده می‌شوند\n تا در اثر کلیک بر روی آن‌ها صفحه بسته نشود!)";
		}else{
			document.getElementById("editDescription").style.display="block";
			document.getElementById("RTLorLTR_Edit").style.display="initial";
			document.getElementById("EditDemo").style.display="none";
			document.getElementById("Demo_Editor_Edit").src="Main/images/eye.png";
			document.getElementById("Demo_Editor_Edit").title="نمایش خروجی (Ctrl+Right) ... (فقط همین صفحه اجرا می‌شود، در\nنتیجه ارجاعات به صفحات دیگر درست نمایش داده نخواهند شد!\n علاوه بر این، سایر لینک‌ها نیز به صورت غیرفعال نمایش داده می‌شوند\n تا در اثر کلیک بر روی آن‌ها صفحه بسته نشود!)";
		}
	}else{
		ftnNum = refFTN = figNum = videoNum = audioNum = iFrameNum = tblNum = nestedListLevel = 0;
		
		if(txt=="New"){
			document.getElementById("newDescription").style.display="none";
			document.getElementById("RTLorLTR_New").style.display="none";
			document.getElementById("NewDemo").style.display="inline-block";
			document.getElementById("Demo_Editor_New").src="Main/images/edit.png";
			document.getElementById("Demo_Editor_New").title="ویرایش ... (Ctrl+Right)";
			
			// reset some styles, as the user may have changed it through using the command /ص[...][...]... the previous time adding a day
			document.getElementById("NewDemo").style.fontFamily="en1, fa1";
			document.getElementById("NewDemo").style.fontSize="90%";
			document.getElementById("NewDemo").style.lineHeight="1.5";
			document.getElementById("NewDemo").style.color="black";
			document.getElementById("NewDemo").style.textShadow="none";
			document.getElementById("NewDemo").style.background="none";
			
			var inputVal=document.getElementById("newDescription").value;
			document.getElementById("NewDemo").innerHTML=
				compile("NewDemo",inputVal)
				+"<br><div id='ftnOnNewDemo' style='display:none;'>"
					+"<br><hr style='width:30%; float:right;'><br>"
					+"<div id='ftnColWrapperOnNewDemo'></div>"
				+"</div>";
			postProcess("NewDemo");
			setCrossReferences("NewDemo");
			/*
			//MathJax.texReset();
			//MathJax.typesetClear();
			MathJax.typeset(["#NewDemo"]);
			//MathJax.typeset();
			*/
			document.getElementById("NewDemo").innerHTML=document.getElementById("NewDemo").innerHTML
				.replace(/(href\=[\'\"]\#[^\'\"]*[\"\'])/g,"");	// kills all the links inside demo, not to jump out from demo while clicking
			
			document.getElementById("NewDemo").innerHTML=document.getElementById("NewDemo").innerHTML
				.replace(/از برگه‌ی (\d+|NewDemo)/g, function(x,y){
					//alert(y);
					if(y=="NewDemo"){
						return "از همین برگه";
					}else{
						return "از برگه‌ی "+toFa(y);
					}
				});
		}else{
			// let wipe out the original page, as labels of the divs in it can conflict with those in EditDemo, when showing the demo
			var pageUnderEditing=document.getElementById("Page"+pageToBeEdited).innerHTML;
			document.getElementById("Page"+pageToBeEdited).innerHTML="";
			
			document.getElementById("editDescription").style.display="none";
			document.getElementById("RTLorLTR_Edit").style.display="none";
			document.getElementById("EditDemo").style.display="block";
			document.getElementById("Demo_Editor_Edit").src="Main/images/edit.png";
			document.getElementById("Demo_Editor_Edit").title="ویرایش ... (Ctrl+Right)";
			
			// reset some styles, as the user may have changed it through using the command /ص[...][...]... the previous time editing a day
			document.getElementById("EditDemo").style.fontFamily="en1, fa1";
			document.getElementById("EditDemo").style.fontSize="90%";
			document.getElementById("EditDemo").style.lineHeight="1.5";
			document.getElementById("EditDemo").style.color="black";
			document.getElementById("EditDemo").style.textShadow="none";
			document.getElementById("EditDemo").style.background="none";
			
			var inputVal=document.getElementById("editDescription").value;
			document.getElementById("EditDemo").innerHTML=
				compile("EditDemo",inputVal)
				+"<br><div id='ftnOnEditDemo' style='display:none;'>"
					+"<br><hr style='width:30%; float:right;'><br>"
					+"<div id='ftnColWrapperOnEditDemo'></div>"
				+"</div>";
			postProcess("EditDemo");
			setCrossReferences("EditDemo");
			/*
			//MathJax.texReset();
			//MathJax.typesetClear();
			MathJax.typeset(["#EditDemo"]);
			//MathJax.typeset();
			//MathJax.startup.document.state(0, true);
			*/
			document.getElementById("EditDemo").innerHTML=document.getElementById("EditDemo").innerHTML
				.replace(/(href\=[\'\"]\#[^\'\"]*[\"\'])/g,"");	// kills all the links inside demo, not to jump out from demo while clicking
			document.getElementById("EditDemo").innerHTML=document.getElementById("EditDemo").innerHTML
				.replace(/از برگه‌ی (\d+|EditDemo)/g, function(x,y){
					//alert(y);
					if(y=="EditDemo"){
						return "از همین برگه";
					}else{
						return "از برگه‌ی "+toFa(y);
					}
				});
			
			// now that processes are finished, it is safe to revert back that page under editting ...
			// it's required, as otherwise if user leave editing with no saved modification, the info in the original page will be lost
			document.getElementById("Page"+pageToBeEdited).innerHTML = pageUnderEditing;
		}
	}
	ViewDemoVar=(ViewDemoVar)? 0 : 1 ;
}






//=================  DELETE AN ALREADY AVAILABLE DAY IN THE BOOK  ==================//



function deletePage(pageNum){
	if(!confirm('با ادامه‌ی این کار، برگه‌ی شماره‌ی «'+toFa(pageNum)+'» حذف می‌شود، آیا با این حال ادامه می‌دهید؟')){
		return false;
	}
	
	
	var pagesCitingThisPage=[];
	for (var day=1, days=myJSONData["days"].length; day<=days; day++) {			//var day in myJSONData["days"]
		if(document.getElementById("Page"+day).innerHTML.indexOf( "jumpToPageContainingPage("+pageNum+")" )!=-1 && day!=pageNum){
			pagesCitingThisPage.push(day);
		}
	}
	if(pagesCitingThisPage.length==0){
		if(!confirm('اگرچه از برگه‌ی دیگری به این برگه ارجاعی داده نشده است، اما آیا همچنان به حذف این برگه اطمینان دارید؟')){
			return false;
		}
	}else if(pagesCitingThisPage.length==1){
		if(!confirm('توجه: از برگه‌ی «'+toFa(pagesCitingThisPage[0])+'» به این برگه ارجاع داده شده است، آیا همچنان به حذف این برگه اطمینان دارید؟')){
			return false;
		}
	}else{
		if(!confirm('توجه: از برگه‌های «'+toFa(pagesCitingThisPage.join("، "))+'» به این برگه ارجاع داده شده است، آیا همچنان به حذف این برگه اطمینان دارید؟')){
			return false;
		}
	}
	
	
	myJSONData.days.splice((pageNum-1), 1);	// deletes the page from the array
	
	
	fillTheBook();
	selectHowMany();
}



//=================  FILL THE WEBPAGE WITH THE DATA ALREADY AQUIRED  ==================//




function changeDirection(){
	myJSONData.start2End = StartToEndVar = (StartToEndVar)? 0 : 1;
	saveToCache();
	
	// to reverse the order of pages in 'container', whatsoever it was previously ...
	// obtained from http://jsfiddle.net/t6q44/5/ (https://stackoverflow.com/a/16919947)
	var parent=document.getElementsByClassName('container')[0],		// strange! using « getElementById("container") » doesn't work here
		divs=parent.children;
	for(var i=divs.length-1; i--; ) {
		parent.appendChild(divs[i]);
	}
	
	selectHowMany();
}

function fillTheBook() {
	var containerContent="";
	finalTagsList=[];
	
	
	if(myJSONData != undefined){
		myJSONData["days"].sort(function(a, b){return a.dateForSortAction - b.dateForSortAction});
	}else{
		return false;
	}
	saveToCache();	// as every change in "myJSONData" will be followed by "fillTheBook()", this is suitable to be placed at here, to always save the latest version of "myJSONData"'s main content in the browser's cache!
	
	
	//var newPage;
	for (var day=1, days=myJSONData["days"].length; day<=days; day++) {			//var day in myJSONData["days"]
		var date=myJSONData["days"][day-1]["weekDay"]
				+" "+toFa(myJSONData["days"][day-1]["year"]
				+"/"+myJSONData["days"][day-1]["month"]
				+"/"+myJSONData["days"][day-1]["day"]),
			tagsHere=myJSONData["days"][day-1]["tags"];
		
		for(var i in tagsHere){
			if(finalTagsList.indexOf(tagsHere[i])==-1){ finalTagsList.push(tagsHere[i]); }
		}
		
		// if "container.innerHTML" was updated here instead, the application was slowed down catastrophically!
		containerContent+=
			'<div class="newpage" id="Page'+day+'" style="width:'+hslider+'; height:'+vslider+'">'
				+'<div class="pageHeader">'
					+'<div style="float:right;">برگه‌ی '+toFa(day)+' (<span style="color:rgb(245,245,220); font-size:95%;">\#'+tagsHere.join(" \#")+'</span>)</div>'
					+'<div>تاریخ: <span style="color:crimson; font-weight:bold;">'+date+'</span>'+myJSONData["days"][day-1]["lastEditDate"]+'</div>'
					+'<span onclick="deletePage('+day+');" class="myButton" title="حذف" style="line-height:25px; font-size:25px; color:Maroon; cursor:pointer; margin:-1px 3px 1px 2px; float:left;">⊠</span>'
					+'<span onclick="editPage('+day+');" class="myButton" title="ویرایش"style="line-height:25px; font-size:25px; color:Sienna; cursor:pointer; margin:1px 0 1px 2px; float:left;">✎</span>'
				+'</div>'
				+'<div id="descriptionOnPage'+day+'" style="text-align: justify; margin-top:5px;"></div>'
			+'</div>';
		
	}
	
	
	container.innerHTML=containerContent;	//should be out of loop, as can incredibly increase load time if pages number exceeds 200 or 300
	
	for (var day=1, days=myJSONData["days"].length; day<=days; day++) {			//var day in myJSONData["days"]
		var description=myJSONData["days"][day-1]["description"];
		ftnNum = refFTN = figNum = videoNum = audioNum = iFrameNum = tblNum = nestedListLevel = 0;
		
		document.getElementById("descriptionOnPage"+day).innerHTML=
				compile("descriptionOnPage"+day, description)
				+"<br><div id='ftnOnPage"+day+"' style='display:none;'>"
					+"<br><hr style='width:30%; float:right;'><br>"
					+"<div id='ftnColWrapperOnPage"+day+"'></div>"
				+"</div>";
		
		postProcess("Page"+day);
	}
	setCrossReferences("container");
	
	for(var day=1, days=myJSONData["days"].length; day<=days; day++) {	//var day in myJSONData["days"]
		document.getElementById('Page'+day).innerHTML=document.getElementById('Page'+day).innerHTML
			.replace(/از برگه‌ی (\d+)/g, function(x,y){
				if(y==day){
					return "از همین برگه";
				}else{
					return "از برگه‌ی "+toFa(y);
				}
			});
	}
	
	
	finalTagsList.sort(function(a, b){return a.localeCompare(b);});
	document.getElementById("tagsList").innerHTML="";
	for(var i=0, l=finalTagsList.length; i<l ; i++){
		document.getElementById("tagsList").innerHTML+='<option value=\"'+finalTagsList[i]+'\">';
	}
	
	
	// to properly set the order of pages from start to end or the reverse ...
	// obtained from http://jsfiddle.net/t6q44/5/ (https://stackoverflow.com/a/16919947)
	var parent=document.getElementsByClassName('container')[0],		// strange! using « getElementById("container") » doesn't work here
		divs=parent.children;
	if(myJSONData["days"].length && StartToEndVar==0){	//to display the pages in reverse order, the last page at top-right of the webpage
		for(var i=divs.length-1; i--; ) {
	   		parent.appendChild(divs[i]);
		}
	}
}
function jumpToPageContainingPage(x){
	// 1 <= x <= myJSONData["days"].length;
	var i = Number(pagesShown.indexOf(x))+1;
	if(StartToEndVar==0){	//pages are displayed in reverse order
		myJSONData.currentPage = currentPage = Math.ceil((pagesShown.length - Number(i) + 1) / selectedPageNumShown);
	}else{
		myJSONData.currentPage = currentPage = Math.ceil(Number(i) / selectedPageNumShown);
	}
	saveToCache();
	
	document.getElementById('goToPage').value=toFa(currentPage)+'\/'+toFa(totalPageNumber);
	
	changePage();
}



//=======  COMPILE & POST-PROCESS & SET CROSS-REFERENCES   ===========


function compile(id,content){
	content=content.replace(/(\n*\/خ\/\n*)/g,"<br>");
	content=parseStyles(content);
	content=parseTables(id,content);
	content=parseFigures(id,content);
	content=parseVideos(id,content);
	content=parseAudios(id,content);
	content=parseiFrames(id,content);
	content=parseFootnotes(id,content);
	content=parseListItems(content);
	content=parseEnvironments(id,content);
	content=parseSymbols(content);
	
	
	content=content
		.replace(/(\n{0,1}\\begin\{align\})/g,"\\begin{align}")			// for better vertical spacing
		.replace(/(\n{0,1}\\begin\{equation\})/g,"\\begin{equation}")	// for better vertical spacing
		.replace(/(\\end\{align\})\n{0,1}/g,"\\end{align}")				// for better vertical spacing
		.replace(/(\\end\{equation\})\n{0,1}/g,"\\end{equation}")		// for better vertical spacing
		
		.replace(/\n/g,"<br>")
		//.replace(/(\<hr[^\>]*\>)(\<br\>)+/g,"$1")
		.replace(/(\<\/[ou]l\>)\<br\>/g,"$1")
		;
	
	
	
	// to take care of lists and nested lists
	while(nestedListLevel){
		content=content
						.replace(/\<\/ol\>(?:\<br\>)?\<ol\>/g,"")
						.replace(/\<\/ul\>(?:\<br\>)?\<ul\>/g,"")
						.replace(/\<\/li\>\<ol\>/g,"\<ol\>")
						.replace(/\<\/li\>\<ul\>/g,"\<ul\>");
		nestedListLevel--;
	}
	
	
	// for THISPAGE specification of font, fontSize, lineHeight, fontColor, & BG
	// use it as /ص[ق: قلم][ا: اندازه][ر: رنگ][س: سایه][ف: فاصله‌ی‌بین‌خطوط][پ: پس‌زمینه]
	// although each [] is optional ...	
	content=content.replace(/(?:\/ص)[ \t\n]*(?:\[ق:[ \t\n]*(ف[۱-۹]|f\d)?[ \t\n]*\])?[ \t\n]*(?:\[ا:[ \t\n]*([٫٬.۰۱۲۳۴۵۶۷۸۹\d]+)[ \t\n]*\])?[ \t\n]*(?:\[ر:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[س:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[ف:[ \t\n]*([\S\s]*?)[ \t\n]*\])?[ \t\n]*(?:\[پ:[ \t\n]*([\S\s]*?)[ \t\n]*\])?/g, function(x,y1,y2,y3,y4,y5,y6){
				var idMod=id.replace(/descriptionOn/,"");
				var page=document.getElementById(idMod);
				if(y1!=undefined){
					y1=y1.replace(/f/,"en").replace(/ف/,"fa")
						.replace(/۱/g,'1').replace(/۲/g,'2').replace(/۳/g,'3')
						.replace(/۴/g,'4').replace(/۵/g,'5').replace(/۶/g,'6')
						.replace(/۷/g,'7').replace(/۸/g,'8').replace(/۹/g,'9');
					switch(y1) {
						case "fa1":
							page.style.fontFamily="en1, fa1";
							break;
						case "fa2":
							page.style.fontFamily="en5, fa2";
							break;
						case "fa3":
							page.style.fontFamily="fa3";
							break;
						case "fa4":
							page.style.fontFamily="en4, fa4";
							break;
						case "fa5":
							page.style.fontFamily="en4, fa5";
							break;
						case "fa6":
							page.style.fontFamily="en2, fa6";
							break;
						case "fa7":
							page.style.fontFamily="en3, fa7";
							break;
						case "fa8":
							page.style.fontFamily="en1, fa8";
							break;
						case "en1":
							page.style.fontFamily="en1";
							break;
						case "en2":
							page.style.fontFamily="en2, fa6";
							break;
						case "en3":
							page.style.fontFamily="en3, fa7";
							break;
						case "en4":
							page.style.fontFamily="en4, fa4";
							break;
						case "en5":
							page.style.fontFamily="en5, fa2";
							break;
						case "en6":
							page.style.fontFamily="en6, fa5";
							break;
						case "en7":
							page.style.fontFamily="en7";
							break;
					}
				}
				if(y2!=undefined){
					page.style.fontSize="calc( 100% *"+toEn(y2)+" )";
				}
				if(y3!=undefined){
					page.style.color=y3;
				}
				if(y4!=undefined){
					page.style.textShadow=y4;
				}
				if(y5!=undefined){
					page.style.lineHeight="calc( 100% *"+toEn(y5)+" )";
				}
				if(y6!=undefined){
					page.style.background=y6;
				}
				return (!y1 && !y2 && !y3 && !y4 && !y5 && !y6)? "/ص" : "";
		})
	
	return content;
}
function parseFootnotes(id,string) {
	return string
		// for capturing footnotes, the source being like (٬٬ text ٬٬)
		.replace(/(?:\(٬٬)((و|چ|وچ|چچ)?([۰۱۲۳۴۵۶۷۸۹\d]*)(?:\[[ \t\n]*(.*?)[ \t\n]*\])?\/)?[ \t\n]*([\s\S]*?)[ \t\n]*(?:٬٬\))/g, function(x,y1,y2,y3,y4,y5){
			var directionPopup="right", directionMainText="justify";
			if(y2){
				switch(y2) {
					case "و":
						directionPopup="center";
						break;
					case "چ":
						directionPopup="left";
						break;
					case "وچ":
						directionPopup="center";
						directionMainText="left";
						break;
					case "چچ":
						directionPopup="left";
						directionMainText="left";
						break;
				}
			}
			var tooltipwidth = (y3)? toEn(y3.replace(/ */g,""))+"px" : "250px";
			var key=(y4)? y4 : "";
			
			ftnNum++;
			//y=parseStyles(y);
			//y=parseTables(id,y);
			//y=parseFigures(id,y);
			//y=parseVideos(id,y);
			//y=parseAudios(id,y);
			//y=parseiFrames(id,y);
			y5=parseListItems(y5);
			y5=parseEnvironments(id,y5);
			//y=parseSymbols(y);
			
			y5=(y1 && !y2 && !y3 && !y4)? "/"+y5 : y5;
			
			var idToCallFor="ftn"+id+"_"+ftnNum;
			//console.log("\""+id+"\", \""+idToCallFor+"\"");
			return "<sup class='tooltip' onmouseover='tooltipRepositionCaller(\""+id+"\", \""+idToCallFor+"\");'>"
					+"<a href='#FTN"+id+"_"+ftnNum+"' id='ftn"+id+"_"+ftnNum+"' style='font-size:90%; color:crimson;' key='"+key+"'>"
						+toFa(ftnNum)
					+"</a>"
					+"<span id='ftn"+id+"_"+ftnNum+"-Hidden' class='tooltipContent bottom' style='text-align:"+directionPopup+"; width:"+tooltipwidth+"' directionMainText='"+directionMainText+"' onmouseout='"
												+"if(this.matches(':hover')){this.style.visibility='visible'; thiis.style.opacity='1';}"
												+"else{setTimeout(function(){this.style.visibility='hidden'; thiis.style.opacity='0';}, 2000);}"
											+"'>"
					+"<span class='tooltipInnerContent'>"+y5+"</span>"
				+"</span>"
			+"</sup>";
		})
		// this one inter-referencing is here to be able to capture the page it resides on
		.replace(/(?:\/پاورقی)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			refFTN++;
			return "<span id='ftnCaller"+refFTN+"' containerID='"+id+"' keyToRefer='"+y+"'></span>"
		});
}
function tooltipRepositionCaller(pageid, id){
	//console.log(pageid+" : "+id);
	var el=document.getElementById(id),
		elTooltip=document.getElementById(id+"-Hidden");
	tooltipReposition(pageid, el , elTooltip);
}
function tooltipReposition(id,el,eltt){
	//console.log(id);
	var tooltipContainer=document.getElementById(id);
			
	
	var relativeLeft= el.getBoundingClientRect().left - tooltipContainer.getBoundingClientRect().left,
		relativeTop= el.getBoundingClientRect().top - tooltipContainer.getBoundingClientRect().top;
	
	var tooltipContainerWidth=tooltipContainer.clientWidth,
		tooltipContainerHeight=tooltipContainer.clientHeight;
	
	
	if(relativeTop <= Math.floor(tooltipContainerHeight/2) && relativeLeft < Math.floor(tooltipContainerWidth/3)){
		eltt.className = "tooltipContent bottomRight";
	}else if(relativeTop <= Math.floor(tooltipContainerHeight/2) && relativeLeft > Math.floor(2*tooltipContainerWidth/3)){
		eltt.className = "tooltipContent bottomLeft";
	}else if(relativeTop <= Math.floor(tooltipContainerHeight/2)){
		eltt.className = "tooltipContent bottom";
	}else if(relativeTop > Math.floor(tooltipContainerHeight/2) && relativeLeft < Math.floor(tooltipContainerWidth/3)){
		eltt.className = "tooltipContent topRight";
	}else if(relativeTop > Math.floor(tooltipContainerHeight/2) && relativeLeft > Math.floor(2*tooltipContainerWidth/3)){
		eltt.className = "tooltipContent topLeft";
	}else{
		eltt.className = "tooltipContent top";
	}
}
function parseTables(id,string) {
	var string=string
			// for capturing "tables" ...
			// [class], [caption] & [key] in   /جدول.ش[key][class][caption]  are all optional ...
			.replace(/(?:\/جدول.ش\/)(?:\[کلید:[ \t]*(.*?)[ \t]*\])?(?:\[کلاس:[ \t]*(.*?)[ \t]*\])?(?:\[\:[ \t\n]*([\S\s]*?)[ \t\n]*\:\])?/g, function(x,y1,y2,y3){
				tblNum++;
				var tblNumPersian=toFa(tblNum.toString());
				if(y3!=undefined){
					//y3=parseStyles(y3);
					//y3=parseTables(id,y3);
					y3=parseFigures(id,y3);
					//y3=parseVideos(id,y3);
					//y3=parseAudios(id,y3);
					//y3=parseiFrames(id,y3);
					//y3=parseFootnotes(id,y3);
					y3=parseListItems(y3);
					y3=parseEnvironments(id,y3);
					//y3=parseSymbols(y3);
				}
				var captionTail=(y3==undefined)?  "</span>"  :  ":</span>  <span class='captionContent'>"+y3+"</span>";
				return "<table id='tbl"+id+"_"+y1+"' tblNumber='"+tblNumPersian+"' class='"+y2+"'>"
						+"<caption>"
							+"<span style='color:crimson;'>جدول "+tblNumPersian+""+captionTail
						+"</caption>";
			})
			// not numbered. not referrable, not increasing the table counter, not having any caption
			.replace(/(?:\/جدول.ش\*\/)(?:\[کلاس:[ \t]*(.*?)[ \t]*\])?/g, "<table class='$1'>")
			
			// to capture each row in the tables
			.replace(/(?:\/ردیف\/)[\t\n\r ]*(.*?)[\t\n\r ]*(?=\/ردیف\/|\/جدول\.پ\/|\r|\n|\t)/g,"<tr>$1</tr>")
			
			// to capture each column in each row, with possible different optional styles for it
			.replace(/(?:\|\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(id,y);
					y=parseFigures(id,y);
					y=parseVideos(id,y);
					y=parseAudios(id,y);
					y=parseiFrames(id,y);
					y=parseFootnotes(id,y);
					y=parseListItems(y);
					y=parseEnvironments(id,y);
					//y=parseSymbols(y);
				}*/
				return "<td>"+y+"</td>";
			})
			.replace(/(?:\|ر\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(id,y);
					y=parseFigures(id,y);
					y=parseVideos(id,y);
					y=parseAudios(id,y);
					y=parseiFrames(id,y);
					y=parseFootnotes(id,y);
					y=parseListItems(y);
					y=parseEnvironments(id,y);
					//y=parseSymbols(y);
				}*/
				return "<td style='text-align:right'>"+y+"</td>";
			})
			.replace(/(?:\|ر.ب\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(id,y);
					y=parseFigures(id,y);
					y=parseVideos(id,y);
					y=parseAudios(id,y);
					y=parseiFrames(id,y);
					y=parseFootnotes(id,y);
					y=parseListItems(y);
					y=parseEnvironments(id,y);
					//y=parseSymbols(y);
				}*/
				return "<td style=\"vertical-align:top; text-align:right;\">"+y+"</td>";
			})
			.replace(/(?:\|ر.پ\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(id,y);
					y=parseFigures(id,y);
					y=parseVideos(id,y);
					y=parseAudios(id,y);
					y=parseiFrames(id,y);
					y=parseFootnotes(id,y);
					y=parseListItems(y);
					y=parseEnvironments(id,y);
					//y=parseSymbols(y);
				}*/
				return "<td style=\"vertical-align:bottom; text-align:right;\">"+y+"</td>";
			})
			.replace(/(?:\|چ\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(id,y);
					y=parseFigures(id,y);
					y=parseVideos(id,y);
					y=parseAudios(id,y);
					y=parseiFrames(id,y);
					y=parseFootnotes(id,y);
					y=parseListItems(y);
					y=parseEnvironments(id,y);
					//y=parseSymbols(y);
				}*/
				return "<td style='text-align:left'>"+y+"</td>";
			})
			.replace(/(?:\|چ.ب\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(id,y);
					y=parseFigures(id,y);
					y=parseVideos(id,y);
					y=parseAudios(id,y);
					y=parseiFrames(id,y);
					y=parseFootnotes(id,y);
					y=parseListItems(y);
					y=parseEnvironments(id,y);
					//y=parseSymbols(y);
				}*/
				return "<td style=\"vertical-align:top; text-align:left;\">"+y+"</td>";
			})
			.replace(/(?:\|چ.پ\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(id,y);
					y=parseFigures(id,y);
					y=parseVideos(id,y);
					y=parseAudios(id,y);
					y=parseiFrames(id,y);
					y=parseFootnotes(id,y);
					y=parseListItems(y);
					y=parseEnvironments(id,y);
					//y=parseSymbols(y);
				}*/
				return "<td style=\"vertical-align:bottom; text-align:left;\">"+y+"</td>";
			})
			.replace(/(?:\|ب\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(id,y);
					y=parseFigures(id,y);
					y=parseVideos(id,y);
					y=parseAudios(id,y);
					y=parseiFrames(id,y);
					y=parseFootnotes(id,y);
					y=parseListItems(y);
					y=parseEnvironments(id,y);
					//y=parseSymbols(y);
				}*/
				return "<td style='vertical-align:top;'>"+y+"</td>";
			})
			.replace(/(?:\|پ\|)([^\|\r\n\t]*)/g, function(x,y){
				/*if(y!=undefined){
					//y=parseStyles(y);
					//y=parseTables(id,y);
					y=parseFigures(id,y);
					y=parseVideos(id,y);
					y=parseAudios(id,y);
					y=parseiFrames(id,y);
					y=parseFootnotes(id,y);
					y=parseListItems(y);
					y=parseEnvironments(id,y);
					//y=parseSymbols(y);
				}*/
				return "<td style='vertical-align:bottom;'>"+y+"</td>";
			})
			
			.replace(/[ \t\n]*(?:\/جدول.پ\/)/g,"</table>")	// to end the tables;
	return string;
}
function parseStyles(string) {
	var string=string
			// for capturing new styles defined by the user, to be considered as lying in the header of the HTML file
			.replace(/(\/استایل\/)[ \t\n]*(?=\S)([^\r]*?\S[*_]*)[ \t\n]*\1/g,  function(x,y1,y2){
				var style = document.createElement('style');
				style.type = 'text/css';
				style.innerHTML = y2;
				document.getElementsByTagName('head')[0].appendChild(style);
				
				//document.body.appendChild(style);
				/*
				if (style.styleSheet) style.styleSheet.cssText = y2;				// Supports IE
				else style.appendChild(document.createTextNode(y2));			// Supports the rest
				document.getElementsByTagName("head")[0].appendChild(style);	// where to place the style
				*/
				return "";		// if it was not added, an "undefined" text was written in its place!
			});
	return string;
}
function parseFigures(id,string) {
	var string=string
			//for capturing INLINE figures ...
			//use as  /شکل*{folder/image.gif}[300:200][چب۱٫۵]
			.replace(/(?:\/شکل\*[ \t]*)(?:\{[ \t]*([^\}]*)[ \t]*\})(?:[ \t]*\[[ \t]*([*\d]+[A-Za-z%]{0,4})?[ \t]*\:[ \t]*([*\d]+[A-Za-z%]{0,4})?[ \t]*\])?(?:\[([روچ])?([بوپ])?([٫٬.۰۱۲۳۴۵۶۷۸۹\d]+)\])?/g, function(x,y1,y2,y3,y4,y5,y6){
				var figWidth=(y2!=undefined)? y2 : "*" ;
				var figHeight=(y3!=undefined)? y3 : "*" ;
				var s="";
				if(y6!=undefined){
					var scale = toEn(y6);
					var originX="center", originY="center";
					if(y4!=undefined){
						switch(y4){
							case "ر":
								originX ="right";
								break;
							/*case "و":
								//originX = "center";
								break;*/
							case "چ":
								originX ="left";
								break;
							/*default:
								originX = "center";*/
						}
					}
					if(y5!=undefined){
						switch(y5){
							case "ب":
								originY ="top";
								break;
							/*case "و":
								originY = "center";
								break;*/
							case "پ":
								originY ="bottom";
								break;
							/*default:
								originY = "center";*/
						}
					}
					s = "onmouseover= ' "
							+"this.style.transformOrigin = \""+originX+" "+originY+"\"; "
							+"this.style.transform = \"scale("+scale+")\";"
						+" '"
						+" onmouseout= ' this.style.transform = \"none\"; '";
				}
				return "<img src='"+y1+"' width='"+figWidth+"' height='"+figHeight+"' style='margin-bottom:"+(-figHeight/2+5)+"px;' "+s+">";
			})

			//for capturing NUMBERED figures ...
			//use as  /شکل{folder/image.gif}[300:200][: توضیحات شکل که زیر آن نوشته میشود:][کلید: کلیدواژه برای ارجاع به آن][عنوان شکل]
			.replace(/(?:\/شکل[ \t]*)(?:\{[ \t]*([^ک][^\}]*)[ \t]*\})(?:[ \t]*\[[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\:[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\])?[ \t\n]*(?:\[([روچ])?([بوپ])?([٫٬.۰۱۲۳۴۵۶۷۸۹\d]+)\])?[ \t\n]*(?:\[\:[ \t\n]*([\S\s]*?)[ \t\n]*\:\])?[ \t\n]*(?:\[[ \t]*کلید\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([^\]]*)[ \t]*\])?/g, function(x,y1,y2,y3,y4,y5,y6,y7,y8,y9){
				figNum++;
				var figNumPersian=toFa(figNum.toString());var figWidth=(y2!=undefined)? y2 : "*" ;
				var figHeight=(y3!=undefined)? y3 : "*" ;
				var s="";
				if(y6!=undefined){
					var scale = toEn(y6);
					var originX="center", originY="center";
					if(y4!=undefined){
						switch(y4){
							case "ر":
								originX ="right";
								break;
							/*case "و":
								//originX = "center";
								break;*/
							case "چ":
								originX ="left";
								break;
							/*default:
								originX = "center";*/
						}
					}
					if(y5!=undefined){
						switch(y5){
							case "ب":
								originY ="top";
								break;
							/*case "و":
								originY = "center";
								break;*/
							case "پ":
								originY ="bottom";
								break;
							/*default:
								originY = "center";*/
						}
					}
					s = "onmouseover= ' "
							+"this.style.transformOrigin = \""+originX+" "+originY+"\"; "
							+"this.style.transform = \"scale("+scale+")\";"
						+" '"
						+" onmouseout= ' this.style.transform = \"none\"; '";
				}
				if(y7!=undefined){
					//y7=parseStyles(y7);
					//y7=parseTables(id,y7);
					//y7=parseFigures(id,y7);
					//y7=parseVideos(id,y7);
					//y7=parseAudios(id,y7);
					//y7=parseiFrames(id,y7);
					//y7=parseFootnotes(id,y7);
					y7=parseListItems(y7);
					y7=parseEnvironments(id,y7);
					//y7=parseSymbols(y7);
				}
				var captionTail=(y7==undefined)?  "</span>"  :  ":</span> <span class='captionContent'>"+y7+"</span>" ;
				var figID=(y8!=undefined)? " id='fig"+id+"_"+y8+"' " : " " ;
				var figTitle=(y9!=undefined)? " title='"+y9+"' " : " " ;
				return "<figure style='text-align:center; align-content:center; margin:auto;'>"
						+"<img"+figID+"figNumber='"+figNumPersian+"' src='"+y1+"' width='"+figWidth+"' height='"+figHeight+"' "+s+figTitle+">"
						+"<figcaption>"
							+"<span style='color:crimson;'>شکل "+figNumPersian+captionTail
						+"</figcaption>"
					+"</figure>";
			});
	return string;
}
function parseVideos(id,string) {
	var string=string
			//for capturing videos ...
			//use as	/فیلم{"folder/video.mp4" "folder/video.webm"}[زیرنویس: "folder/subtitle1.vtt?en" "folder/subtitle2.vtt?fa"][320:240][: توضیحات فیلم که در زیر آن نوشته میشود:][کلید: کلیدواژه برای ارجاع به آن][عنوان فیلم]
			.replace(/(?:\/فیلم[ \t]*)(?:\{[ \t]*([^ک][^\}]*)\})[ \t]*(?:\[[ \t]*زیرنویس\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\:[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\])?[ \t\n]*(?:\[\:[ \t\n]*([\S\s]*?)[ \t\n]*\:\])?[ \t\n]*(?:\[[ \t]*کلید\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([^\]]*)\])?/g, function(x,y1,y2,y3,y4,y5,y6,y7){
				videoNum++;
				var videoNumPersian=toFa(videoNum.toString());
				var sources=y1.replace(/(\"[^\"]*\")/g,"<source src=$1>");
				var subtitles=(y2==undefined)? "" : y2.replace(/(?:\"([^\?]*)\?([^\"]*)\")/g,"<track src\=\"$1\" srclang\=\"$2\" label\=\"$2\" default>");
				if(y5!=undefined){
					//y5=parseStyles(y5);
					//y5=parseTables(id,y5);
					//y5=parseFigures(id,y5);
					//y5=parseVideos(id,y5);
					//y5=parseAudios(id,y5);
					//y5=parseiFrames(id,y5);
					//y5=parseFootnotes(id,y5);
					y5=parseListItems(y5);
					y5=parseEnvironments(id,y5);
					//y5=parseSymbols(y5);
				}
				var captionTail=(y5==undefined)?  "</span>"  :  ":</span>  <span class='captionContent'>"+y5+"</span>";
				var divWidth=(y3==undefined)? "" : (y3.indexOf("\%")!=-1 || y3.indexOf("٪")!=-1 || y3.indexOf("px")!=-1)? "style='width:"+y3.replace(/٪/,"%")+"!important;" :	 "style='width:"+y3+"px!important;";
				var videoWidth=(y3!=undefined)? " width='"+y3+"' " : "" ;
				var videoHeight=(y4!=undefined)? " height='"+y4+"' " : "" ;
				return "<div class=\"videoContainer\" "+divWidth+" '>"
						+"<video id='video"+id+"_"+y6+"' videoNumber='"+videoNumPersian+"' "+ videoWidth + videoHeight +" title='"+y7+"' controls>"
							+sources
							+subtitles
						+"مرورگر شما از HTML5 video پشتیبانی نمی‌کند."
						+"</video>"
						+"<br><span style=\"font-size:90%!important;\"><span style='color:crimson;'>فیلم "+videoNumPersian+""+captionTail+"</span>"
					+"</div>";
			});
	return string;
}
function parseAudios(id,string) {
	var string=string
			//for capturing audios ...
			//use as	/صوت{"folder/audio.ogg" "folder/audio.mp3"}[400][: توضیحات صوتی که در زیر آن نوشته میشود:][کلید: کلیدواژه برای ارجاع به آن][عنوان صوت]
			.replace(/(?:\/صوت[ \t]*)(?:\{[ \t]*([^ک][^\}]*)\})[ \t]*(?:\[[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\])?[ \t\n]*(?:\[\:[ \t\n]*([\S\s]*?)[ \t\n]*\:\])?[ \t\n]*(?:\[[ \t]*کلید\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([^\]]*)\])?/g, function(x,y1,y2,y3,y4,y5){
				audioNum++;
				var audioNumPersian=toFa(audioNum.toString());
				var sources=y1.replace(/(\"[^\"]*\")/g,"<source src=$1>");
				if(y3!=undefined){
					//y3=parseStyles(y3);
					//y3=parseTables(id,y3);
					//y3=parseFigures(id,y3);
					//y3=parseVideos(id,y3);
					//y3=parseAudios(id,y3);
					//y3=parseiFrames(id,y3);
					//y3=parseFootnotes(id,y3);
					y3=parseListItems(y3);
					y3=parseEnvironments(id,y3);
					//y3=parseSymbols(y3);
				}
				var captionTail=(y3==undefined)?  "</span>"  :  ":</span>  <span class='captionContent'>"+y3+"</span>" ;
				var divWidth=(y2==undefined)? "" : (y2.indexOf("\%")!=-1 || y2.indexOf("٪")!=-1 || y2.indexOf("px")!=-1)? y2.replace(/٪/,"%") : y2+"px";
				return "<div class=\"audioContainer\" style='width:"+divWidth+"!important;'>"
						+"<audio id='audio"+id+"_"+y4+"' audioNumber='"+audioNumPersian+"' style='width:"+divWidth+"!important;' title='"+y5+"' controls>"
							+sources
						+"مرورگر شما از HTML5 audio پشتیبانی نمی‌کند."
						+"</audio>"
						+"<br><span style=\"font-size:90%!important;\"><span style='color:crimson;'>صوت "+audioNumPersian+""+captionTail+"</span>"
					+"</div>";
			});
	return string;
}
function parseiFrames(id,string) {
	var string=string
			//for capturing (interactive) iFrames ...
			//use as  /پنجره{folder/iFrame.html}[320:240][: توضیحات پنجره که در زیر آن نوشته میشود:][کلید: کلیدواژه برای ارجاع به آن]
			.replace(/(?:\/پنجره[ \t]*)(?:\{[ \t]*([^ک][^\}]*)[ \t]*\})(?:[ \t]*\[[ \t]*(\d+)?[ \t]*\:[ \t]*(\d+)?[ \t]*(?:\-[ \t]*([\.\d]+)?[ \t]*)?[ \t]*\])?[ \t\n]*(?:\[\:[ \t\n]*([\S\s]*?)[ \t\n]*\:\])?[ \t\n]*(?:\[[ \t]*کلید\:[ \t]*([^\]]*)\])?/g, function(x,y1,y2,y3,y4,y5,y6){
				iFrameNum++;
				var iFrameNumPersian=toFa(iFrameNum.toString());
				
				var iFrameWidth=(y2!=undefined)? y2 : "500" ;
				var iFrameHeight=(y3!=undefined)? y3 : "500" ;
				var zoom=(y4!=undefined)?  (y4*1.0)  :  1.0  ;
				//var iFramePadding=" calc( ( "+zoom+" - 1.0 ) * 0.5 * "+ iFrameWidth +")";
				
				var iFrameStyle=" style=\""
										+"width:"+ (iFrameWidth / zoom) +"px; "
										+"height:"+ (iFrameHeight / zoom) +"px; "
										+"transform: scale("+zoom+"); "
										+"transform-origin: right bottom; "
										+"margin-left: "+ ((zoom - 1.0) * iFrameWidth / zoom) +"px; "
										+"margin-top: "+ ((zoom - 1.0) * iFrameHeight / zoom) +"px;"
									+"\" ";
				
				var scrollTo=" onload=\""
									+"this.contentWindow.document.documentElement.scrollLeft="
											+"this.contentWindow.document.documentElement.scrollWidth / 3; "
									+"this.contentWindow.document.documentElement.scrollTop="
											+"this.contentWindow.document.documentElement.scrollHeight / 3; "
								+"\" ";
				
				if(y5!=undefined){
					//y5=parseStyles(y5);
					//y5=parseTables(id,y5);
					//y5=parseFigures(id,y5);
					//y5=parseVideos(id,y5);
					//y5=parseAudios(id,y5);
					//y5=parseiFrames(id,y5);
					//y5=parseFootnotes(id,y5);
					y5=parseListItems(y5);
					y5=parseEnvironments(id,y5);
					//y5=parseSymbols(y5);
				}
				var captionTail=(y5==undefined)?  "</span>"  :  ":</span> <span class='captionContent'>"+y5+"</span>" ;
				var iFrameID=(y6!=undefined)? " id='iFrame"+id+"_"+y6+"' " : "" ;
				return "<div class=\"iFrameContainer\">"
						+"<iframe src='"+y1+"' class=\"iFrame\" "
							+ iFrameStyle + scrollTo + iFrameID
							+"iFrameNumber='"+iFrameNumPersian+"'>"
						+"</iframe>"
						+"<br>"
						+"<span style=\"font-size:90%!important;\"><span style='color:crimson;'>پنجره‌ی "
							+ iFrameNumPersian + captionTail
						+"</span>"
					+"</div>";
			});
	return string;
}
function parseListItems(string) {
	var string=string
			//	*	+	**	++[✍]	*+*	....
			.replace(/^[ \t]*(\+|\*)(.*)$/gm, function(x,y2,y3){
				var i=1;	if(i > nestedListLevel){nestedListLevel=i;}
				y3=(y2=="+")? "<ol><li>"+y3+"</li></ol>" : "<ul><li>"+y3+"</li></ul>";
				var temp=1, yt=y3, ytt="";
				while(temp){
					ytt=yt	.replace(/\<li\>(?:\+)[ \t]*(.+)\<\/li\>/, "<ol><li>$1</li></ol>")
							.replace(/\<li\>(?:\*)[ \t]*(.+)\<\/li\>/, "<ul><li>$1</li></ul>");
					if(ytt==yt){
						temp=0;		// so the loop is terminated
						i--;
						
						// to let change the bullet fot this item and its following of the same level
						ytt=ytt.replace(/(?:\<ul\>\<li\>)(?:\[(.*)\])?/, function(x,y){
							return (y!=undefined)? "<ul style='list-style:\" "+y+" \" outside;'><li>" : "<ul><li>";
						});
					}
					yt=ytt;
					i++; if(i > nestedListLevel){nestedListLevel=i;}
				}
				//console.log(yt);
				return yt;
			});
	return string;
}
function parseEnvironments(id,string) {
	var string=string
			.replace(/(\/ن\/)[ \t\n]*([\S\s]*?)[ \t\n]*\1/g,"<blockquote>$2</blockquote>")
			
			.replace(/(?:\/چند.س([۰۱۲۳۴۵۶۷۸۹\d]+)?\/)[ \t\n]*([\S\s]*?)[ \t\n]*(?:\/چند.س\/)/g, function(x,y1,y2){
				var width = (y1==undefined)? "400px" : toEn(y1.replace(/px/,""))+"px";
				return "<div style='column-count:auto; column-width:"+width+"; column-gap:40px;'>"+y2+"</div>";
			})
			
			.replace(/(?:\/قاب)(?:\[([۰۱۲۳۴۵۶۷۸۹\d]+[٪\%]?(?:px)?)?([آقسزخط]?)\])?(?:[ \t\n]*\[[ \t\n]*([^\n]+?)[ \t\n]*\][ \t\n]*)?(?:\/)[ \t\n]*([\s\S]*?)[ \t\n]*(?:\/قاب\/)/g, function(x,y1,y2,y3,y4){
				var width=(y1==undefined)? "80%" 
						: (y1.indexOf("\%")!=-1 || y1.indexOf("٪")!=-1)? toEn(y1.replace(/[٪\%]/,""))+"%"
						: toEn(y1.replace(/(?:px)/,""))+"px";
				var colorBG, colorTitleBG; //ColorText="black";
				switch(y2){
					case "آ":
						colorBG="rgba(0,191,255,0.4)";
						colorTitleBG="rgba(30,144,255,0.4)";
						//ColorText="black";
						break;
					case "ق":
						colorBG="rgba(255,0,90,0.3)";
						colorTitleBG="rgba(255,0,90,0.5)";
						//ColorText="black";
						break;
					case "س":
						colorBG="rgba(154,205,50, 0.5)";
						colorTitleBG="rgba(50,205,50, 0.5)";
						//ColorText="black";
						break;
					case "ز":
						colorBG="rgba(255,255,0,0.5)";
						colorTitleBG="rgba(255,195,16,0.5)";
						//ColorText="black";
						break;
					case "ط":
						colorBG="rgba(255,215,0,0.5)";
						colorTitleBG="rgba(218,165,32,0.5)";
						//ColorText="black";
						break;
					case "خ":
						colorBG="rgba(200, 200, 200,0.5)";
						colorTitleBG="rgba(180,180,180,0.5)";
						//ColorText= "black";
						break;
					default:
						colorBG="rgba(255, 255, 255, 0.2)";
						colorTitleBG="rgba(255, 255, 255, 0.1)";
						//ColorText="black";
				}
				var headerTitle, headerTitleDisplay="";
				if(y3==undefined || y3=="|"){
					headerTitle="";
					headerTitleDisplay="none";
				}else{
					headerTitle=y3.replace(/\|/,"");
				}
				return "<div style='margin:auto; width:"+width+"; background-color:"+colorBG+"; border-radius:10px;'>"
						+"<div style='display:"+headerTitleDisplay+"; width:100%; background-color:"+colorTitleBG+"; border-radius:10px 10px 0 0; padding:10px; font-size:120%;'>"
							+headerTitle
						+"</div>"
						+"<div style='padding:10px;'>"+y4+"</div>"
					+"</div>";
			})
			
			.replace(/(\/ی\/)[ \t]*([\s\S]*?)[ \t]*\1/g,"<!-- $2 -->")
			
			
			// for capturing "headings" in three levels "h1", "h2" ... to ... "h6"
			.replace(/(?:\/=۱\/)(?:\[[ \t]*([^\]]*)[ \t]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h1' key='"+key+"'>"
							+y2
						+"</div>";
			})
			.replace(/(?:\/=۲\/)(?:\[[ \t\n]*(.*)[ \t\n]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h2' key='"+key+"'>"
							+y2
						+"</div>";
			})
			.replace(/(?:\/=۳\/)(?:\[[ \t\n]*(.*)[ \t\n]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h3' key='"+key+"'>"
							+y2
						+"</div>";
			})
			.replace(/(?:\/=۴\/)(?:\[[ \t]*([^\]]*)[ \t]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h4' key='"+key+"'>"
							+y2
						+"</div>";
			})
			.replace(/(?:\/=۵\/)(?:\[[ \t\n]*(.*)[ \t\n]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h5' key='"+key+"'>"
							+y2
						+"</div>";
			})
			.replace(/(?:\/=۶\/)(?:\[[ \t\n]*(.*)[ \t\n]*\])?[ \t]*(.+)[ \t]*/g, function(x,y1,y2){
				var key=(y1!=undefined)? y1 : "";
				return "<div class='header' kind='h6' key='"+key+"'>"
							+y2
						+"</div>";
			})
			
			
			
			//for capturing links ...   //use as   /لینک{متن}{http://www.address.com}[عنوان]
			.replace(/(?:\/لینک)(?:\{[ \t]*([^\}]*)[ \t]*\})[ \t]*(?:\{[ \t]*([^\}]*)[ \t]*\})[ \t]*(?:\[([^\]]*)\])?/g,"<a href='$2' title='$3'>$1</a>")
			//for capturing email links ...
			.replace(/(?:\/ایمیل)(?:\{[ \t]*([^\}]*)[ \t]*\})/g,"<a href='mailto:$1'>$1</a>")   //use as   /ایمیل{aaaa_bbbb@ccc.ir}
			
			// to generate "لنگرگاه" everywhere the user will refer to later ... 	//use as   /لنگرگاه{key}
			.replace(/(?:\/لنگرگاه)(?:\{[ \t]*(.*?)[ \t]*\})/g, "<span id='anchor"+id+"_$1'></span>")
			
			
			// Bold, Italic, Underline, Linetrough, ...
			.replace(/(\×\×)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<strong>$2</strong>")
			.replace(/(\×)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<em>$2</em>")
			.replace(/(\/ـ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<u>$2</u>")
			.replace(/(\/-\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<s>$2</s>")
					
			.replace(/(\/،\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<sub>$2</sub>")
			.replace(/(\/٬\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<sup>$2</sup>")
			
			.replace(/(\/ق\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(220,20,60)'>$2</span>")
			.replace(/(\/آ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(0,0,139)'>$2</span>")
			.replace(/(\/س\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:darkgreen'>$2</span>")
			.replace(/(\/ط\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(189,158,85)'>$2</span>")
			
			.replace(/(\/زرد\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='background-color:yellow'>$2</span>")
			.replace(/(\/سبز\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='background-color:lime'>$2</span>")
			
			.replace(/(\/ف۱\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en1, fa1; font-size:100%;'>$2</span>")
			.replace(/(\/ف۲\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en5, fa2; font-size:105%;'>$2</span>")
			.replace(/(\/ف۳\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:fa3; font-size:110%;'>$2</span>")
			.replace(/(\/ف۴\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en4, fa4; font-size:130%;'>$2</span>")
			.replace(/(\/ف۵\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en4, fa5; font-size:150%; line-height:120%;'>$2</span>")
			.replace(/(\/ف۶\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en2, fa6; font-size:140%; line-height:190%;'>$2</span>")
			.replace(/(\/ف۷\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en3, fa7; font-size:100%;'>$2</span>")
			.replace(/(\/ف۸\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en1, fa8; font-size:170%;'>$2</span>")
			.replace(/(\/f1\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en1; font-size:100%;'>$2</span>")
			.replace(/(\/f2\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en2, fa6; font-size:170%; line-height:140%;'>$2</span>")
			.replace(/(\/f3\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en3, fa7; font-size:100%;'>$2</span>")
			.replace(/(\/f4\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en4, fa4; font-size:140%;'>$2</span>")
			.replace(/(\/f5\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en5, fa2; font-size:130%;'>$2</span>")
			.replace(/(\/f6\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en6, fa5; font-size:120%;'>$2</span>")
			.replace(/(\/f7\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en7; font-size:120%;'>$2</span>")
			.replace(/(\/f8\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:en8; font-size:140%;'>$2</span>")
			
			.replace(/(\/قرآن\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:fa3; font-size:110%; color:rgb(34,139,34); text-shadow:2px 2px 4px white;'>$2</span>")
			.replace(/(\/حدیث\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:fa2; font-size:97%; color:rgb(65,105,225); text-shadow:2px 2px 4px white;'>$2</span>")
			.replace(/(\/ترجمه\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:fa7; font-size:90%; color:rgb(205,92,92); text-shadow:2px 2px 4px white;'>$2</span>")
			
			
			.replace(/(?:\/ب([٫٬.۰۱۲۳۴۵۶۷۸۹\d]+)\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\/ب\//g, function(x,y1,y2){
				return "<span style='font-size:calc( 100% *"+toEn(y1)+" );'>"+y2+"</span>";
			})
			
			
			.replace(/(\/چ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span class='blink'> $2 </span>")
			.replace(/(\/\+\-\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span class='growShrink'> $2 </span>")
			.replace(/(\/\@\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g, "<span class='vibrotate'>$2</span>")
			.replace(/(\/\@\-\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g, function(x,y1,y2){	// to rotate, word by word
				y2=y2.replace(/([^\s\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+|[\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+)/g,
								"<span class='vibrotate'>$1</span>");
				return y2;
			})
			.replace(/(\/\^\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span class='alert'> $2 </span>")
			
			
			
			// font coloring: transparent font on a colorful background
			.replace(/(?:\/ر([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/ر\/)/g,"<span class='colorfulFontBG-$1'> $2 </span>")
			.replace(/(?:\/رر([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/رر\/)/g,"<span class='colorfulFontBG-$1 Anim'> $2 </span>")
			// font coloring: word by word
			.replace(/(?:\/رـ([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/رـ\/)/g, function(x,y1,y2){
				y2=y2.replace(/\$[^\$]+\$|\<[^\>]+\>|([^\s\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+|[\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+)/g, function(x,z){
					if(!z){return x;}else{return "<span>"+z+"</span>";}
				});
				return "<span class='colorfulFont-"+y1+"'>"+y2+"</span>";
			})
			.replace(/(?:\/ررـ([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/ررـ\/)/g, function(x,y1,y2){
				y2=y2.replace(/\$[^\$]+\$|\<[^\>]+\>|([^\s\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+|[\.\,\;\:\"\'\?\`\!\(\)\{\}\[\]،؛]+)/g,function(x,z){
					if(!z){return x;}else{return "<span>"+z+"</span>";}
				});
				return "<span class='colorfulFontAnim-"+y1+"'>"+y2+"</span>";
			})
			// font coloring: char by char
			.replace(/(?:\/ر-([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/ر-\/)/g, function(x,y1,y2){
				y2=y2.replace(/\$[^\$]+\$|\<[^\>]+\>|(\s|\S)/g,function(x,z){
					if(!z){return x;}else{return "<span>"+z+"</span>";}
				});
				return "<span class='colorfulFont-"+y1+"'>"+y2+"</span>";
			})
			.replace(/(?:\/رر-([۱۲۳])\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*(?:\/رر-\/)/g, function(x,y1,y2){
				y2=y2.replace(/\$[^\$]+\$|\<[^\>]+\>|(\s|\S)/g,function(x,z){
					if(!z){return x;}else{return "<span>"+z+"</span>";}
				});
				return "<span class='colorfulFontAnim-"+y1+"'>"+y2+"</span>";
			})
			
			
			
			
			.replace(/(?:\/بلوک([۰۱۲۳۴۵۶۷۸۹\d]+[\%٪]?)?\{)(?:[ \t\n]*([+-]?[۰۱۲۳۴۵۶۷۸۹\d]+(?:px)?|[بپو])\|)?[ \t\n]*([\s\S]*?)[ \t\n]*(?:\})/g, function(x,y1,y2,y3){
				var width=(y1==undefined)? "300px" 
						: (y1.indexOf("\%")!=-1 || y1.indexOf("٪")!=-1)? toEn(y1.replace(/[٪\%]/,""))+"%"
						: toEn(y1.replace(/px/,""))+"px";
				var vposition=(y2==undefined)? "middle"
						: (y2.indexOf("ب")!=-1)? "bottom"
						: (y2.indexOf("و")!=-1)? "middle"
						: (y2.indexOf("پ")!=-1)? "top"
						: toEn(y2.replace(/px/,""))+"px";
				//alert(width+" ; "+vposition);
				return "<div style='display:inline-block; max-width:"+width+"; vertical-align:"+vposition+";'>"+y3+"</div>";
			})
			
			.replace(/^[ \t]*(---)[ \t]*$/gm,"<hr>")
			.replace(/^[ \t]*(===)[ \t]*$/gm,"<hr style='border:0px; border-top:5px double #8c8c8c;'>")
			
			.replace(/[ \t]*\n{0,1}(\/=.\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:left; margin:0;'>$2</p>")
			.replace(/[ \t]*\n{0,1}(\/.=\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:right; margin:0;'>$2</p>")
			.replace(/[ \t]*\n{0,1}(\/=.=\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:center; margin:0;'>$2</p>")
			
			.replace(/(\/ltr\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span dir='ltr'>$2</span>")
			.replace(/[ \t]*\n{0,1}(\/ltrp\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p dir='ltr' style='text-align:justify;'>$2</p>")
			
			
			.replace(/(?:\/پ([۰۱۲۳۴۵۶۷۸۹\d\-\+]+)(\%|\٪)?\/)/g, function(x,y1,y2){
				var inEn=toEn(y1);
				var marginTop = (y2!=undefined)? inEn+"vh" : inEn+"px";
				return "<div style='display:block!important; margin-top:"+marginTop+";'></div>";
			})
			.replace(/(?:\/ج([۰۱۲۳۴۵۶۷۸۹\d\-\+]+)\/)/g, function(x,y){
				return " <span style='margin-right:"+toEn(y)+"px;'></span>";
			})
			
			.replace(/(?:\/ج\/)(.+?\n)/g, function(x,y){
				var temp=1, yt=y, ytt="";
				while(temp){
					ytt=yt.replace(/(?:\/ج\/)(.+?\n)/g, "<div style='margin:0 40px 0 0;'>$1</div>");
					if(ytt==yt){temp=0;}
					yt=ytt;
				}
				return "<div style='margin:0 40px 0 0;'>"+ytt+"</div>";
			})
			.replace(/(?:\/ع\/)(.+?\n)/g, function(x,y){
				var temp=1, yt=y, ytt="";
				while(temp){
					ytt=yt.replace(/(?:\/ع\/)(.+?\n)/g, "<div style='position:relative; margin:0 -40px 0 0;'>$1</div>");
					if(ytt==yt){temp=0;}
					yt=ytt;
				}
				return "<div style='position:relative; margin:0 -40px 0 0;'>"+ytt+"</div>";
			})
			
			
			
			
			
			
			.replace(/٪٪[ \t\n]*([\s\S]*?)[ \t\n]*٪٪/g,"<pre dir='ltr'><code style='background:none;'>$1</code></pre>")  //"<pre><code>$1</code></pre>" this enters code in a newline
			.replace(/٪(.*?)٪/g,"<code dir='ltr'>$1</code>")  //"<pre><code>$1</code></pre>" this enters code in a newline
			
			.replace(/\%/g,"%")
			.replace(/\/\%/g,"٪")
			;
	return string;
}
function parseSymbols(string) {
	var string=string
			.replace(/(\(بسمله\))/g,"<span style='font-family:fa5; font-size:140%;'>‌بِسْــمِ <span style='color:rgb(220,20,60)'>اللَّـهِ</span> الرَّحْمـٰنِ الرَّحِيمِ</span>")
			.replace(/(\(بسمله۱\))/g,"<span style='font-family:sardar;'>‌ا</span>")
			.replace(/(\(بسمله۲\))/g,"<span style='font-family:sardar;'>‌ب</span>")
			.replace(/(\(بسمله۳\))/g,"<span style='font-family:sardar;'>‌پ</span>")
			.replace(/(\(بسمله۴\))/g,"<span style='font-family:sardar;'>‌ت</span>")
			.replace(/(\(بسمله۵\))/g,"<span style='font-family:sardar;'>‌ث</span>")
			
			.replace(/(\(جل\*\))/g,"<span style='font-family:fa4'>«جَلَّ‌جَلالُه»</span>")
			.replace(/(\(جل\))/g,"<span style='font-family:sardar'>ح</span>")
			
			.replace(/(\(ص\*\))/g,"<span style='font-family:fa4'>«صَلَّی‌اللّه‌ُعَلَیْه‌ِوَآلِه»</span>")
			.replace(/(\(ص\))/g,"<span style='font-family:sardar'>ج</span>")
			.replace(/(\(ص\-\))/g,"<span style='font-family:sardar'>ط</span>")
			
			.replace(/(\(علیه\*\))/g,"<span style='font-family:fa4'>«عَلَیْه‌ِالسَّلام»</span>")
			.replace(/(\(علیه\))/g,"<span style='font-family:sardar'>خ</span>")
			
			.replace(/(\(علیها\*\))/g,"<span style='font-family:fa4'>«عَلَیْهاالسَّلام»</span>")
			.replace(/(\(علیها\))/g,"<span style='font-family:sardar'>د</span>")
			
			.replace(/(\(علیهما\*\))/g,"<span style='font-family:fa4'>«عَلَیْهِماالسَّلام»</span>")
			.replace(/(\(علیهما\))/g,"<span style='font-family:sardar'>ذ</span>")
			
			.replace(/(\(علیهم\*\))/g,"<span style='font-family:fa4'>«عَلَیْهِم‌ُالسَّلام»</span>")
			.replace(/(\(علیهم\))/g,"<span style='font-family:sardar'>ر</span>")
			
			.replace(/(\(عج\*\))/g,"<span style='font-family:fa4'>«عَجّ‌َاللّه‌ُفَرَجَه‌ُالشَّریف»</span>")
			.replace(/(\(عج\))/g,"<span style='font-family:sardar'>ظ</span>")
			.replace(/(\(عج\-\))/g,"<span style='font-family:sardar'>ی</span>")
			
			.replace(/(\(رحمه\*\))/g,"<span style='font-family:fa4'>«رَحِمَه‌ُاللّه»</span>")
			.replace(/(\(رحمه\))/g,"<span style='font-family:sardar'>ز</span>")
			
			.replace(/(\(رحمها\*\))/g,"<span style='font-family:fa4'>«رَحِمَهااللّه»</span>")
			.replace(/(\(رحمها\))/g,"<span style='font-family:sardar'>س</span>")
			
			.replace(/(\(رحمهما\*\))/g,"<span style='font-family:fa4'>«رَحِمَهُمااللّه»</span>")
			.replace(/(\(رحمهما\))/g,"<span style='font-family:sardar'>ش</span>")
			
			.replace(/(\(رحمهم\*\))/g,"<span style='font-family:fa4'>«رَحِمَهُم‌ُاللّه»</span>")
			.replace(/(\(رحمهم\))/g,"<span style='font-family:sardar'>ص</span>")
		
		// شکلک‌ها (smiley)
			.replace(/(\/ش۱\/)/g, "<img src='Main/images/smiley/1.gif' style='margin-bottom:-3px;'>")	
			.replace(/(\/ش۲\/)/g, "<img src='Main/images/smiley/2.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۳\/)/g, "<img src='Main/images/smiley/3.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۴\/)/g, "<img src='Main/images/smiley/4.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵\/)/g, "<img src='Main/images/smiley/5.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۶\/)/g, "<img src='Main/images/smiley/6.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۷\/)/g, "<img src='Main/images/smiley/7.gif' style='margin-bottom:-7px;'>")
			.replace(/(\/ش۸\/)/g, "<img src='Main/images/smiley/8.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۹\/)/g, "<img src='Main/images/smiley/9.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۱۰\/)/g,"<img src='Main/images/smiley/10.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۱۱\/)/g,"<img src='Main/images/smiley/11.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۱۲\/)/g,"<img src='Main/images/smiley/12.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۱۳\/)/g,"<img src='Main/images/smiley/13.gif' style='margin-bottom:-9px;'>")
			.replace(/(\/ش۱۴\/)/g,"<img src='Main/images/smiley/14.gif' style='margin-bottom:-8px;'>")
			.replace(/(\/ش۱۵\/)/g,"<img src='Main/images/smiley/15.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۱۶\/)/g,"<img src='Main/images/smiley/16.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۱۷\/)/g,"<img src='Main/images/smiley/17.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۱۸\/)/g,"<img src='Main/images/smiley/18.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۱۹\/)/g,"<img src='Main/images/smiley/19.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۲۰\/)/g,"<img src='Main/images/smiley/20.gif' style='margin-bottom:-4px;'>")		
			.replace(/(\/ش۲۱\/)/g, "<img src='Main/images/smiley/21.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۲۲\/)/g, "<img src='Main/images/smiley/22.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۲۳\/)/g, "<img src='Main/images/smiley/23.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۲۴\/)/g, "<img src='Main/images/smiley/24.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۲۵\/)/g, "<img src='Main/images/smiley/25.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۲۶\/)/g, "<img src='Main/images/smiley/26.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۲۷\/)/g, "<img src='Main/images/smiley/27.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۲۸\/)/g, "<img src='Main/images/smiley/28.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۲۹\/)/g, "<img src='Main/images/smiley/29.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۳۰\/)/g,"<img src='Main/images/smiley/30.gif' style='margin-bottom:-7px;'>")
			.replace(/(\/ش۳۱\/)/g,"<img src='Main/images/smiley/31.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۳۲\/)/g,"<img src='Main/images/smiley/32.gif' style='height:40px; margin-bottom:-8px;'>")
			.replace(/(\/ش۳۳\/)/g,"<img src='Main/images/smiley/33.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۳۴\/)/g,"<img src='Main/images/smiley/34.gif' style='height:75px; margin-bottom:-8px;'>")
			.replace(/(\/ش۳۵\/)/g,"<img src='Main/images/smiley/35.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۳۶\/)/g,"<img src='Main/images/smiley/36.gif' style='margin-bottom:-7px;'>")
			.replace(/(\/ش۳۷\/)/g,"<img src='Main/images/smiley/37.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۳۸\/)/g,"<img src='Main/images/smiley/38.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۳۹\/)/g,"<img src='Main/images/smiley/39.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۴۰\/)/g,"<img src='Main/images/smiley/40.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۴۱\/)/g,"<img src='Main/images/smiley/41.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۴۲\/)/g,"<img src='Main/images/smiley/42.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۴۳\/)/g,"<img src='Main/images/smiley/43.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۴۴\/)/g,"<img src='Main/images/smiley/44.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۴۵\/)/g,"<img src='Main/images/smiley/45.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۴۶\/)/g,"<img src='Main/images/smiley/46.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۴۷\/)/g,"<img src='Main/images/smiley/47.gif' style='height:40px; margin-bottom:-5px;'>")
			.replace(/(\/ش۴۸\/)/g,"<img src='Main/images/smiley/48.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۴۹\/)/g,"<img src='Main/images/smiley/49.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵۰\/)/g,"<img src='Main/images/smiley/50.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۵۱\/)/g,"<img src='Main/images/smiley/51.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵۲\/)/g,"<img src='Main/images/smiley/52.gif' style='margin-bottom:-5px;'>")
			.replace(/(\/ش۵۳\/)/g,"<img src='Main/images/smiley/53.gif' style='margin-bottom:-6px;'>")
			.replace(/(\/ش۵۴\/)/g,"<img src='Main/images/smiley/54.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵۵\/)/g,"<img src='Main/images/smiley/55.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۵۶\/)/g,"<img src='Main/images/smiley/56.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵۷\/)/g,"<img src='Main/images/smiley/57.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۵۸\/)/g,"<img src='Main/images/smiley/58.gif' style='margin-bottom:-4px;'>")
			.replace(/(\/ش۵۹\/)/g,"<img src='Main/images/smiley/59.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۶۰\/)/g,"<img src='Main/images/smiley/60.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۶۱\/)/g,"<img src='Main/images/smiley/61.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۶۲\/)/g,"<img src='Main/images/smiley/62.gif' style='margin-bottom:-2px;'>")
			.replace(/(\/ش۶۳\/)/g,"<img src='Main/images/smiley/63.gif' style='margin-bottom:-2px;'>")
			.replace(/(\/ش۶۴\/)/g,"<img src='Main/images/smiley/64.gif' style='margin-bottom:-3px;'>")
			.replace(/(\/ش۶۵\/)/g,"<img src='Main/images/smiley/65.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۶۶\/)/g,"<img src='Main/images/smiley/66.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۶۷\/)/g,"<img src='Main/images/smiley/67.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۶۸\/)/g,"<img src='Main/images/smiley/68.gif' style='height:36px; margin-bottom:-6px;'>")
			.replace(/(\/ش۶۹\/)/g,"<img src='Main/images/smiley/69.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۷۰\/)/g,"<img src='Main/images/smiley/70.gif' style='height:36px; margin-bottom:-5px;'>")
			.replace(/(\/ش۷۱\/)/g,"<img src='Main/images/smiley/71.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۷۲\/)/g,"<img src='Main/images/smiley/72.gif' style='height:36px; margin-bottom:-4px;'>")
			.replace(/(\/ش۷۳\/)/g,"<img src='Main/images/smiley/73.gif' style='margin-bottom:-9px;'>")
			.replace(/(\/ش۷۴\/)/g,"<img src='Main/images/smiley/74.gif' style='height:36px; margin-bottom:-6px;'>")
			.replace(/(\/ش۷۵\/)/g,"<img src='Main/images/smiley/75.gif' style='height:45px; margin-bottom:-6px;'>")
			
			.replace(/(\/؟\/)/g,"<img src='Main/images/smiley/ex1.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/!\/)/g,"<img src='Main/images/smiley/ex2.gif' style='height:21px; margin-bottom:-4px;'>")
			.replace(/(\/چپ\/)/g,"<img src='Main/images/smiley/ex3.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/راست\/)/g,"<img src='Main/images/smiley/ex4.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/لامپ\/)/g,"<img src='Main/images/smiley/ex5.gif' style='height:21px; margin-bottom:-3px;'>")
			.replace(/(\/شمع\/)/g,"<img src='Main/images/smiley/ex6.gif' style='height:21px; margin-bottom:-2px;'>")
			.replace(/(\/گل\/)/g,"<img src='Main/images/smiley/ex7.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/قلب\/)/g,"<img src='Main/images/smiley/ex8.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/بادکنک\/)/g,"<img src='Main/images/smiley/ex9.gif' style='height:26px; margin-bottom:-2px;'>")
			.replace(/(\/کبوتر\/)/g,"<img src='Main/images/smiley/ex10.gif' style='height:26px; margin-bottom:-2px;'>")
			.replace(/(\/پروانه\/)/g,"<img src='Main/images/smiley/ex11.gif' style='height:21px; margin-bottom:-4px;'>")
			.replace(/(\/قهوه\/)/g,"<img src='Main/images/smiley/ex12.gif' style='height:21px; margin-bottom:-2px;'>")
			
			.replace(/(\/خط۱\/)/g,"<img src='Main/images/glyph/1.svg' style='width:500px; margin-bottom:0px;'>")
			.replace(/(\/خط۲\/)/g,"<img src='Main/images/glyph/2.svg' style='width:90px; margin-bottom:-5px;'>")
			.replace(/(\/خط۳\/)/g,"<img src='Main/images/glyph/3.svg' style='width:250px; margin-bottom:-5px;'>")
			.replace(/(\/خط۴\/)/g,"<img src='Main/images/glyph/4.svg' style='width:180px; margin-bottom:-5px;'>")
			.replace(/(\/خط۵\/)/g,"<img src='Main/images/glyph/5.svg' style='width:150px; margin-bottom:-5px;'>")
			.replace(/(\/خط۶\/)/g,"<img src='Main/images/glyph/6.svg' style='width:200px; margin-bottom:-15px;'>")
			.replace(/(\/خط۷\/)/g,"<img src='Main/images/glyph/7.svg' style='width:150px; margin-bottom:-5px;'>")
			.replace(/(\/خط۸\/)/g,"<img src='Main/images/glyph/8.svg' style='width:200px; margin-bottom:-5px;'>")
			.replace(/(\/خط۹\/)/g,"<img src='Main/images/glyph/9.svg' style='width:180px; margin-bottom:-5px;'>")
			.replace(/(\/خط۱۰\/)/g,"<img src='Main/images/glyph/10.svg' style='width:180px; margin-bottom:-5px;'>")
			.replace(/(\/خط۱۱\/)/g,"<img src='Main/images/glyph/11.svg' style='width:180px; margin-bottom:-15px;'>")
	return string;
}





function postProcess(id){
	
	var obj=document.getElementById(id);
	
	// to handle the header styling, and numbering
	var headers=obj.getElementsByClassName("header");
	var h1Num=h2Num=h3Num=0, h4Num=h5Num=h6Num=-1;
	for (var i=0, l=headers.length; i<l; i++) {
		var header = headers[i];
		
		if(header.getAttribute("kind")=="h1"){
			h1Num++; h2Num=h3Num=0; h4Num=h5Num=h6Num=-1;
			var h1NumPersian=toFa(h1Num);
			header.innerHTML="<table><tr valign=top id='headerOn"+id+"_"+h1Num+"' class='header1Content'>"
							+"<td class='header1Inside1'>"+h1NumPersian+".</div> "
							+"<td class='header1Inside2'>"+header.innerHTML+"</div>"
						+"</tr></table>";
					+"</tr></table>";
		}else if(header.getAttribute("kind")=="h2"){
			h2Num++; h3Num=0; h4Num=h5Num=h6Num=-1;
			var h2NumPersian=toFa(h1Num)+".&hairsp;"+toFa(h2Num);  // &hairsp; is a hairspace that is used after the "." for "." to remain a "." between 2 numbers
			header.innerHTML="<table><tr valign=top id='headerOn"+id+"_"+h1Num+"."+h2Num+"' class='header2Content'>"
							+"<td class='header2Inside1'>"+h2NumPersian+".</td> "
							+"<td class='header2Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
		}else if(header.getAttribute("kind")=="h3"){
			h3Num++; h4Num=h5Num=h6Num=-1;
			var h3NumPersian=toFa(h1Num)+".&hairsp;"+toFa(h2Num)+".&hairsp;"+toFa(h3Num);
			header.innerHTML="<table><tr valign=top id='headerOn"+id+"_"+h1Num+"."+h2Num+"."+h3Num+"' class='header3Content'>"
							+"<td class='header3Inside1'>"+h3NumPersian+".</td> "
							+"<td class='header3Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
		}else if(header.getAttribute("kind")=="h4"){
			h4Num++; h5Num=h6Num=-1;
			var h4NumPersian=toFa(h1Num)+".&hairsp;"+toFa(h2Num)+".&hairsp;"+toFa(h3Num)+".&hairsp;"+abjad[h4Num];
			header.innerHTML="<table><tr valign=top id='headerOn"+id+"_"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"' class='header4Content'>"
							+"<td class='header4Inside1'>"+h4NumPersian+".</td> "
							+"<td class='header4Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			
		}else if(header.getAttribute("kind")=="h5"){
			h5Num++; h6Num=-1;
			var h5NumPersian=toFa(h1Num)+".&hairsp;"+toFa(h2Num)+".&hairsp;"+toFa(h3Num)+".&hairsp;"+abjad[h4Num]+".&hairsp;"+Roman[h5Num];
			header.innerHTML="<table><tr valign=top id='headerOn"+id+"_"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"' class='header5Content'>"
							+"<td class='header5Inside1'>"+h5NumPersian+".</td> "
							+"<td class='header5Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			
		}else if(header.getAttribute("kind")=="h6"){
			h6Num++;
			var h6NumPersian=toFa(h1Num)+".&hairsp;"+toFa(h2Num)+".&hairsp;"+toFa(h3Num)+".&hairsp;"+abjad[h4Num]+".&hairsp;<span dir='ltr'>"+Roman[h5Num]+"</span>.&hairsp;"+roman[h6Num];
			header.innerHTML="<table><tr valign=top id='headerOn"+id+"_"+h1Num+"."+h2Num+"."+h3Num+"."+h4Num+"."+h5Num+"."+h6Num+"' class='header6Content'>"
							+"<td class='header6Inside1'>"+h6NumPersian+".</td> "
							+"<td class='header6Inside2'>"+header.innerHTML+"</td>"
						+"</tr></table>";
			
		}
	}
	
	
	
	
	// to handle generating the list of relevent Footnotes at the end of each page
	if(ftnNum>=1){
		var ftnCurrentPage="";
		var i, ftnCounter=1;
		var idMod=(id.indexOf("Demo")==-1)? "descriptionOn"+id : id;
		for(i=ftnCounter; i<=ftnNum; i++){
			if(document.getElementById("ftn"+idMod+"_"+i)!=null){
				var ftnContent=document.getElementById("ftn"+idMod+"_"+i+"-Hidden").firstChild.innerHTML;
				var directionMainText=document.getElementById("ftn"+idMod+"_"+i+"-Hidden").getAttribute("directionMainText");
				//alert(directionMainText);
				
				ftnCurrentPage+=
						"<tr id='FTN"+idMod+"_"+i+"'>"
							+"<td class='ftnNumbers'><sup><a href='#ftn"+idMod+"_"+i+"' style='color:crimson;'>"+toFa(i)+"</a></sup></td>"
							+"<td class='ftnContents' style='text-align:"+directionMainText+";'>"+ftnContent+"</td>"
						+"</tr>";
					
				
				//to have "anchors" defined once, not twice; and only within the ftn at the bottom of the page
				document.getElementById("ftn"+idMod+"_"+i+"-Hidden").innerHTML = ("<span class='tooltipInnerContent'>"+ftnContent+"</span>").toString()
																				.replace(/(\<span id\=[\'\"]anchor[^\>]*\>\<\/span\>)/g,"")
																				//.replace(/(?:\/لنگرگاه)(?:\{[ \t]*(.*?)[ \t]*\})/g,"")
																				;
				ftnCounter=i;
			}
		}
		if(ftnCurrentPage != ""){
			document.getElementById("ftnOn"+id).style.display="initial";
			document.getElementById("ftnColWrapperOn"+id).innerHTML="<table style='display:block'><tbody style='display:block'>"+ftnCurrentPage+"</tbody></table>";
		}
	}
	
	
	obj.innerHTML=obj.innerHTML.replace(/(?:\/پا۱\/)/g, function(x){
		document.getElementById("ftnColWrapperOn"+id).classList.add("singleFtnCol");
		// odd that it doesn't work ... it is added when the div's classList is seen, but not added when alert(obj.innerHTML) is observed
		//alert(document.getElementById("ftnColWrapperOn"+id).classList);
		
		// these also doesn't work
		/*document.getElementById("ftnColWrapperOn"+id).style.columnWidth="2000px";
		document.getElementById("ftnColWrapperOn"+id).style.columnCount=1;*/
		
		return "";
	});
	// the line below should not have been required, but IT IS, but why?	... this is now more like a hack :(
	//obj.innerHTML=obj.innerHTML.replace(/(?:\/پا۱\/)/g,"");
}



function setCrossReferences(containerID){
	var containerDIV=document.getElementById(containerID);
	
	// Now define the links for the cross-references
	containerDIV.innerHTML = containerDIV.innerHTML
	
		// for capturing references to already defined figures ...	   //use as   /شکل{کلید: key}
		.replace(/(?:\/شکل)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(containerDIV.contains(document.querySelector('[id^="fig"][id$="_'+y+'"]'))){
				var id = document.querySelector('[id^="fig"][id$="_'+y+'"]').id;
				var targetDay=id.replace(/figdescriptionOnPage(\d*)\_.*/,"$1").replace(/fig((?:New|Edit)Demo)\_.*/,"$1");
				return "شکل <a href='#"+id+"' onclick='jumpToPageContainingPage("+targetDay+");'>"
						+document.getElementById(id).getAttribute("figNumber")
					+"</a>"
					+" از برگه‌ی "
					+targetDay;	// این الآن باید به انگلیسی باشد تا بعداً به نحو درستی فارسی شود
			}else{
				return	"شکل <span style='color:crimson;'>؟؟</span>";
			}
		})
		// for capturing references to already defined فیلم ...	   //use as   /فیلم{کلید: key}
		.replace(/(?:\/فیلم)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(containerDIV.contains(document.querySelector('[id^="video"][id$="_'+y+'"]'))){
				var id = document.querySelector('[id^="video"][id$="_'+y+'"]').id;
				var targetDay=id.replace(/videodescriptionOnPage(\d*)\_.*/,"$1").replace(/video((?:New|Edit)Demo)\_.*/,"$1");
				return "فیلم <a href='#"+id+"' onclick='jumpToPageContainingPage("+targetDay+");'>"
						+document.getElementById(id).getAttribute("videoNumber")
					+"</a>"
					+" از برگه‌ی "
					+targetDay;	// این الآن باید به انگلیسی باشد تا بعداً به نحو درستی فارسی شود
			}else{
				return	"فیلم <span style='color:crimson;'>؟؟</span>";
			}
		})
		// for capturing references to already defined صوت ...	   //use as   /صوت{کلید: key}
		.replace(/(?:\/صوت)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(containerDIV.contains(document.querySelector('[id^="audio"][id$="_'+y+'"]'))){
				var id = document.querySelector('[id^="audio"][id$="_'+y+'"]').id;
				var targetDay=id.replace(/audiodescriptionOnPage(\d*)\_.*/,"$1").replace(/audio((?:New|Edit)Demo)\_.*/,"$1");
				return "صوت <a href='#"+id+"' onclick='jumpToPageContainingPage("+targetDay+");'>"
						+document.getElementById(id).getAttribute("audioNumber")
					+"</a>"
					+" از برگه‌ی "
					+targetDay;	// این الآن باید به انگلیسی باشد تا بعداً به نحو درستی فارسی شود
			}else{
				return	"صوت <span style='color:crimson;'>؟؟</span>";
			}
		})
		// for capturing references to already defined پنجره ...	   //use as   /پنجره{کلید: key}
		.replace(/(?:\/پنجره)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(containerDIV.contains(document.querySelector('[id^="iFrame"][id$="_'+y+'"]'))){
				var id = document.querySelector('[id^="iFrame"][id$="_'+y+'"]').id;
				var targetDay=id.replace(/iFramedescriptionOnPage(\d*)\_.*/,"$1").replace(/iFrame((?:New|Edit)Demo)\_.*/,"$1");
				return "پنجره‌ی <a href='#"+id+"' onclick='jumpToPageContainingPage("+targetDay+");'>"
						+document.getElementById(id).getAttribute("iFrameNumber")
					+"</a>"
					+" از برگه‌ی "
					+targetDay;	// این الآن باید به انگلیسی باشد تا بعداً به نحو درستی فارسی شود
			}else{
				return	"پنجره‌ی <span style='color:crimson;'>؟؟</span>";
			}
		})
		// for capturing references to already defined tables ...	   //use as   /جدول{key}
		.replace(/(?:\/جدول)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(containerDIV.contains(document.querySelector('[id^="tbl"][id$="_'+y+'"]'))){
				var id = document.querySelector('[id^="tbl"][id$="_'+y+'"]').id;
				var targetDay=id.replace(/tbldescriptionOnPage(\d*)\_.*/,"$1").replace(/tbl((?:New|Edit)Demo)\_.*/,"$1");
				return "جدول <a href='#"+id+"' onclick='jumpToPageContainingPage("+targetDay+");'>"
						+document.getElementById(id).getAttribute("tblNumber")
					+"</a>"
					+" از برگه‌ی "
					+targetDay;	// این الآن باید به انگلیسی باشد تا بعداً به نحو درستی فارسی شود
			}else{
				return	"جدول <span style='color:crimson;'>؟؟</span>";
			}
		})
		// for capturing references to already defined sections ...	   //use as   /بخش{کلید: key}
		.replace(/(?:\/بخش)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			var headers=document.getElementsByClassName("header"),
				targetDay, key, id, hNumber, htitle, keyFound=0;
			for (var i=0, l=headers.length; i<l; i++) {
				if(headers[i].getAttribute("key")==y){
					id=headers[i].firstChild.firstChild.firstChild.id;
					targetDay=id.replace(/headerOnPage(\d*)\_.*/,"$1").replace(/headerOn((?:New|Edit)Demo)\_.*/,"$1");
					hNumber=document.getElementById(id).firstChild.innerHTML.replace(/\.\s?$/m,"");
					htitle=document.getElementById(id).lastChild.innerHTML.replace(/(?:\<sup class\=\"tooltip)[^\r]*?(?:\<\/sup\>)/g,"");	// remove Footnotes from header's text;
					keyFound=1;
					break;
				}
			}
			if(keyFound==0){
				return "بخش <span style='color:crimson;'>؟؟</span>";
			}
			
			
			
			refHeader++;
			var idToCallFor="refHeader-"+refHeader;
			return "بخش "
					+"<span class='tooltip' onmouseover='tooltipRepositionCaller(\""+containerID+"\", \""+idToCallFor+"\");'>"
						+"<a href='#"+id+"' id='refHeader-"+refHeader+"' onclick='jumpToPageContainingPage("+targetDay+");'>"+hNumber+"</a>"
						+"<span id='refHeader-"+refHeader+"-Hidden' class='tooltipContent bottom' style='text-align:center; white-space:nowrap;'>"
							+htitle
						+"</span>"
					+" از برگه‌ی "
						+targetDay	// این الآن باید به انگلیسی باشد تا بعداً به نحو درستی فارسی شود
					+"</span>";
			
			
			
		})
		
		// to refer to the generated "لنگرگاه" ...	//use as   /لنگر{کلید: key}{متن لینک}
		.replace(/(?:\/لنگر)(?:\{کلید:[ \t]*(.*?)[ \t]*\})(?:\{[ \t]*(.*?)[ \t]*\})/g,  function(x,y1,y2){
			if(containerDIV.contains(document.querySelector('[id^="anchor"][id$="_'+y1+'"]'))){
				var id = document.querySelector('[id^="anchor"][id$="_'+y1+'"]').id;
				var targetDay=id.replace(/anchordescriptionOnPage(\d*)\_.*/,"$1").replace(/anchor((?:New|Edit)Demo)\_.*/,"$1");
				return "<a href='#"+id+"' onclick='jumpToPageContainingPage("+targetDay+");'>"+y2+"</a>"
					+" از برگه‌ی "
					+targetDay;	// این الآن باید به انگلیسی باشد تا بعداً به نحو درستی فارسی شود
			}else{
				return	"<a href='#' onclick='alert(\"لنگرگاه این لنگر تعریف نشده است!\");'>"+y2+"</a>";
			}
		});
	
	
	
	
	// for capturing references to already defined پاورقی ...	   //use as   /پاورقی{کلید: key}
	var ftnCallers=document.querySelectorAll('[id^=ftnCaller]');
	for(var i=0, l=ftnCallers.length; i<l; i++) {
		var ftnCaller=ftnCallers[i];
		var ftnCallerID=ftnCaller.id;
		var keyToRefer=ftnCaller.getAttribute("keyToRefer");
		var ftnContainerID=ftnCaller.getAttribute("containerID");
		
		if(containerDIV.contains(document.querySelector('[id^="ftn"][key="'+keyToRefer+'"]'))){
			var id = document.querySelector('[id^="ftn"][key="'+keyToRefer+'"]').id;
			var targetDay=id.replace(/ftndescriptionOnPage(\d*)\_\d*/,"$1").replace(/ftn((?:New|Edit)Demo)\_.*/,"$1");
			var ftnNumber=id.replace(/ftn[^\_]*\_(\d*)/,"$1");
			var ftn=document.getElementById("ftndescriptionOnPage"+targetDay+"_"+ftnNumber+"-Hidden")
					|| document.getElementById("ftn"+containerID+"_"+ftnNumber+"-Hidden");
			var ftnContent, ftnWidth, ftnDir;
			ftnContent=ftn.innerHTML;
			ftnWidth=ftn.getBoundingClientRect().width;
			ftnDir=ftn.style.textAlign;
			
			
			var idToCallFor="refFTN"+ftnContainerID+"_"+i;
			ftnCaller.innerHTML= "پاورقی "
					+"<span class='tooltip' onmouseover='tooltipRepositionCaller(\""+containerID+"\", \""+idToCallFor+"\");'>"
						+"<a href='#"+id+"' id='refFTN"+ftnContainerID+"_"+i+"' onclick='jumpToPageContainingPage("+targetDay+");'>"+toFa(ftnNumber)+"</a>"
						+"<span id='refFTN"+ftnContainerID+"_"+i+"-Hidden' class='tooltipContent bottom' style='text-align:"+ftnDir+"; width:"+ftnWidth+"px;' >"
							+ftnContent
						+"</span>"
					+"</span>"
					+" از برگه‌ی "
					+targetDay;	// این الآن باید به انگلیسی باشد تا بعداً به نحو درستی فارسی شود
		}else{
			ftnCaller.innerHTML= "پاورقی <span style='color:crimson;'>؟؟</span>";
		}
	}
	
			
	
	MathJax.texReset();
	MathJax.typesetClear();
	MathJax.typeset();
	//MathJax.typeset(["#containerDIV"]);
	
	// to handle cross-referencing the equations in MathJax, due to the multipage nature of the document
	var perPageEqs=[];
	for(var day=1, days=myJSONData["days"].length; day<=days; day++) {	//var day in myJSONData["days"]
		var jax = MathJax.getAllJax("Page"+day);
		var neWLabelsInPage=[];
		for (var i=0, l=jax.length; i<l; i++) {
			//alert(jax[i].math);
			jax[i].math.replace(/\\label\{([^\}]+)\}/g, function(x,y){
				neWLabelsInPage.push(y);
				return false;
			});
		}
		perPageEqs.push(neWLabelsInPage);
	}
	
	//alert(JSON.stringify(perPageEqs));
	containerDIV.innerHTML=containerDIV.innerHTML
		.replace(/(href\=\"\#mjx\-eqn\-([^\"]*)\")/g,  function(x,y1,y2){
			targetDay=perPageEqs.findIndex(function(x) {
				return x.indexOf(y2) !== -1;
			});
			targetDay++;
			return y1+" onclick=\"jumpToPageContainingPage("+targetDay+");\"";
		});
	
	
}



//======  CHANGE THE SIZE OF THE PAGES SHOWN ON THE WEBPAGE, EACH BELONGING TO A DAY  =======



document.getElementById("hSizeSlider").oninput = function() {
	for(var i=1, l=days=myJSONData["days"].length; i<=l ; i++){
		hslider='calc('+ Number(this.value) +'% - 20px)';
		document.getElementById("Page"+i).style.width = myJSONData.hslider = hslider;
		saveToCache();
	}
}
document.getElementById("vSizeSlider").oninput = function() {
	for(var i=1, l=days=myJSONData["days"].length; i<=l ; i++){
		vslider='calc('+ Number(this.value) +'vh - 50px)';
		document.getElementById("Page"+i).style.height = myJSONData.vslider = vslider;
		saveToCache();
	}
}





//====================  OPEN A NEW FILE  =====================



var openFile=document.getElementById("Openfile");

function openFunction(){
	if(myJSONData){
		if(!confirm('با باز کردن فایل جدید ورودی‌های ذخیره‌نشده‌ی فعلی از دست می‌روند، آیا ادامه می‌دهید؟')){
			return false;
		}
	}
	openFile.click();	// this opens the file browser dialog for selecting a file to open
	return;
};

openFile.addEventListener('change', function() {
	var fileToLoad=openFile.files[0];			// the selected file itself as an object?
	var fileToLoadAddress=openFile.value;		// the relative or absolute address of the selected file
	
	document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>فایل: </span>"+fileToLoadAddress.split('\\').pop()  .replace(/(.txt)/,"").replace(/\./g,":");	// this writes the name of the file opened in the header at the top
	//.replace(/(?:^|[^\d۰-۹])(([01۰۱]?[\d۰-۹])|([2۲][0-3۰-۳])|(24|۲۴)).([0-5۰-۵]?[\d۰-۹])(?:$|[^\d۰-۹])/g,"$1:$5");	// to match time
	
	if(fileToLoad){
		var reader=new FileReader();
		reader.readAsText(fileToLoad, "UTF-8");
		reader.onload=function(event){
			myJSONData = JSON.parse(event.target.result);
			
			// to let import a file from saved files of the application "همیان"
			if(myJSONData["days"].length && !myJSONData["days"][0]["lastEditDate"]){	//so the file is identified as imported from "همیان"
				for (var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
					myJSONData["days"][day]["lastEditDate"]="";
					myJSONData["days"][day]["tags"]=[];
				}
			}
			
			
			selectedPageNumShown = myJSONData.daysInPageNum;
			StartToEndVar = myJSONData.start2End;
			hslider = myJSONData.hslider;
			vslider = myJSONData.vslider;
			currentPage = myJSONData.currentPage;
		
			document.getElementById("hSizeSlider").value = hslider.replace(/[^\d]*(\d+)\%.*/,"$1");
			document.getElementById("vSizeSlider").value = vslider.replace(/[^\d]*(\d+)vh.*/,"$1");
			
			fillTheBook();
			selectHowMany();
		}
		reader.onerror=function(event){
			document.getElementById("container").innerHTML="بارگذاری فایل انتخاب شده ناموفق بود!";
		}
	}
});



// -----------------------------------------------------------------------------
// Drag&Drop text file into the siurce textarea to open the file's content there
// got the inspiration from "http://devjs.eu/en/drag-multiple-text-files-to-your-web-application-with-html5-and-javascript/"


document.getElementById("container").addEventListener('dragover', dragOver);
document.getElementById("container").addEventListener('dragend', dragEnd);
document.getElementById("container").addEventListener('drop', readText, false);

function dragOver(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	//e.dataTransfer.effectAllowed = "move";		// when the curser changed, the file can be dropped!
	return false;
}
function dragEnd(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	return false;
}
function readText(e){
	e.stopPropagation(); // for some browsers stop redirecting
	e.preventDefault();
	
	var fileData, reader, file=e.dataTransfer.files[0];
	if (!file) {return false;}
	
	if(myJSONData){
		if(!confirm('با باز کردن فایل جدید ورودی‌های ذخیره‌نشده‌ی فعلی از دست می‌روند، آیا ادامه می‌دهید؟')){
			return false;
		}
	}
    
    //to read the content of the file
    reader=new FileReader();
	reader.readAsText(file, "UTF-8");
	reader.onload=function(event){
		myJSONData = JSON.parse(event.target.result);
			
		// to let import a file from saved files of the application "همیان"
		if(myJSONData["days"].length && !myJSONData["days"][0]["lastEditDate"]){	//so the file is identified as imported from "همیان"
			for (var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
				myJSONData["days"][day]["lastEditDate"]="";
				myJSONData["days"][day]["tags"]=[];
			}
		}
		
		
		selectedPageNumShown = myJSONData.daysInPageNum;
		StartToEndVar = myJSONData.start2End;
		hslider = myJSONData.hslider;
		vslider = myJSONData.vslider;
		currentPage = myJSONData.currentPage;
		
		document.getElementById("hSizeSlider").value = hslider.replace(/[^\d]*(\d+)\%.*/,"$1");
		document.getElementById("vSizeSlider").value = vslider.replace(/[^\d]*(\d+)vh.*/,"$1");
		
		fillTheBook();
		selectHowMany();
	}
	reader.onerror=function(event){ alert("بارگذاری فایل انتخاب شده ناموفق بود!"); };
	
	
	document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>فایل: </span>"+file.name.split('\\').pop()  .replace(/(.txt)/,"").replace(/\./g,":");	// this writes the name of the file opened in the header at the top
	//.replace(/(?:^|[^\d۰-۹])(([01۰۱]?[\d۰-۹])|([2۲][0-3۰-۳])|(24|۲۴)).([0-5۰-۵]?[\d۰-۹])(?:$|[^\d۰-۹])/g,"$1:$5");	// to match time
}




//====================  SAVE TO A FILE (PERMANENT BACKUP)  =====================




function saveData(){
	if(myJSONData){
		persianDateTime();
		var title=myJSONData["BookName"],
			today=toFa(shortDate).replace(/\:/g,".");
	
		title=title.length>30	?	title.substring(0,30)+" ..."	:	title;
		
		// ------- if using  download.js
		download(  JSON.stringify(myJSONData)	,	title+" ("+today+").txt"	,	"text/html");
	}else{
		alert("هنوز داده‌ای وارد نشده که ذخیره شود!");
	}
};



//=============  USE localStorage OF HTML5 TO AUTOMATE SAVING OF DATA IN CACHE ==============//



function saveToCache(){
	// to properly save a file imported from the saved files of the application "همیان" in the new format suitable to this app
	if(myJSONData.Accounts){
		delete myJSONData.Accounts;
		delete myJSONData.StartingAmounts;
		for (var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
			delete myJSONData["days"][day]["transactions"];
			delete myJSONData["days"][day]["endDayLeft"];
		}
	}
	

	window.localStorage["savedInCahe"] = JSON.stringify(myJSONData);	// stores the data to the browser's cache
	document.getElementById('save-log').style.display = 'inline-block';
	setTimeout(function() {
		document.getElementById('save-log').style.display = 'none';	// the save-log will last for 1 second (1000 ms) before it will become display-none ...
	}, 1000);
}



//=============  PREVENT LEAVING THE PAGE AS THERE MIGHT BE UNSAVED DATA ==============//



window.onbeforeunload = function() {
	return "توصیه بر ذخیره‌ی داده‌ها پیش از حروج از نرم‌افزار است ... آیا اطمینان دارید می‌خواهید از نرم‌افزار خارج شوید؟!";
}	
//window.addEventListener("beforeunload", function(event) {
//	event.returnValue = "شما در حال ترک نرم‌افزار هستید، آیا تمایل دارید داده‌های خود را در صورت تغییر ذخیره نمایید؟";
	//saveFunctioin();
//});
