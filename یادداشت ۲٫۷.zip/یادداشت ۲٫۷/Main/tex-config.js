window.MathJax = {
	startup: {
		ready: function () {
			// to add the persian digits as well to the digits MathJax understands
			var ParseMethods = MathJax._.input.tex.ParseMethods.default;
			var RegExpMap = MathJax._.input.tex.SymbolMap.RegExpMap;
			new RegExpMap('digit', ParseMethods.digit, /[\d.٫۰-۹]/);
			
			// to define   MathJax.getAllJax()   function as a replacement for   MathJax.Hub.getAllJax()   in MathJax v.2
			MathJax.getAllJax = function(name){
				const list = Array.from(MathJax.startup.document.math);
				if (!name) return list;
				const container = document.getElementById(name);
				if (!container) return list;
				return list.filter((node) => container.contains(node.start.node));
			}
			
			
			
			// temporary to solve the issue of the problem which used to arise if calling for mutip different equations fro within an equation
			const {SVGWrapper} = MathJax._.output.svg.Wrapper;
			const place = SVGWrapper.prototype.place;
			SVGWrapper.prototype.place = function (x, y, node) {
				place.call(this, x, y, node);
				if ((x || y) && !node && this.node.attributes.get('href')) {
					const translate = 'translate(' + this.fixed(x) + ', ' + this.fixed(y) + ')';
					const rect = this.adaptor.previous(this.element);
					this.adaptor.setAttribute(rect, 'transform', translate);
				}
			};
			//----------
			
			
			
			return MathJax.startup.defaultReady();
		}
	},
	tex: {
		inlineMath: [ ["$","$"] ],		// ["$","$"],["\$","\$"],["\(","\)"],["\\(","\\)"]
		displayMath: [ ["$$","$$"] ],
		processEscapes: true,			// for \$ to mean a common dollar sign, not a math delimiter
		
		digits: /^(?:[\d۰-۹]+(?:[,٬'][\d۰-۹]{3})*(?:[\.\/٫][\d۰-۹]*)?|[\.\/٫][\d۰-۹]+)/,	// introduce numbers
		
		tagSide: "right",
		tagIndent: ".8em",
		multlineWidth: "85%",
		tags: "ams",
		tagformat: {
			number: function(n){
				return String(n).replace(/0/g,"۰").replace(/1/g,"۱").replace(/2/g,"۲").replace(/3/g,"۳")
								.replace(/4/g,"۴").replace(/5/g,"۵").replace(/6/g,"۶")
								.replace(/7/g,"۷").replace(/8/g,"۸").replace(/9/g,"۹");
			}
		},
	},
	svg: {
		fontCache: 'none',			// or 'local' or 'global', but these prevent showing the math glyphs in NewDemo and EditDemo popups!
		mtextInheritFont: true		// required to correctly render RTL Persian text inside a formula
	},
};
