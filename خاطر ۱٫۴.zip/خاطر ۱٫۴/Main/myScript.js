//============  THE MAIN VARIABLES AND INITIAL FILLING OF THE WEBPAGE ON LOAD  =============//



//== global variables ==
var 	pageToBeEdited,	// it will be used by the function:  saveEditedPage()
	myJSONData,		// the main variable (JSON DATABASE) which contains the whole data
	totalPageNumber=1, currentPage=1, selectedPageNumShown=10,
	hslider='calc(40% - 25px)', vslider='calc(80vh - 50px)';   //saves last size of Pages related to different days ...
var  userCalledAnimationSources=[], userCalledAnimationLibs=[];	
	
document.getElementById("goToPage").value="۱ \/ ۱";

window.onload=function(){
	if(myJSONData){
		document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>دفتر: </span>"+myJSONData.BookName;
		selectHowMany(10);
		//fillTheBook();
	}
}



//=============  USE localStorage OF HTML5 TO RELOAD DATA FROM CACHE AT START  ==============//


if (window.localStorage["savedInCahe"] != 'undefined' && window.localStorage["savedInCahe"] != null) {
//if (window.localStorage["savedInCahe"] != 'undefined') {
	myJSONData = JSON.parse(window.localStorage["savedInCahe"]);	//retrieves the data from the browser's cache even after the browser/tab is reopened
}



//=============  FIND THE PRESENT DATE IN THE PERSIAN CALENDAR  ==============//



function gregorian_to_jalali(gy,gm,gd){
	g_d_m=[0,31,59,90,120,151,181,212,243,273,304,334];
	jy=(gy<=1600)?0:979;
	gy-=(gy<=1600)?621:1600;
	gy2=(gm>2)?(gy+1):gy;
	days=(365*gy) +(parseInt((gy2+3)/4)) -(parseInt((gy2+99)/100)) +(parseInt((gy2+399)/400)) -80 +gd +g_d_m[gm-1];
	jy+=33*(parseInt(days/12053)); 
	days%=12053;
	jy+=4*(parseInt(days/1461));
	days%=1461;
	jy+=parseInt((days-1)/365);
 	if(days > 365)days=(days-1)%365;
	jm=(days < 186)?1+parseInt(days/31):7+parseInt((days-186)/30);
	jd=1+((days < 186)?(days%31):((days-186)%30));
	return [jy,jm,jd];
};
var persianMonth=["","فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"];
var dayOfWeek=["یکشنبه","دوشنبه","سه‌شنبه", "چهارشنبه","پنجشنبه","جمعه","شنبه"];
var currenDayOfWeek;
var morningAfternnon;
function persianDateTime(){
	d=new Date();
	g_y=d.getFullYear();
	g_m=d.getMonth()+1;
	g_d=d.getDate();
	currenDayOfWeek=d.getDay();
	shamsi=gregorian_to_jalali(g_y,g_m,g_d);
	H=d.getHours();
	//H=(H<10)?"0"+H:H;
	morningAfternnon= 
		(H==12)  ? "ظ" : (
			(H!=0) ? (
				(H<12) ? "ص" : (
					(H>=20) ? "ش" :  "ب‌ظ"
				)
			)
			: "ن‌ش"
		);
	H = (H<=12)  ?  H  :  H-12;
	H = (H<10) ? "0"+H : H;
	i = d.getMinutes();
	i = (i<10) ? "0"+i : i;
	return shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]+" ساعت "+H+":"+i+" "+morningAfternnon;
}; // now you can use the present date by calling the function  persianDateTime()




//=================  TRANSFORM NUMBERS TO PERSIAN/ENGLISH  ==================



function toFa(textContainingEnglishNumbers){
	return textContainingEnglishNumbers.toString()
		.replace(/0/g,'۰').replace(/1/g,'۱').replace(/2/g,'۲').replace(/3/g,'۳').replace(/4/g,'۴').replace(/5/g,'۵')
		.replace(/6/g,'۶').replace(/7/g,'۷').replace(/8/g,'۸').replace(/9/g,'۹').replace(/\./g,'/');
}
function toEn(persianNumbers){
	return Number(
		persianNumbers.toString()
		.replace(/۰/g,'0').replace(/۱/g,'1').replace(/۲/g,'2').replace(/۳/g,'3').replace(/۴/g,'4').replace(/۵/g,'5')
		.replace(/۶/g,'6').replace(/۷/g,'7').replace(/۸/g,'8').replace(/۹/g,'9').replace(/\//g,'.')
	);
}
//alert(toFa("53 is 53 and not 78 !"));
//alert(toEn("۴۵")+2);




//=============  to define some keyboard shortcuts and etc ...  ==============



document.addEventListener("keydown", function(e){
	// add the shortcut "ctrl+left" and "ctrl+up" for page change to NEXT
	if (e.ctrlKey && (e.keyCode == 37 || e.keyCode == 38)) { e.preventDefault(); nextPage(); }
	
	// add the shortcut "ctrl+right" and "ctrl+down" for page change to PREVIOUS
	if (e.ctrlKey && (e.keyCode == 39 || e.keyCode == 40)) { e.preventDefault(); prevPage(); }
	
	// to close the Popups by pressing the key "Esc"
	if (e.keyCode == 27) { window.location.href='#'; }
});


document.onclick = function(e){
	//check if the dark backgrounds of the popups are clicked ...
	if(e.target.id == 'popupSmilies' || e.target.id == 'popupGuide' || e.target.id == 'popupAbout'){
		window.location.href='#';
	}
}


document.getElementById("goToPage").onclick = function(){
	document.getElementById("goToPage").value="";
}
document.getElementById("goToPage").addEventListener("focusout",function(){
	document.getElementById("goToPage").value=toFa(totalPageNumber)+" \/ "+toFa(currentPage);
});




//=============  Pagination  ==============


function selectHowMany(val){
	document.getElementById("selectBox").value=val;
	selectedPageNumShown=val;
	if(selectedPageNumShown=="ALL"){
		totalPageNumber=1;
		currentPage=1;
	} else {
		(myJSONData != undefined) ? 
			totalPageNumber=Math.ceil(myJSONData["days"].length / selectedPageNumShown)
			: totalPageNumber=1;
		(document.getElementById("checkbox").checked)?
			//to display the pages in reverse order, the last page at top-right of the webpage
			currentPage=1
			:
			//to display the pages in straight order of page numbers
			currentPage=totalPageNumber;
	}
	document.getElementById("goToPage").value=toFa(totalPageNumber)+" \/ "+toFa(currentPage);
	fillTheBook();
}
function nextPage(){
	(currentPage < totalPageNumber) ? currentPage++ : currentPage=totalPageNumber ;
	document.getElementById("goToPage").value=toFa(totalPageNumber)+" \/ "+toFa(currentPage);
	
	// to show only those pages which lie in the range selected
	changePage();
}
function prevPage(){
	(currentPage > 1) ? currentPage-- : currentPage=1 ;
	document.getElementById("goToPage").value=toFa(totalPageNumber)+" \/ "+toFa(currentPage);
	
	// to show only those pages which lie in the range selected
	changePage();
}
document.getElementById("goToPage").onkeypress = function(ev){
	if (ev.which === 13){
		currentPage=toEn(document.getElementById("goToPage").value);
		(currentPage < 1) ? currentPage=1 : 0;
		(currentPage > totalPageNumber) ? currentPage=totalPageNumber : 0;
		document.getElementById("goToPage").value=toFa(totalPageNumber)+" \/ "+toFa(currentPage);
		
		// to show only those pages which lie in the range selected
		changePage();
	}
}
function changePage(){
	// to show only those pages which lie in the range selected
	for (var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
		//document.getElementById("page-"+(day+1)).style.display="none";
		if(!document.getElementById("page-"+(day+1)).classList.contains("hidden")){
			document.getElementById("page-"+(day+1)).classList.add("hidden");
		}
		
		if(document.getElementById("checkbox").checked){
			//to display the pages in reverse order, the last page at top-right of the webpage
			if(selectedPageNumShown == "ALL"){
				initialDayNum=0;
				finalDayNum=myJSONData["days"].length - 1;
			}else{
				initialDayNum=myJSONData["days"].length - currentPage*selectedPageNumShown;
				if(initialDayNum<0) initialDayNum=0;
				finalDayNum=myJSONData["days"].length - (currentPage-1)*selectedPageNumShown - 1;
			}
			if(day>=initialDayNum && day<=finalDayNum){
				//document.getElementById("page-"+(day+1)).style.display="";
				document.getElementById("page-"+(day+1)).classList.remove("hidden");
			}
		}else{
			//to display the pages in straight order of page numbers
			if(selectedPageNumShown == "ALL"){
				initialDayNum=0;
				finalDayNum=myJSONData["days"].length - 1;
			}else{
				initialDayNum=(currentPage-1)*selectedPageNumShown;
				finalDayNum=currentPage*selectedPageNumShown - 1;
				if(finalDayNum>myJSONData["days"].length) finalDayNum=myJSONData["days"].length;
			}
			if(day>=initialDayNum && day<=finalDayNum){
				//document.getElementById("page-"+(day+1)).style.display="";
				document.getElementById("page-"+(day+1)).classList.remove("hidden");
			}
		}
	}
	/*
	// this was required if equations were reset numbered inside each page representing a day
	document.getElementById('container').innerHTML = document.getElementById('container').innerHTML
		.replace(/از برگه‌ی (\d+)/g, function(x,y){
			return "از برگه‌ی "+toFa(y);
		});
	*/
}




//=================  Populate the currenDate div in main header  ==================//



persianDateTime();
document.getElementById("currenDate").innerHTML=toFa(dayOfWeek[currenDayOfWeek]+" "+shamsi[0]+"٫"+shamsi[1]+"٫"+shamsi[2]);



//=================  BUILD A WHOLE NEW BOOKLET  ==================//



function newBooklet() {
	if(myJSONData){
		if(!confirm('با ایجاد دفتر خاطرات/خطورات جدید اطلاعات پرونده‌ی قبلی پاک می‌شوند، آیا ادامه می‌دهید؟')){
			return false;
		}
	}
	window.location.href='#popupNewBook';
}
function saveNewBooklet() {
	if(!(document.getElementById("bookTitle").value)){
		alert("لطفاً عنوان دفتر خاطرات/خطورات جدید را وارد نمایید!");
		return false;
	}
	// fill the variable and make a new data in the JSON variables
	myJSONData = {
		"BookName":document.getElementById("bookTitle").value,
		"days":[]
	};
	
	document.getElementById('container').innerHTML="";
	document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>دفتر: </span>"+myJSONData.BookName;
	
	fillTheBook();
	window.location.href='#';						// to colse the popup
	document.getElementById('newBookForm').reset();	//reset the form for later recalling the popup
}




//=================  BUILD A WHOLE NEW PAGE (DAY) INSIDE THE BOOKLET  ==================//




function addNewDay() {
	if(!myJSONData){
		alert("لطفاً ابتدا یک دفتر خاطرات/خطورات جدید ایجاد نمایید، و یا یک دفتر خاطرات/خطورات قدیمی را بارگذاری کنید ...!");
	}else{	
		window.location.href='#popupNewDay';
		// to pre-populate the date fields
		document.getElementById("newWeekDAY").value=dayOfWeek[currenDayOfWeek];
		document.getElementById("newDAY").value=toFa(shamsi[2]);
		document.getElementById("newMONTH").value=toFa(shamsi[1]);
		document.getElementById("newYEAR").value=toFa(shamsi[0]);
	}
}
function saveNewDay() {
	// fill the variable and make a new data in the JSON variable
	var 	validatedDay=toEn(document.getElementById("newDAY").value),
		validatedMonth=toEn(document.getElementById("newMONTH").value),
		validatedYEAR=toEn(document.getElementById("newYEAR").value);
	if(Number.isInteger(validatedDay) && validatedDay>=1 && validatedDay<=31 && Number.isInteger(validatedMonth) && validatedMonth>=1 && validatedMonth<=12 && Number.isInteger(validatedYEAR) && validatedYEAR>=0){
		// for sorting by dates we need to define new variables
		var validatedDayEx = (validatedDay<10) ? "0"+validatedDay : validatedDay;		//e.g. 5 -> 05
		var validatedMonthEx = (validatedMonth<10) ? "0"+validatedMonth : validatedMonth;	//e.g. 5 -> 05
		
		myJSONData.days.push(
			{
				"weekDay": document.getElementById("newWeekDAY").value ,
				"day": validatedDay ,
				"month": validatedMonth ,
				"year": validatedYEAR ,
				"dateForSortAction": Number(validatedYEAR+""+validatedMonthEx+""+validatedDayEx) ,
				"lastEditDate": "" ,
				"description": document.getElementById("newDescription").value ,
			}
		);
		
		
		// to set the totalpagenumber, currentpage, and fill the book accordingly
		selectHowMany(document.getElementById("selectBox").value);
		//fillTheBook();
		
		window.location.href='#';						// to colse the popup
		document.getElementById('formNewPage').reset();	//reset the form for later recalling the popup
	}else{
		alert("لطفاً تاریخ‌ها را درست وارد نمایید. این اطلاعات برای مرتب کردن صفحات دفتر خاطرات/خطورات به کار گرفته می‌شوند.");
	}
}



//=================  EDIT AN ALREADY AVAILABLE DAY IN THE BOOK  ==================//



function editPage(pageNum) {
	pageToBeEdited=pageNum;
	
	//first populate the form with data from the page which is now to be edited
	document.getElementById("PageToEdit").innerHTML=toFa(pageNum);
	
	document.getElementById("editWeekDAY").value=myJSONData["days"][pageNum-1]["weekDay"];
	document.getElementById("editDAY").value=toFa(myJSONData["days"][pageNum-1]["day"]);
	document.getElementById("editMONTH").value=toFa(myJSONData["days"][pageNum-1]["month"]);
	document.getElementById("editYEAR").value=toFa(myJSONData["days"][pageNum-1]["year"]);
	
	document.getElementById("editDescription").value=myJSONData["days"][pageNum-1]["description"];
	
	// next call for the editing form to open
	window.location.href='#popupEditDay';
}
function saveEditedPage() {
	// fill the variable and make a new data in the JSON variable
	var 	validatedDay=toEn(document.getElementById("editDAY").value),
		validatedMonth=toEn(document.getElementById("editMONTH").value),
		validatedYEAR=toEn(document.getElementById("editYEAR").value);
	if(Number.isInteger(validatedDay) && validatedDay>=1 && validatedDay<=31 && Number.isInteger(validatedMonth) && validatedMonth>=1 && validatedMonth<=12 && Number.isInteger(validatedYEAR) && validatedYEAR>=0){
		// for sorting by dates we need to define new variables
		var validatedDayEx = (validatedDay<10) ? "0"+validatedDay : validatedDay;			//e.g. 5 -> 05
		var validatedMonthEx = (validatedMonth<10) ? "0"+validatedMonth : validatedMonth;	//e.g. 5 -> 05
		
		myJSONData.days.splice((pageToBeEdited-1), 1,	// deletes the original one and insert the edited one at the same place in the array
			{
				"weekDay": document.getElementById("editWeekDAY").value ,
				"day": validatedDay ,
				"month": validatedMonth ,
				"year": validatedYEAR ,
				"dateForSortAction": Number(validatedYEAR+""+validatedMonthEx+""+validatedDayEx) ,
				"lastEditDate": '<span style="color:green;"> (آخرین ویرایش در '+toFa(persianDateTime())+')</span>' ,
				"description": document.getElementById("editDescription").value ,
			}
		);
		
		fillTheBook();
		
		//reset the form for later recalling the popup
		document.getElementById('formEditedPage').reset();
		window.location.href='#';	// to colse the popup
	}else{
		alert("لطفاً تاریخ‌ها را درست وارد نمایید. این اطلاعات برای مرتب کردن صفحات دفتر خاطرات/خطورات به کار گرفته می‌شوند.");
	}
}


//=================  DELETE AN ALREADY AVAILABLE DAY IN THE BOOK  ==================//



function deletePage(pageNum){
	myJSONData.days.splice((pageNum-1), 1);	// deletes the page from the array
	
	// to set the totalpagenumber, currentpage, and fill the book accordingly
	selectHowMany(document.getElementById("selectBox").value);
	//fillTheBook();
}



//=================  FILL THE WEBPAGE WITH THE DATA ALREADY AQUIRED  ==================//



function fillTheBook() {
	document.getElementById('container').innerHTML="";
	
	if(myJSONData != undefined){
		myJSONData["days"].sort(function(a, b){return a.dateForSortAction - b.dateForSortAction});
	}else{
		return false;
	}
	
	saveToCache();	// as every change in "myJSONData" will be followed by "fillTheBook()", this is suitable to be placed at here, to always save the latest version of "myJSONData" in the browser's cache!
	
	var initialDayNum, finalDayNum;
	
	var newPage;
	for (var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
		var 	date=myJSONData["days"][day]["weekDay"]+" "+toFa(myJSONData["days"][day]["year"]
				+"/"+myJSONData["days"][day]["month"]
				+"/"+myJSONData["days"][day]["day"],
			description=myJSONData["days"][day]["description"]);
		
		var tblNum=0, figNum=0, videoNum=0, audioNum=0, animationNum=0, ftnNum=0;
		var nestedListLevel=0;
		
		description+="<div id='ftnOnPage"+day+"'>"
				+"<br><hr style='display:block; width:50%; float:right; margin-top:25px; margin-bottom:5px;'><br>"
				+"<div id='ftnOnPage"+day+"-content'></div>"
			+"</div>";
		
		
		description=description
			
			//for capturing NUMBERED figures ...
			//use as  /شکل{folder/image.gif}[300:200][: توضیحات شکل که زیر آن نوشته میشود:][کلید: کلیدواژه برای ارجاع به آن][عنوان شکل]
			.replace(/(?:\/شکل[ \t]*)(?:\{[ \t]*([^ک][^\}]*)[ \t]*\})(?:[ \t]*\[[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\:[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\])?[ \t]*(?:\[\:[ \t]*([^\:]*)\:\])?[ \t]*(?:\[[ \t]*کلید\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([^\]]*)[ \t]*\])?/g, function(x,y1,y2,y3,y4,y5,y6){
				figNum++;
				var figNumPersian=toFa(figNum.toString());
				var figWidth=(y2!=undefined)? " width='"+y2+"' " : "" ;
				var figHeight=(y3!=undefined)? " height='"+y3+"' " : "" ;
				var captionTail=(y4==undefined)?  "</span>"  :  ":</span> <span class='captionContent'>"+y4+"</span>" ;
				var figID=(y5!=undefined)? " id='fig-day"+day+"-"+y5+"' " : "" ;
				var figTitle=(y6!=undefined)? " title='"+y6+"' " : "" ;
				return "<figure style='text-align:center; align-content:center; margin:auto;'>"
						+"<img"+figID+"figNumber='"+figNumPersian+"' src='"+y1+"'"+figWidth+""+figHeight+""+figTitle+">"
						+"<figcaption>"
							+"<span style=\"font-size:90%!important;\">"
								+"<span style='color:crimson;'>شکل "+figNumPersian+captionTail
							+"</span>"
						+"</figcaption>"
					+"</figure>";
			})
			
			
			//for capturing videos ...
			//use as	/ویدئو{"folder/video.mp4" "folder/video.webm"}[زیرنویس: "folder/subtitle1.vtt?en" "folder/subtitle2.vtt?fa"][320:240][: توضیحات ویدئو که در زیر آن نوشته میشود:][کلید: کلیدواژه برای ارجاع به آن][عنوان ویدئو]
			.replace(/(?:\/ویدئو[ \t]*)(?:\{[ \t]*([^ک][^\}]*)\})[ \t]*(?:\[[ \t]*زیرنویس\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\:[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\])?[ \t]*(?:\[\:[ \t]*([^\:]*)\:\])?[ \t]*(?:\[[ \t]*کلید\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([^\]]*)\])?/g, function(x,y1,y2,y3,y4,y5,y6,y7){
				videoNum++;
				var videoNumPersian=toFa(videoNum.toString());
				var sources=y1.replace(/(\"[^\"]*\")/g,"<source src=$1>");
				var subtitles=(y2==undefined)? "" : y2.replace(/(?:\"([^\?]*)\?([^\"]*)\")/g,"<track src\=\"$1\" srclang\=\"$2\" label\=\"$2\" default>");
				var captionTail=(y5==undefined)?  "</span>"  :  ":</span>  <span class='captionContent'>"+y5+"</span>";
				var divWidth=(y3==undefined)? "" : (y3.indexOf("\%")!=-1 || y3.indexOf("px")!=-1)? "style='width:"+y3+"!important;" : "style='width:"+y3+"px!important;";
				var videoWidth=(y3!=undefined)? " width='"+y3+"' " : "" ;
				var videoHeight=(y4!=undefined)? " height='"+y4+"' " : "" ;
				return "<div class=\"videoContainer\" "+divWidth+" '>"
						+"<video id='video-day"+day+"-"+y6+"' videoNumber='"+videoNumPersian+"' "+ videoWidth + videoHeight +" title='"+y7+"' controls>"
							+sources
							+subtitles
+"مرورگر شما از HTML5 video پشتیبانی نمی‌کند."
						+"</video>"
						+"<br><span style=\"font-size:90%!important;\"><span style='color:crimson;'>فیلم "+videoNumPersian+""+captionTail+"</span>"
					+"</div>";
			})
			
			
			//for capturing audios ...
			//use as	/صوت{"folder/audio.ogg" "folder/audio.mp3"}[400][: توضیحات صوتی که در زیر آن نوشته میشود:][کلید: کلیدواژه برای ارجاع به آن][عنوان صوت]
			.replace(/(?:\/صوت[ \t]*)(?:\{[ \t]*([^ک][^\}]*)\})[ \t]*(?:\[[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\])?[ \t]*(?:\[\:[ \t]*([^\:]*)\:\])?[ \t]*(?:\[[ \t]*کلید\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([^\]]*)\])?/g, function(x,y1,y2,y3,y4,y5){
				audioNum++;
				var audioNumPersian=toFa(audioNum.toString());
				var sources=y1.replace(/(\"[^\"]*\")/g,"<source src=$1>");
				var captionTail=(y3==undefined)?  "</span>"  :  ":</span>  <span class='captionContent'>"+y3+"</span>" ;
				var divWidth=(y2==undefined)? "" : (y2.indexOf("\%")!=-1 || y2.indexOf("px")!=-1)? y2 : y2+"px";
				return "<div class=\"audioContainer\" style='width:"+divWidth+"!important;'>"
						+"<audio id='audio-day"+day+"-"+y4+"' audioNumber='"+audioNumPersian+"' style='width:"+divWidth+"!important;' title='"+y5+"' controls>"
							+sources
+"مرورگر شما از HTML5 audio پشتیبانی نمی‌کند."
						+"</audio>"
						+"<br><span style=\"font-size:90%!important;\"><span style='color:crimson;'>صوت "+audioNumPersian+""+captionTail+"</span>"
					+"</div>";
			})
			
			
			//for capturing animations ...
			//use as  ...
			.replace(/(?:\/پویانمایی[ \t]*)(?:\{[ \t]*([^ک][^\}]*)\})[ \t]*(?:\[[ \t]*کتابخانه\:[ \t]*([^\]]*)\])?[ \t]*(?:\[[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\:[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\])?[ \t]*(?:\[\:[ \t]*([^\:]*)\:\])?[ \t]*(?:\[[ \t]*([^\]]*)\])?/g, function(x,y1,y2,y3,y4,y5,y6){
				animationNum++;
				var animationNumPersian=toFa(animationNum.toString());
				userCalledAnimationSources.push(y1.replace(/[ \t]*([^\?]*)(?:\?[^\?]*)(?:\?.*)/g,"$1"));		//"<script src=\"$1\"></script>"
				var animationID=y1.replace(/[ \t]*(?:[^\?]*)(?:\?([^\?]*))(?:\?.*)/g,"$1");
				var startingFunction=y1.replace(/[ \t]*(?:[^\?]*)(?:\?[^\?]*)(?:\?(.*))/g,"$1");
				
				var currentAnimatioinLibs=[];
				y2.replace(/(?:\"([^\"]*)\")/g, function(x,y){
					currentAnimatioinLibs.push(y);	//"<script src=\""+y+"\"></script>"
				})
				for(var i=0, l=currentAnimatioinLibs.length; i<l; i++){
					if(userCalledAnimationLibs.indexOf(currentAnimatioinLibs[i])==-1){userCalledAnimationLibs.push(currentAnimatioinLibs[i])};
				}
				
				var divWidth=(y3==undefined)? "" : (y3.indexOf("\%")!=-1 || y3.indexOf("px")!=-1)? y3+"!important;" : y3+"px!important;";
				var divHeight=(y4==undefined)? "" : (y4.indexOf("\%")!=-1 || y4.indexOf("px")!=-1)? y4+"!important;" : y4+"px!important;";
				
				var captionTail=(y5==undefined)?  "</span>"  :  ":</span>  <span class='captionContent'>"+y5+"</span>" ;
			
				return "<div class=\"animationContainer\" style=\"width:"+divWidth+"\">"
						+"<div id='animation-"+animationID+"' animationPage='"+day+"' animationNumber='"+animationNumPersian+"' class=\"animation\" style=\"width:"+divWidth+" height:"+divHeight+"\" title='"+y6+"'>"
							+"<div onclick=\"this.style.display='none';  "+startingFunction+";\" class='myButton' style='text-align:center; line-height:"+divHeight+"; color:crimson; cursor:pointer;'>جهت نمایش پویانمایی کلیک کن!</div>"
						+"</div>"
						+"<br><span style=\"font-size:90%!important;\"><span style='color:crimson;'>پویانمایی "+animationNumPersian+""+captionTail+"</span>"
					+"</div>";
			})
			
			
			// for capturing footnotes, the source being like (٬٬ text ٬٬)
			.replace(/(?:\(٬٬)[ \t\n]*([\s\S]*?)[ \t\n]*(?:٬٬\))/g, function(x,y){
				ftnNum++;
				var ftnNumPersian=toFa(ftnNum.toString());
				return "<sup class='tooltip'>"
						+"<a href='#FTN-day"+day+"-"+ftnNum+"' id='ftn-day"+day+"-"+ftnNum+"' style='font-size:90%; color:crimson;'>"
							+ftnNumPersian
						+"</a>"
						+"<span id='ftnHidden-day"+day+"-"+ftnNum+"' class='tooltipContent'>"+y+"</span>"
					+"</sup>";
			})
			
			
			.replace(/(\/ن\/)[ \t\n]*([\S\s]*)[ \t\n]*\1/g,"<blockquote>$2</blockquote>")
			.replace(/(\/ی\/)[ \t\n]*([\s\S]*?)[ \t\n]*\1/g,"<!-- $2 -->")
			
			
			// for capturing "headings" in three levels "h1", "h2" and "h3"
			.replace(/(?:\/=\/|\/ت۱\/)[ \t]*(.+?)[ \t]*$/gm, "<p class='header(day"+day+")' kind='h1'>$1</p>")
			.replace(/(?:\/==\/|\/ت۲\/)[ \t]*(.+?)[ \t]*$/gm, "<p class='header(day"+day+")' kind='h2'>$1</p>")
			.replace(/(?:\/===\/|\/ت۳\/)[ \t]*(.+?)[ \t]*$/gm, "<p class='header(day"+day+")' kind='h3'>$1</p>")
			
			
			.replace(/(\s*\/خ.ب\/\s*)/g,"<br>")
			
			.replace(/(?:\s*\/ف.ع\{([۰۱۲۳۴۵۶۷۸۹\d\-\+]+)\}\s*)/g, function(x,y){
				return "<div style='margin-top:"+toEn(y)+"px"+"'></div>";
			})
			.replace(/(?:\s*\/ف.ا\{([۰۱۲۳۴۵۶۷۸۹\d\-\+]+)\}\s*)/g, function(x,y){
				return "<span style='margin-right:"+toEn(y)+"px;'></span>";
			})
			
			
			
			.replace(/٪٪[ \t\n]*([\s\S]*?)[ \t\n]*٪٪/g,"<pre dir='ltr'><code>$1</code></pre>")  //"<pre><code>$1</code></pre>" this enters code in a newline
			.replace(/٪(.*?)٪/g,"<code dir='ltr' style='font-family:monospace;'>$1</code>")  //"<pre><code>$1</code></pre>" this enters code in a newline
			.replace(/\%/g,"%")
			.replace(/\/\%/g,"٪")
			
			
			
			// for capturing "tables" ...
			.replace(/[ \t\n]*(?:\/جدول.ش\/)(?:\[کلید:[ \t]*(.*?)[ \t]*\])?(?:\[کلاس:[ \t]*(.*?)[ \t]*\])?(?:\[\:[ \t]*([^\:]*)\:\])?/g, function(x,y1,y2,y3){
				tblNum++;
				var tblNumPersian=toFa(tblNum.toString());
				var captionTail=(y3==undefined)?  "</span>"  :  ":</span>  <span class='captionContent'>"+y3+"</span>";
				return "<table id='tbl-day"+day+"-"+y1+"' tblNumber='"+tblNumPersian+"' class='"+y2+"'>"
						+"<caption>"
							+"<span style='color:crimson;'>جدول "+tblNumPersian+""+captionTail
						+"</caption>";
			})	// [class], [caption] & [key] in   /جدول.ش[key][class][caption]  are all optional ... 
			.replace(/[ \t\n]*(?:\/جدول.ش\*\/)(?:\[کلاس:[ \t]*(.*?)[ \t]*\])?/g, "<table class='$1'>")	// not numbered. not referrable, not increasing the table counter, not having any caption
			
			// to capture each row in the tables
			.replace(/(?:\/ردیف\/)[\t\n\r ]*(.*?)[\t\n\r ]*(?=\/ردیف\/|\/جدول\.پ\/|\r|\n|\t)/g,"<tr>$1</tr>")
			//.replace(/(\/ردیف\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<tr>$2</tr>")
			//.replace(/(?:^[ \t]*\/ردیف\/|\n[ \t]*\/ردیف\/)[ \t]*(.+?)(?:[ \t]*$)/gm, "<tr>$1</tr>")
			
			// to capture each column in each row, with possible different optional styles for it
			.replace(/(?:\|\|)([^\|\r\n\t]*)/g,"<td>$1</td>")
			.replace(/(?:\|ر\|)([^\|\r\n\t]*)/g,"<td style='text-align:right'>$1</td>")
			.replace(/(?:\|ر.ب\|)([^\|\r\n\t]*)/g,"<td style=\"vertical-align:top; text-align:right;\">$1</td>")
			.replace(/(?:\|ر.پ\|)([^\|\r\n\t]*)/g,"<td style=\"vertical-align:bottom; text-align:right;\">$1</td>")
			.replace(/(?:\|چ\|)([^\|\r\n\t]*)/g,"<td style='text-align:left'>$1</td>")
			.replace(/(?:\|چ.ب\|)([^\|\r\n\t]*)/g,"<td style=\"vertical-align:top; text-align:left;\">$1</td>")
			.replace(/(?:\|چ.پ\|)([^\|\r\n\t]*)/g,"<td style=\"vertical-align:bottom; text-align:left;\">$1</td>")
			.replace(/(?:\|ب\|)([^\|\r\n\t]*)/g,"<td style='vertical-align:top;'>$1</td>")
			.replace(/(?:\|پ\|)([^\|\r\n\t]*)/g,"<td style='vertical-align:bottom;'>$1</td>")
			
			.replace(/[ \t\n]*(?:\/جدول.پ\/)[ \t\n]*/g,"</table>")	// to end the tables
			
			
			// for capturing new styles defined by the user, to be considered as lying in the header of the HTML file
			.replace(/(\/استایل\/)[ \t\n]*(?=\S)([^\r]*?\S[*_]*)[ \t\n]*\1/g,  function(x,y1,y2){
				var style = document.createElement('style');
				style.type = 'text/css';
				style.innerHTML = y2;
				document.getElementsByTagName('head')[0].appendChild(style);
				
				//document.body.appendChild(style);
				/*
				if (style.styleSheet) style.styleSheet.cssText = y2;				// Supports IE
				else style.appendChild(document.createTextNode(y2));			// Supports the rest
				document.getElementsByTagName("head")[0].appendChild(style);	// where to place the style
				*/
				return "";		// if it was not added, an "undefined" text was written in its place!
			})
			
			
			
			.replace(/(\(الله\))/g,"<span style='font-family:Sanaa'>اللّه</span>")
			.replace(/(\(محمد\))/g,"<span style='font-family:Sanaa'>مُحَمَّد</span>")
			.replace(/(\(علی\))/g,"<span style='font-family:Sanaa'>عَلی</span>")
			.replace(/(\(جل\))/g,"<span style='font-family:Sanaa'>«جَلّ‌َجَلالُه»</span>")
			.replace(/(\(ص\))/g,"<span style='font-family:Sanaa'>«صَلَّی‌اللّه‌ُعَلَیْه‌ِوَآلِه»</span>")
			.replace(/(\(علیه\))/g,"<span style='font-family:Sanaa'>«عَلَیْه‌ِالسَّلام»</span>")
			.replace(/(\(علیها\))/g,"<span style='font-family:Sanaa'>«عَلَیْهاالسَّلام»</span>")
			.replace(/(\(علیهما\))/g,"<span style='font-family:Sanaa'>«عَلَیْهِماالسَّلام»</span>")
			.replace(/(\(علیهم\))/g,"<span style='font-family:Sanaa'>«عَلَیْهِم‌ُالسَّلام»</span>")
			.replace(/(\(عج\))/g,"<span style='font-family:Sanaa'>«عَجّ‌َاللّه‌ُفَرَجَه‌ُالشَّریف»</span>")
			.replace(/(\(رحمه\))/g,"<span style='font-family:Sanaa'>«رَحِمَه‌ُاللّه»</span>")
			.replace(/(\(رحمها\))/g,"<span style='font-family:Sanaa'>«رَحِمَهااللّه»</span>")
			.replace(/(\(رحمهما\))/g,"<span style='font-family:Sanaa'>«رَحِمَهُمااللّه»</span>")
			.replace(/(\(رحمهم\))/g,"<span style='font-family:Sanaa'>«رَحِمَهُم‌ُاللّه»</span>")
			.replace(/(\(سره\))/g,"<span style='font-family:Sanaa'>«قُدِّس‌َسِرُّه»</span>")
			.replace(/(\(سرها\))/g,"<span style='font-family:Sanaa'>«قُدِّس‌َسِرُّها»</span>")
			.replace(/(\(سرهما\))/g,"<span style='font-family:Sanaa'>«قُدِّس‌َسِرُّهُما»</span>")
			.replace(/(\(سرهم\))/g,"<span style='font-family:Sanaa'>«قُدِّس‌َسِرُّهُم»</span>")
			.replace(/(\(ظله\))/g,"<span style='font-family:Sanaa'>«دامَّ‌ظِلُّه»</span>")
			
			.replace(/(\/اسلیمی۱\/)/g,"<img src='Main/images/glyph/18-0.png' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/اسلیمی۲\/)/g,"<img src='Main/images/glyph/18-1.png' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/اسلیمی۳\/)/g,"<img src='Main/images/glyph/18-2.png' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/اسلیمی۴\/)/g,"<img src='Main/images/glyph/18-3.png' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/اسلیمی۵\/)/g,"<img src='Main/images/glyph/18-4.png' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/اسلیمی۶\/)/g,"<img src='Main/images/glyph/18-5.png' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/اسلیمی۷\/)/g,"<img src='Main/images/glyph/18-6.png' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/اسلیمی۸\/)/g,"<img src='Main/images/glyph/18-7.png' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/اسلیمی۹\/)/g,"<img src='Main/images/glyph/18-8.png' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/اسلیمی۱۰\/)/g,"<img src='Main/images/glyph/18-9.png' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/اسلیمی۱۱\/)/g,"<img src='Main/images/glyph/18-10.png' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/خط۱\/)/g,"<img src='Main/images/glyph/19-0.png' style='margin-bottom:-6px;'>")
			.replace(/(\/خط۲\/)/g,"<img src='Main/images/glyph/19-1.png' style='width:200px; margin-bottom:-6px;'>")
			.replace(/(\/خط۳\/)/g,"<img src='Main/images/glyph/19-2.png' style='margin-bottom:-10px;'>")
			.replace(/(\/خط۴\/)/g,"<img src='Main/images/glyph/19-3.png' style='margin-bottom:-10px;'>")
			.replace(/(\/خط۵\/)/g,"<img src='Main/images/glyph/19-4.png' style='margin-bottom:-10px;'>")
			.replace(/(\/خط۶\/)/g,"<img src='Main/images/glyph/19-5.png' style='margin-bottom:-10px;'>")
			.replace(/(\/خط۷\/)/g,"<img src='Main/images/glyph/19-6.png' style='margin-bottom:-30px;'>")
			.replace(/(\/خط۸\/)/g,"<img src='Main/images/glyph/19-7.png' style='margin-bottom:-40px;'>")
			.replace(/(\/خط۹\/)/g,"<img src='Main/images/glyph/20-0.png' style='margin-bottom:-8px;'>")
			.replace(/(\/خط۱۰\/)/g,"<img src='Main/images/glyph/20-1.png' style='margin-bottom:-3px;'>")
			.replace(/(\/خط۱۱\/)/g,"<img src='Main/images/glyph/20-2.png' style='margin-bottom:-5px;'>")
			.replace(/(\/خط۱۲\/)/g,"<img src='Main/images/glyph/20-3.png' style='margin-bottom:-8px;'>")
			.replace(/(\/خط۱۳\/)/g,"<img src='Main/images/glyph/20-4.png' style='margin-bottom:-9px;'>")
			.replace(/(\/خط۱۴\/)/g,"<img src='Main/images/glyph/20-5.png' style='margin-bottom:-10px;'>")
			.replace(/(\/خط۱۵\/)/g,"<img src='Main/images/glyph/20-6.png' style='margin-bottom:-11px;'>")
			.replace(/(\/خط۱۶\/)/g,"<img src='Main/images/glyph/20-7.png' style='margin-bottom:-10px;'>")
			.replace(/(\/خط۱۷\/)/g,"<img src='Main/images/glyph/20-8.png' style='margin-bottom:-10px;'>")
			.replace(/(\/خط۱۸\/)/g,"<img src='Main/images/glyph/20-9.png' style='margin-bottom:-10px;'>")
			.replace(/(\/خط۱۹\/)/g,"<img src='Main/images/glyph/20-10.png' style='margin-bottom:-30px;'>")
			.replace(/(\/خط۲۰\/)/g,"<img src='Main/images/glyph/20-11.png' style='margin-bottom:-15px;'>")
			
		// شکلک‌ها (smiley)
			.replace(/(\(ش۱\))/g, "<img src='Main/images/smiley/001.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۲\))/g, "<img src='Main/images/smiley/002.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۳\))/g, "<img src='Main/images/smiley/003.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۴\))/g, "<img src='Main/images/smiley/004.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۵\))/g, "<img src='Main/images/smiley/005.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۶\))/g, "<img src='Main/images/smiley/006.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۷\))/g, "<img src='Main/images/smiley/007.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۸\))/g, "<img src='Main/images/smiley/008.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۹\))/g, "<img src='Main/images/smiley/009.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۱۰\))/g,"<img src='Main/images/smiley/010.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۱۱\))/g,"<img src='Main/images/smiley/011.gif' style='margin-bottom:-4px;'>")
			.replace(/(\(ش۱۲\))/g,"<img src='Main/images/smiley/012.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۱۳\))/g,"<img src='Main/images/smiley/013.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۱۴\))/g,"<img src='Main/images/smiley/014.gif' style='margin-bottom:-4px;'>")
			.replace(/(\(ش۱۵\))/g,"<img src='Main/images/smiley/015.gif' style='margin-bottom:-5px;'>")
			.replace(/(\(ش۱۶\))/g,"<img src='Main/images/smiley/016.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۱۷\))/g,"<img src='Main/images/smiley/017.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۱۸\))/g,"<img src='Main/images/smiley/018.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۱۹\))/g,"<img src='Main/images/smiley/019.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۲۰\))/g,"<img src='Main/images/smiley/020.gif' style='margin-bottom:-3px;'>")		
			.replace(/(\(ش۲۱\))/g, "<img src='Main/images/smiley/021.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۲۲\))/g, "<img src='Main/images/smiley/022.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۲۳\))/g, "<img src='Main/images/smiley/023.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۲۴\))/g, "<img src='Main/images/smiley/024.gif' style='margin-bottom:-1px;'>")
			.replace(/(\(ش۲۵\))/g, "<img src='Main/images/smiley/025.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۲۶\))/g, "<img src='Main/images/smiley/026.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۲۷\))/g, "<img src='Main/images/smiley/027.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۲۸\))/g, "<img src='Main/images/smiley/028.gif' style='margin-bottom:-4px;'>")
			.replace(/(\(ش۲۹\))/g, "<img src='Main/images/smiley/029.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۳۰\))/g,"<img src='Main/images/smiley/030.gif' style='margin-bottom:-4px;'>")
			.replace(/(\(ش۳۱\))/g,"<img src='Main/images/smiley/031.gif' style='margin-bottom:-1px;'>")
			.replace(/(\(ش۳۲\))/g,"<img src='Main/images/smiley/032.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۳۳\))/g,"<img src='Main/images/smiley/033.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۳۴\))/g,"<img src='Main/images/smiley/034.gif' style='margin-bottom:-4px;'>")
			.replace(/(\(ش۳۵\))/g,"<img src='Main/images/smiley/035.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۳۶\))/g,"<img src='Main/images/smiley/036.gif' style='margin-bottom:-4px;'>")
			.replace(/(\(ش۳۷\))/g,"<img src='Main/images/smiley/037.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۳۸\))/g,"<img src='Main/images/smiley/038.gif' style='height:70px;'>")
			.replace(/(\(ش۳۹\))/g,"<img src='Main/images/smiley/039.gif' style='margin-bottom:-4px;'>")
			.replace(/(\(ش۴۰\))/g,"<img src='Main/images/smiley/040.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۴۱\))/g,"<img src='Main/images/smiley/041.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۴۲\))/g,"<img src='Main/images/smiley/042.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۴۳\))/g,"<img src='Main/images/smiley/043.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۴۴\))/g,"<img src='Main/images/smiley/044.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۴۵\))/g,"<img src='Main/images/smiley/045.gif' style='margin-bottom:-5px;'>")
			.replace(/(\(ش۴۶\))/g,"<img src='Main/images/smiley/046.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۴۷\))/g,"<img src='Main/images/smiley/047.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۴۸\))/g,"<img src='Main/images/smiley/048.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۴۹\))/g,"<img src='Main/images/smiley/049.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۵۰\))/g,"<img src='Main/images/smiley/050.gif' style='margin-bottom:-4px;'>")
			.replace(/(\(ش۵۱\))/g,"<img src='Main/images/smiley/051.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۵۲\))/g,"<img src='Main/images/smiley/052.gif' style='height:45px; margin-bottom:-5px;'>")
			.replace(/(\(ش۵۳\))/g,"<img src='Main/images/smiley/053.gif' style='height:40px; margin-bottom:-5px;'>")
			.replace(/(\(ش۵۴\))/g,"<img src='Main/images/smiley/054.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۵۵\))/g,"<img src='Main/images/smiley/055.gif' style='margin-bottom:-4px;'>")
			.replace(/(\(ش۵۶\))/g,"<img src='Main/images/smiley/056.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۵۷\))/g,"<img src='Main/images/smiley/057.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۵۸\))/g,"<img src='Main/images/smiley/058.gif' style='margin-bottom:-4px;'>")
			.replace(/(\(ش۵۹\))/g,"<img src='Main/images/smiley/059.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۶۰\))/g,"<img src='Main/images/smiley/060.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۶۱\))/g,"<img src='Main/images/smiley/061.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۶۲\))/g,"<img src='Main/images/smiley/062.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۶۳\))/g,"<img src='Main/images/smiley/063.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۶۴\))/g,"<img src='Main/images/smiley/064.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۶۵\))/g,"<img src='Main/images/smiley/065.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۶۶\))/g,"<img src='Main/images/smiley/066.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۶۷\))/g,"<img src='Main/images/smiley/067.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۶۸\))/g,"<img src='Main/images/smiley/068.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۶۹\))/g,"<img src='Main/images/smiley/069.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۷۰\))/g,"<img src='Main/images/smiley/070.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۷۱\))/g,"<img src='Main/images/smiley/071.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۷۲\))/g,"<img src='Main/images/smiley/072.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۷۳\))/g,"<img src='Main/images/smiley/073.gif' style='margin-bottom:-2px;'>")
			.replace(/(\(ش۷۴\))/g,"<img src='Main/images/smiley/074.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۷۵\))/g,"<img src='Main/images/smiley/075.gif' style='margin-bottom:-3px;'>")
			.replace(/(\(ش۷۶\))/g,"<img src='Main/images/smiley/b01.gif' style='height:30px; margin-bottom:-6px;'>")
			.replace(/(\(ش۷۷\))/g,"<img src='Main/images/smiley/b02.gif' style='height:30px; margin-bottom:-6px;'>")
			.replace(/(\(ش۷۸\))/g,"<img src='Main/images/smiley/b03.gif' style='height:40px; margin-bottom:-6px;'>")
			.replace(/(\(ش۷۹\))/g,"<img src='Main/images/smiley/b04.gif' style='height:40px; margin-bottom:-6px;'>")
			.replace(/(\(ش۸۰\))/g,"<img src='Main/images/smiley/b05.gif' style='height:40px; margin-bottom:-6px;'>")
			.replace(/(\(ش۸۱\))/g,"<img src='Main/images/smiley/b06.gif' style='height:35px; margin-bottom:-6px;'>")
			.replace(/(\(ش۸۲\))/g,"<img src='Main/images/smiley/b07.gif' style='height:40px; margin-bottom:-6px;'>")
			.replace(/(\(ش۸۳\))/g,"<img src='Main/images/smiley/b08.gif' style='height:45px; margin-bottom:-6px;'>")
			.replace(/(\(ش۸۴\))/g,"<img src='Main/images/smiley/b09.gif' style='height:35px; margin-bottom:-6px;'>")
			.replace(/(\(ش۸۵\))/g,"<img src='Main/images/smiley/b10.gif' style='height:30px; margin-bottom:-6px;'>")
			.replace(/(\(ش۸۶\))/g,"<img src='Main/images/smiley/b11.gif' style='height:40px; margin-bottom:-6px;'>")
			.replace(/(\(ش۸۷\))/g,"<img src='Main/images/smiley/b12.gif' style='height:40px; margin-bottom:-6px;'>")
			.replace(/(\(ش۸۸\))/g,"<img src='Main/images/smiley/b13.gif' style='height:45px; margin-bottom:-6px;'>")
			.replace(/(\(ش۸۹\))/g,"<img src='Main/images/smiley/b14.gif' style='height:35px; margin-bottom:-6px;'>")
			.replace(/(\(ش۹۰\))/g,"<img src='Main/images/smiley/b15.gif' style='height:30px; margin-bottom:-6px;'>")
			.replace(/(\(ش۹۱\))/g,"<img src='Main/images/smiley/b16.gif' style='height:35px; margin-bottom:-6px;'>")
			.replace(/(\(ش۹۲\))/g,"<img src='Main/images/smiley/b17.gif' style='height:35px; margin-bottom:-6px;'>")
			.replace(/(\(ش۹۳\))/g,"<img src='Main/images/smiley/b18.gif' style='height:40px; margin-bottom:-6px;'>")
			.replace(/(\(ش۹۴\))/g,"<img src='Main/images/smiley/b19.gif' style='height:30px; margin-bottom:-6px;'>")
			.replace(/(\(ش۹۵\))/g,"<img src='Main/images/smiley/b20.gif' style='height:50px; margin-bottom:-6px;'>")
			
			.replace(/(\/؟\/)/g,"<img src='Main/images/smiley/ex01.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/!\/)/g,"<img src='Main/images/smiley/ex02.gif' style='height:21px; margin-bottom:-4px;'>")
			.replace(/(\/!!\/)/g,"<img src='Main/images/smiley/ex03.gif' style='height:21px; margin-bottom:-5px;'>")
			.replace(/(\/چپ\/)/g,"<img src='Main/images/smiley/ex04.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/راست\/)/g,"<img src='Main/images/smiley/ex05.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/لامپ\/)/g,"<img src='Main/images/smiley/ex06.gif' style='height:21px; margin-bottom:-3px;'>")
			.replace(/(\/شمع\/)/g,"<img src='Main/images/smiley/ex07.gif' style='height:21px; margin-bottom:-2px;'>")
			.replace(/(\/گل\/)/g,"<img src='Main/images/smiley/ex08.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/قلب\/)/g,"<img src='Main/images/smiley/ex09.gif' style='height:21px; margin-bottom:-6px;'>")
			.replace(/(\/بادکنک\/)/g,"<img src='Main/images/smiley/ex10.gif' style='height:26px; margin-bottom:-2px;'>")
			.replace(/(\/کبوتر\/)/g,"<img src='Main/images/smiley/ex11.gif' style='height:26px; margin-bottom:-2px;'>")
			.replace(/(\/پروانه\/)/g,"<img src='Main/images/smiley/ex12.gif' style='height:21px; margin-bottom:-4px;'>")
			.replace(/(\/قهوه\/)/g,"<img src='Main/images/smiley/ex13.gif' style='height:21px; margin-bottom:-2px;'>")
			
			
			
			//for capturing links ...
			.replace(/(?:\/لینک)(?:\{[ \t]*([^\}]*)[ \t]*\})[ \t]*(?:\{[ \t]*([^\}]*)[ \t]*\})[ \t]*(?:\[([^\]]*)\])?/g,"<a href='$2' title='$3'>$1</a>")   //use as   /لینک{متن}{http://www.address.com}[عنوان]
			//for capturing email links ...
			.replace(/(?:\/ایمیل)(?:\{[ \t]*([^\}]*)[ \t]*\})/g,"<a href='mailto:$1'>$1</a>")   //use as   /ایمیل{aaaa_bbbb@ccc.ir}
			
			
			//for capturing INLINE figures ...
			//use as  /شکل*{folder/image.gif}[300:200]
			.replace(/(?:\/شکل\*[ \t]*)(?:\{[ \t]*([^\}]*)[ \t]*\})(?:[ \t]*\[[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\:[ \t]*([*\d]+[A-Za-z%]{0,4})[ \t]*\])?/g, function(x,y1,y2,y3){
				var figWidth=(y2!=undefined)? " width='"+y2+"' " : "" ;
				var figHeight=(y3!=undefined)? " height='"+y3+"' " : "" ;
				return "<img src='"+y1+"'"+figWidth+""+figHeight+" style='margin-bottom:"+(-y3/2+5)+"px;'>";
			})
			
			
			
			// to generate "لنگرگاه" everywhere the user will refer to later ... 	//use as   /لنگرگاه{key}
			.replace(/[ \t\n]*(?:\/لنگرگاه)(?:\{[ \t]*(.*?)[ \t]*\})/g, "<span id='anchor-$1' anchorPage='"+day+"'></span>")
			
			
			
			// Bold,Italic, Underline, Linetrough, ...
			.replace(/(××)[ \t\n]*(?=\S)([^\r]*?\S[*_]*)[ \t\n]*\1/g,"<strong>$2</strong>")
			.replace(/(×)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<em>$2</em>")
			.replace(/(\/ـ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<u>$2</u>")
			.replace(/(\/-\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<s>$2</s>")
					
			.replace(/(\/،\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<sub>$2</sub>")
			.replace(/(\/٬\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<sup>$2</sup>")
			
			.replace(/(\/ق\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(220,20,60)'>$2</span>")
			.replace(/(\/آ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(0,0,139)'>$2</span>")
			.replace(/(\/س\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:darkgreen'>$2</span>")
			.replace(/(\/ط\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(189,158,85)'>$2</span>")
			
			.replace(/(\/زرد\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='background-color:yellow'>$2</span>")
			.replace(/(\/سبز\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='background-color:lime'>$2</span>")
			
			.replace(/(\/ف۱\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:Kamran'>$2</span>")
			.replace(/(\/ف۲\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-family:Sanaa'>$2</span>")
			
			.replace(/(\/قرآن\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(34,139,34); text-shadow:2px 2px 4px white;'>$2</span>")
			.replace(/(\/حدیث\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(65,105,225); text-shadow:2px 2px 4px white;'>$2</span>")
			.replace(/(\/ترجمه\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='color:rgb(205,92,92); text-shadow:2px 2px 4px white;'>$2</span>")
			
			.replace(/(\/کک\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-size:60%;'>$2</span>")
			.replace(/(\/ک\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-size:80%;'>$2</span>")
			.replace(/(\/ب\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-size:120%;'>$2</span>")
			.replace(/(\/بب\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span style='font-size:140%;'>$2</span>")
			
			
			.replace(/(\/چ\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span class='blink'> $2 </span>")
			
			
			.replace(/[ \t]*\n{0}(---)[ \t]*\n{0,1}/g,"<hr>")
			
			.replace(/[ \t]*\n{0,1}(\/ت.چ\/|\/=.\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:left; margin:0;'>$2</p>")
			.replace(/[ \t]*\n{0,1}(\/ت.ر\/|\/.=\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:right; margin:0;'>$2</p>")
			.replace(/[ \t]*\n{0,1}(\/ت.و\/|\/=.=\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:center; margin:0;'>$2</p>")
			//.replace(/[ \t]*\n{0,1}(\/ه.ت\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p style='text-align:justify; margin:0;'>$2</p>")
			
			
			.replace(/(\/ltr\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1/g,"<span dir='ltr'>$2</span>")
			.replace(/[ \t]*\n{0,1}(\/ltrp\/)[ \t\n]*(?=\S)([^\r]*?\S)[ \t\n]*\1\n{0,1}/g,"<p dir='ltr' style='text-align:left;'>$2</p>")
			
		
		
			.replace(/^[ \t]*(\+|\*)[ \t]*(.+)/gm, function(x,y1,y2){
				var i=1;	if(i > nestedListLevel){nestedListLevel=i;}
				y2=(y1=="+")? "<ol><li>"+y2+"</li></ol>" : "<ul><li>"+y2+"</li></ul>";
				var temp=1, yt=y2, ytt="";
				while(temp){
					ytt=yt	.replace(/\<li\>[ \t]*(?:\+)[ \t]*(.+)\<\/li\>/, "<ol><li>$1</li></ol>")
						.replace(/\<li\>[ \t]*(?:\*)[ \t]*(.+)\<\/li\>/, "<ul><li>$1</li></ul>");
					if(ytt==yt){temp=0; i--;}
					yt=ytt;
					i++; if(i > nestedListLevel){nestedListLevel=i;}
				}
				return yt;
			})
			
			
			.replace(/(?:\/ج\/)[ \t]*(.+)(?:\n|$)/gm, function(x,y){
				var temp=1, yt=y, ytt="";
				while(temp){
					ytt=yt.replace(/(?:\/ج\/)[ \t]*(.+)(?:\n|$)/gm,"<div style='position:relative; margin:0 40px 0 0;'>$1</div>");
					if(ytt==yt){temp=0;}
					yt=ytt;
				}
				return "<div style='position:relative; margin:0 40px 0 0;'>"+ytt+"</div>";
			})
			
			
			// to place each citation to an equation inside a span, for later works to be done over it
			.replace(/(\\ref\{[^\}]+\})/g, "<span class='eqCitationSpan'>$1</span>")
			.replace(/(\\eqref\{[^\}]+\})/g, "<span class='eqCitationSpan'>$1</span>")
				
			
			.replace(/(\\end\{align\})\n{0,1}/g,"\\end{align}")		// for suitable vertical spacing after "align" math eq.
			.replace(/(\\end\{equation\})\n{0,1}/g,"\\end{equation}")	// for suitable vertical spacing after "equation" math eq.
			
			.replace(/\n/g,"<br>")
			;
		
		
		
		
		// to take care of lists and nested lists
		while(nestedListLevel){
			description=description.replace(/\<\/ol\>(?:\<br\>)?\<ol\>/g,"").replace(/\<\/ul\>(?:\<br\>)?\<ul\>/g,"");
			nestedListLevel--;
		}
		
		
		
		newPage=
			'<div class="newpage" id="page-'+(day+1)+'" style="width:'+hslider+'; height:'+vslider+'">'
				+'<div class="pageHeader">'
					+'<div style="float:right;">برگه‌ی '+toFa((day+1))+'</div>'
					+'<div>تاریخ: <span style="color:crimson; font-weight:bold;">'+date+'</span>'+myJSONData["days"][day]["lastEditDate"]+'</div>'
					+'<input onclick="deletePage('+(day+1)+');" type="image" class="myButton" src="Main/images/close.png"  title="حذف" align="center" width="20" height="20" style="position:relative; bottom:5%; padding:4px; float:left;">'
					+'<input onclick="editPage('+(day+1)+');" type="image" class="myButton" src="Main/images/edit.png"  title="ویرایش" align="center" width="20" height="20" style="position:relative; bottom:5%; padding:4px; float:left;">'
				+'</div>'
				+'<div style="text-align:right; margin-top:5px;">'+'<span style="display:none;">\$\\setCounter{0}\$</span>'+description+'</div>'
			+'</div>';	// the  $\setCounter{0}$  function resets the equation numbering in each page
		
		
		
		
		if(document.getElementById("checkbox").checked){
			//to display the pages in reverse order, the last page at top-right of the webpage
			if(day==0){	// the FIRST page lays on the page always alone
				document.getElementById('container').innerHTML=newPage;
			}else{
				// here we determine whether the new pages to lay after the previous pages or before them
				document.getElementById("page-"+day).insertAdjacentHTML('beforebegin', newPage);
				// these can be selected for positioning:  'beforebegin'  ,  'afterbegin'  ,  'beforeend'  ,  'afterend'
			}
		}else{
			//to display the pages in straight order of page numbers
			document.getElementById('container').innerHTML+=newPage;
		}
		
		
					
					
		if(ftnNum!=0){
			var content="";
			for(var i=1; i<=ftnNum; i++){
				content=document.getElementById("ftnHidden-day"+day+"-"+i).innerHTML;
				document.getElementById('ftnOnPage'+day+'-content').innerHTML+=
					"<p id='FTN-day"+day+"-"+i+"' style='font-size:90%;'>"
						+"<sup style=\"color:crimson;\">"+toFa(i)+" </sup> "
						+content
						+" <a href='#ftn-day"+day+"-"+i+"' style='color:cyan; border:1px groove cyan'>↩</a>"
					+"</p>";
			}
		}else{
			document.getElementById('ftnOnPage'+day).style.display='none';
		}
		
		
		/*
		// to compile math equations using MathJax
		var page=document.getElementById('page-'+(day+1));
		MathJax.Hub.Queue(
			["resetEquationNumbers",MathJax.InputJax.TeX],	 //resets the equation numberings at each compile
			["Typeset",MathJax.Hub,"page"]
			//["PreProcess",MathJax.Hub,"page"],
			//["Reprocess",MathJax.Hub,"page"]
		);
		*/
		
		
		// to handle the header styling and their numbering within each day
		var headers=document.getElementsByClassName("header(day"+day+")");
		var h1Num=0, h2Num=0, h3Num=0;
		for (var i = 0, l=headers.length; i<l; i++) {
			var header=headers[i];
			if(header.getAttribute("kind")=="h1"){
				h1Num++; h2Num=0; h3Num=0;
				header.innerHTML=
					"<span class='header1Content'>"+toFa(h1Num)+". "+header.innerHTML+"</span>";
			}else if(header.getAttribute("kind")=="h2"){
				h2Num++; h3Num=0;
				header.innerHTML=
					"<span class='header2Content'>"+toFa(h1Num)+".&hairsp;"+toFa(h2Num)+". "+header.innerHTML+"</span>";
			}else{
				h3Num++;
				header.innerHTML=
					"<span class='header3Content'>"+toFa(h1Num)+".&hairsp;"+toFa(h2Num)+".&hairsp;"+toFa(h3Num)+". "+header.innerHTML+"</span>";
			}
		}
		
		/*
		// to show only those pages which lie in the range selected
		if(document.getElementById("checkbox").checked){
			//to display the pages in reverse order, the last page at top-right of the webpage
			if(selectedPageNumShown == "ALL"){
				initialDayNum=0;
				finalDayNum=myJSONData["days"].length - 1;
			}else{
				initialDayNum=myJSONData["days"].length - currentPage*selectedPageNumShown;
				if(initialDayNum<0) initialDayNum=0;
				finalDayNum=myJSONData["days"].length - (currentPage-1)*selectedPageNumShown - 1;
			}
			if(day<initialDayNum || day>finalDayNum){
				//document.getElementById("page-"+(day+1)).style.display="none";
				if(!document.getElementById("page-"+(day+1)).classList.contains("hidden")){
					document.getElementById("page-"+(day+1)).classList.add("hidden");
				}
			}
		}else{
			//to display the pages in straight order of page numbers
			if(selectedPageNumShown == "ALL"){
				initialDayNum=0;
				finalDayNum=myJSONData["days"].length - 1;
			}else{
				initialDayNum=(currentPage-1)*selectedPageNumShown;
				finalDayNum=currentPage*selectedPageNumShown - 1;
				if(finalDayNum>myJSONData["days"].length) finalDayNum=myJSONData["days"].length;
			}
			if(day<initialDayNum || day>finalDayNum){
				//document.getElementById("page-"+(day+1)).style.display="none";
				if(!document.getElementById("page-"+(day+1)).classList.contains("hidden")){
					document.getElementById("page-"+(day+1)).classList.add("hidden");
				}
			}
		}
		*/
		
		
	}
	
	
	
	// to refer to the already generated referrable items
	document.getElementById('container').innerHTML = document.getElementById('container').innerHTML
		
		// for capturing references to already defined figures ...	   //use as   /شکل{کلید: key}
		.replace(/(?:\/شکل)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(document.getElementById('container').contains(document.querySelector('[id^="fig-day"][id$="-'+y+'"]'))){
				var id = document.querySelector('[id^="fig-day"][id$="-'+y+'"]').id;
				var targetDay=id.replace(/fig\-day(\d*)\-.*/,"$1");
				targetDay=(Number(targetDay)+1);
				return "<a href='#"+id+"' onclick='jumpToPageContainingPage("+targetDay+");'>شکل "
						+document.getElementById(id).getAttribute("figNumber")
					+"</a>"
					+" از برگه‌ی "
					+targetDay;
			}else{
				return	"<span style='color:crimson;'>شکل ؟؟</span>";
			}
		})
		// for capturing references to already defined ویدئو ...	   //use as   /ویدئو{کلید: key}
		.replace(/(?:\/ویدئو)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(document.getElementById('container').contains(document.querySelector('[id^="video-day"][id$="-'+y+'"]'))){
				var id = document.querySelector('[id^="video-day"][id$="-'+y+'"]').id;
				var targetDay=id.replace(/video\-day(\d*)\-.*/,"$1");
				targetDay=(Number(targetDay)+1);
				return "<a href='#"+id+"' onclick='jumpToPageContainingPage("+targetDay+");'>ویدئو "
						+document.getElementById(id).getAttribute("videoNumber")
					+"</a>"
					+" از برگه‌ی "
					+targetDay;
			}else{
				return	"<span style='color:crimson;'>ویدئو ؟؟</span>";
			}
		})
		// for capturing references to already defined صوت ...	   //use as   /صوت{کلید: key}
		.replace(/(?:\/صوت)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(document.getElementById('container').contains(document.querySelector('[id^="audio-day"][id$="-'+y+'"]'))){
				var id = document.querySelector('[id^="audio-day"][id$="-'+y+'"]').id;
				var targetDay=id.replace(/audio\-day(\d*)\-.*/,"$1");
				targetDay=(Number(targetDay)+1);
				return "<a href='#"+id+"' onclick='jumpToPageContainingPage("+targetDay+");'>صوت "
						+document.getElementById(id).getAttribute("audioNumber")
					+"</a>"
					+" از برگه‌ی "
					+targetDay;
			}else{
				return	"<span style='color:crimson;'>صوت ؟؟</span>";
			}
		})
		// for capturing references to already defined tables ...	   //use as   /جدول{کلید: key}
		.replace(/(?:\/جدول)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(document.getElementById('container').contains(document.querySelector('[id^="tbl-day"][id$="-'+y+'"]'))){
				var id = document.querySelector('[id^="tbl-day"][id$="-'+y+'"]').id;
				var targetDay=id.replace(/tbl\-day(\d*)\-.*/,"$1");
				targetDay=(Number(targetDay)+1);
				return "<a href='#"+id+"' onclick='jumpToPageContainingPage("+targetDay+");'>جدول "
						+document.getElementById(id).getAttribute("tblNumber")
					+"</a>"
					+" از برگه‌ی "
					+targetDay;
			}else{
				return	"<span style='color:crimson;'>جدول ؟؟</span>";
			}
		})
		// for capturing references to already defined پویانمایی ...	   //use as   /پویانمایی{کلید: key}
		.replace(/(?:\/پویانمایی)(?:\{کلید\:[ \t]*([^\}]*)[ \t]*\})/g,  function(x,y){
			if(document.getElementById('container').contains(document.getElementById("animation-"+y))){
				var targetDay=document.getElementById("animation-"+y).getAttribute("animationPage");
				targetDay=(Number(targetDay)+1);
				return "<a href='#animation-"+y+"' onclick='jumpToPageContainingPage("+targetDay+");'>پویانمایی "
						+document.getElementById("animation-"+y).getAttribute("animationNumber")
					+"</a>"
					+" از برگه‌ی "
					+targetDay;
			}else{
				return	"<span style='color:crimson;'>پویانمایی ؟؟</span>";
			}
		})
		// for capturing references to already defined anchors ...	   //use as   /لنگر{کلید: key}{متن لینک}
		.replace(/(?:\/لنگر)(?:\{کلید:[ \t]*(.*?)[ \t]*\})(?:\{[ \t]*(.*?)[ \t]*\})/g,  function(x,y1,y2){
			if(document.getElementById('container').contains(document.getElementById("anchor-"+y1))){
				var targetDay=document.getElementById("anchor-"+y1).getAttribute("anchorPage");
				targetDay=(Number(targetDay)+1);
				return "<a href='#anchor-"+y1+"' onclick='jumpToPageContainingPage("+targetDay+");'>"+y2+"</a>"
					+" از برگه‌ی "
					+targetDay;
					
			}else{
				return	"<a href='#' onclick='alert(\"لنگرگاه این لنگر تعریف نشده است!\");'>"+y2+"</a>";
			}
		});
	
	
	for(var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
		document.getElementById('page-'+(day+1)).innerHTML=document.getElementById('page-'+(day+1)).innerHTML
			.replace(/از برگه‌ی (\d+)/g, function(x,y){
				//alert(y);
				if(y==(day+1)){
					return "از همین برگه";
				}else{
					return "از برگه‌ی "+toFa(y);
				}
			});
	}
	
	
	
	// let add the js <script> tags corresponding to the called animations (sources+libs) into the header of the page
	for(var i=0, l=userCalledAnimationLibs.length; i<l; i++){
		var jsScript=document.createElement('script');
		jsScript.src=userCalledAnimationLibs[i];
		document.getElementsByTagName('head')[0].appendChild(jsScript);
	}
	for(var i=0, l=userCalledAnimationSources.length; i<l; i++){
		var jsScript=document.createElement('script');
		jsScript.src=userCalledAnimationSources[i];
		document.getElementsByTagName('head')[0].appendChild(jsScript);
		
		/*	//below pieces of codes are from:	https://stackoverflow.com/questions/8578617/inject-a-script-tag-with-remote-src-and-wait-for-it-to-execute
		(function(d, script) {
			script = d.createElement('script');
			script.type = 'text/javascript';
			script.async = true;
			script.onload = function(){
				// remote script has loaded
			};
			script.src = userCalledAnimationSources[i];
			d.getElementsByTagName('head')[0].appendChild(script);
		}(document));
		
		//or
		
		(function(d, s, id){
			var js, fjs = d.getElementsByTagName(s)[0];
			if (d.getElementById(id)){ return; }
			js = d.createElement(s); js.id = id;
			js.onload = function(){
				// remote script has loaded
			};
			js.src = userCalledAnimationSources[i];
			fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'animations-'+i));
		*/
		
	}
	
	
	
	// to compile math equations using MathJax
	//var container=document.getElementById('container');
	// to handle cross-referencing the equations in MathJax, due to the multipage nature of the document
	var perDayEqs=[];
	MathJax.Hub.Queue(
		["resetEquationNumbers",MathJax.InputJax.TeX],	   // to reset the equation numberings at each compile
		["Typeset",MathJax.Hub],	// ["Typeset",MathJax.Hub,"container"]
		
		function () {
			for(var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
				var jax = MathJax.Hub.getAllJax('page-'+(day+1));
				//alert(jax.length);
				var neWLabelsInPage=[];
				for (var i=0, l=jax.length; i<l; i++) {
					//alert(jax[i].originalText);
					jax[i].originalText.replace(/\\label\{([^\}]+)\}/g, function(x,y){
						neWLabelsInPage.push(y);
						return false;
					});
				}
				perDayEqs.push(neWLabelsInPage);
			}
			//alert(JSON.stringify(perDayEqs));
			
			var eqCitationArray = document.getElementsByClassName("eqCitationSpan");
			var targetDay;
			for(var i=0, l=eqCitationArray.length; i<l; i++) {
				var key=eqCitationArray[i].innerHTML
					.replace(/.*\\ref\{([^\}]+)\}.*/g,"$1").replace(/.*\\eqref\{([^\}]+)\}.*/g,"$1");
				targetDay=perDayEqs.findIndex(function(x) {
					return x.indexOf(key) !== -1;
				});
				targetDay=(Number(targetDay)+1);
				//alert(targetDay);
				eqCitationArray[i].outerHTML=
					"<span class='eqCitationSpan' onclick='jumpToPageContainingPage("+targetDay+");'>"
						+eqCitationArray[i].innerHTML
					+"</span>";
					/*
					// this was required if equations were reset numbered inside each page representing a day
					+" از برگه‌ی "
					+targetDay;
					*/
			}
			/*
			for(var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
				document.getElementById('page-'+(day+1)).innerHTML=document.getElementById('page-'+(day+1)).innerHTML
					.replace(/از برگه‌ی (\d+)/g, function(x,y){
						//alert(y);
						if(y==(day+1)){
							return "از همین برگه";
						}else{
							return "از برگه‌ی "+y;
						}
					});
			}
			document.getElementById('container').innerHTML = document.getElementById('container').innerHTML
				.replace(/از همین برگه از همین برگه/g,"از همین برگه")
				.replace(/از برگه‌ی \d+ از برگه‌ی (\d+)/g, function(x,y){
					return "از برگه‌ی "+toFa(y);
				});
			*/
			
		}
	);
	
	
	changePage();
	
}
function jumpToPageContainingPage(x){
	// 1 <= x <= myJSONData["days"].length;
	if(document.getElementById("checkbox").checked){	//pages are displayed in reverse order
		currentPage=Math.ceil((myJSONData["days"].length - x + 1) / selectedPageNumShown);
	}else{
		currentPage=Math.ceil(x / selectedPageNumShown);
	}
	document.getElementById('goToPage').value=toFa(totalPageNumber)+' \/ '+toFa(currentPage);
	
	changePage();
}

/*
// setting direction of showing the pages from "first" to "last" or vice versa ...
function changeDirection(chb){
	document.getElementById('containerContentInvisible').innerHTML=
											document.getElementById('container').innerHTML;
	document.getElementById('container').innerHTML="";
	if(chb.checked){
		for (var day=myJSONData["days"].length; day>=1; day--) {
			//to display the pages in reverse order, the last page at top-right of the webpage
			document.getElementById('container').innerHTML+=
											document.getElementById("page-"+day).outerHTML;
		}
	}else{
		for (var day=1, days=myJSONData["days"].length; day<=days; day++) {
			//to display the pages in straight order of page numbers
			document.getElementById('container').innerHTML+=
											document.getElementById("page-"+day).outerHTML;
		}
	}
	document.getElementById('containerContentInvisible').innerHTML="";	// to avoid 2 divs having a single ID
}
*/




//======  CHANGE THE SIZE OF THE PAGES SHOWN ON THE WEBPAGE, EACH BELONGING TO A DAY  =======



document.getElementById("hSizeSlider").oninput = function() {
	for(var i=1, l=days=myJSONData["days"].length; i<=l ; i++){
		hslider='calc('+ Number(this.value) +'% - 25px)';
		document.getElementById("page-"+i).style.width = hslider;
	}
}
document.getElementById("vSizeSlider").oninput = function() {
	for(var i=1, l=days=myJSONData["days"].length; i<=l ; i++){
		vslider='calc('+ Number(this.value) +'vh - 50px)';
		document.getElementById("page-"+i).style.height = vslider;
	}
}




//====================  OPEN A NEW FILE  =====================



var openFile=document.getElementById("Openfile");

function openFunction(){
	if(myJSONData){
		if(!confirm('با باز کردن فایل جدید اطلاعات فعلی از دست می‌روند، آیا ادامه می‌دهید؟')){
			return false;
		}
	}
	openFile.click();	// this opens the file browser dialog for selecting a file to open
	return;
};

openFile.addEventListener('change', function() {
	var fileToLoad=openFile.files[0];			// the selected file itself as an object?
	var fileToLoadAddress=openFile.value;		// the relative or absolute address of the selected file
	
	document.getElementById("bookName").innerHTML="<span style='color:rgb(238,232,170);'>فایل: </span>"+fileToLoadAddress.split('\\').pop()  .replace(/(.txt)/,"").replace(/(.*)٫(.*)$/g,"$1:$2");	// this writes the name of the file opened in the header at the top
	
	if(fileToLoad){
		var reader=new FileReader();
		reader.readAsText(fileToLoad, "UTF-8");
		reader.onload=function(event){
			myJSONData = JSON.parse(event.target.result);
			
			selectHowMany(10);
			totalPageNumber=Math.ceil(myJSONData["days"].length / selectedPageNumShown);
			(document.getElementById("checkbox").checked)?
				//to display the pages in reverse order, the last page at top-right of the webpage
				currentPage=1
				:
				//to display the pages in straight order of page numbers
				currentPage=totalPageNumber;
			document.getElementById("goToPage").value=toFa(totalPageNumber)+" \/ "+toFa(currentPage);
			fillTheBook();
		}
		reader.onerror=function(event){
			document.getElementById("container").innerHTML="بارگذاری فایل انتخاب شده ناموفق بود!";
		}
	}
});




//====================  SAVE TO A FILE (PERMANENT BACKUP)  =====================




function saveData(){
	if(myJSONData){
		var 	title=myJSONData["BookName"],
			today=toFa(persianDateTime()).replace(/\:/g,"٫");
	
		title=title.length>12	?	title.substring(0,8)+" ..."	:	title;
		
		// ------- if using  download.js
		download(  JSON.stringify(myJSONData)	,	"دفتر «"+title+"» ("+today+").txt"	,	"text/html");
	
		// ------- if not using  download.js
		/*
		var a = document.body.appendChild(document.createElement("a"));
		a.download = "myContacts.js";
		a.href = "data:text/html," + aaData;
		a.click();
		*/
	}else{
		alert("هنوز داده‌ای وارد نشده که ذخیره شود!");
	}
};
//----------or
/*
function saveData(text, name, type) {
	var a = document.createElement("a");
	var file = new Blob([text], {type: type});
	a.href = URL.createObjectURL(file);
	a.download = name;
	a.click();
}
saveData(jsonData, 'test.txt', 'text/plain');
*/



//=============  USE localStorage OF HTML5 TO AUTOMATE SAVING OF DATA IN CACHE ==============//



function saveToCache(){
	if(myJSONData.Accounts){
		delete myJSONData.Accounts;
		delete myJSONData.StartingAmounts;
		for (var day=0, days=myJSONData["days"].length; day<days; day++) {	//var day in myJSONData["days"]
			delete myJSONData["days"][day]["transactions"];
		}
	}
	window.localStorage["savedInCahe"] = JSON.stringify(myJSONData);	// stores the data to the browser's cache
	document.getElementById('save-log').style.display = 'inline-block';
	setTimeout(function() {
		document.getElementById('save-log').style.display = 'none';	// the save-log will last for 1 second (1000 ms) before it will become display-none ...
	}, 1000);
}



//=============  PREVENT LEAVING THE PAGE AS THERE MIGHT BE UNSAVED DATA ==============//



//$(window).bind('beforeunload', function(){
//	return 'شما در حال ترک نرم‌افزار هستید، آیا تمایل دارید یادداشت‌های خود را در صورت تغییر ذخیره نمایید؟';
//});	
window.onbeforeunload = function() {
	return "توصیه بر ذخیره‌ی داده‌ها پیش از حروج از نرم‌افزار است ... آیا اطمینان دارید می‌خواهید از نرم‌افزار خارج شوید؟!";
}	
//window.addEventListener("beforeunload", function(event) {
//	event.returnValue = "شما در حال ترک نرم‌افزار هستید، آیا تمایل دارید داده‌های خود را در صورت تغییر ذخیره نمایید؟";
	//saveFunctioin();
//});
