var WIDTH = 320, HEIGHT = 240;
var renderer4, scene4, camera4, torus4;

function sampleAnimation4(){
       var container = document.getElementById("animation-"+"container4");

       renderer4 = new THREE.WebGLRenderer();
       renderer4.setSize(WIDTH, HEIGHT);
       container.appendChild(renderer4.domElement);

       camera4 = new THREE.PerspectiveCamera(45, WIDTH /HEIGHT , 0.1, 1000);
       scene4 = new THREE.Scene();
    
       scene4.add(camera4);
       camera4.position.z = 300;
    
       torus4 = new THREE.Mesh( new THREE.TorusGeometry(75, 25, 160, 320) );
       torus4.position.y = 0;
       torus4.position.z = -150;
       scene4.add(torus4);
    
       requestAnimationFrame(render4);
};

function render4(){
      requestAnimationFrame(render4);
      
      torus4.rotation.y += 0.01;
      
      renderer4.render(scene4, camera4);
};
