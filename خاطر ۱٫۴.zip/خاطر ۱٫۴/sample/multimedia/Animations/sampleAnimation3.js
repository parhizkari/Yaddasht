var WIDTH = 320, HEIGHT = 240;
var renderer3, scene3, camera3, geometry3;

function sampleAnimation3(){
       var container = document.getElementById("animation-"+"container3");

       renderer3 = new THREE.WebGLRenderer();
       renderer3.setSize(WIDTH, HEIGHT);
       container.appendChild(renderer3.domElement);

       camera3 = new THREE.PerspectiveCamera(45, WIDTH /HEIGHT , 0.1, 1000);
       scene3 = new THREE.Scene();
    
       scene3.add(camera3);
       camera3.position.z = 10;
       
       
       var verticesOfCube = [ -1,-1,-1, 1,-1,-1, 1, 1,-1, -1, 1,-1, -1,-1, 1, 1,-1, 1, 1, 1, 1, -1, 1, 1, ];
       var indicesOfFaces = [ 2,1,0, 0,3,2, 0,4,7, 7,3,0, 0,1,5, 5,4,0, 1,2,6, 6,5,1, 2,3,7, 7,6,2, 4,5,6, 6,7,4 ];
       
       geometry3 = new THREE.Mesh( new THREE.PolyhedronGeometry( verticesOfCube, indicesOfFaces, 6, 2 ) );
       geometry3.position.y = 0;
       geometry3.position.z = -15;
       scene3.add(geometry3);
    
       requestAnimationFrame(render3);
};

function render3(){
      requestAnimationFrame(render3);
      
      geometry3.rotation.y += 0.01;
      
      renderer3.render(scene3, camera3);
};
